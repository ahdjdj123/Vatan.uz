import { Lang } from "@/lib/i18n";

export interface SourceItem {
  id: string;
  title: Record<Lang, string>;
  org: Record<Lang, string>;
  topic: Record<Lang, string>;
  url: string;
}

/**
 * Real, credible sources only. No fabricated citations.
 * These are official/credible public information sources about Uzbekistan.
 */
export const SOURCES: SourceItem[] = [
  {
    id: "gov-uz",
    title: {
      uz: "O‘zbekiston Respublikasi Hukumati portali",
      en: "Government portal of the Republic of Uzbekistan",
      ru: "Портал Правительства Республики Узбекистан",
    },
    org: { uz: "gov.uz", en: "gov.uz", ru: "gov.uz" },
    topic: {
      uz: "Islohotlar, davlat siyosati",
      en: "Reforms, state policy",
      ru: "Реформы, государственная политика",
    },
    url: "https://www.gov.uz",
  },
  {
    id: "lex-uz",
    title: {
      uz: "O‘zbekiston Respublikasi Konstitutsiyasi",
      en: "Constitution of the Republic of Uzbekistan",
      ru: "Конституция Республики Узбекистан",
    },
    org: { uz: "lex.uz", en: "lex.uz", ru: "lex.uz" },
    topic: {
      uz: "Huquq, mustaqillik, davlatchilik",
      en: "Law, independence, statehood",
      ru: "Право, независимость, государственность",
    },
    url: "https://lex.uz",
  },
  {
    id: "president-uz",
    title: {
      uz: "O‘zbekiston Respublikasi Prezidentining rasmiy veb-sayti",
      en: "Official website of the President of Uzbekistan",
      ru: "Официальный сайт Президента Узбекистана",
    },
    org: { uz: "president.uz", en: "president.uz", ru: "president.uz" },
    topic: {
      uz: "Islohotlar, davlat ramzlari",
      en: "Reforms, state symbols",
      ru: "Реформы, государственные символы",
    },
    url: "https://www.president.uz",
  },
  {
    id: "mygov-uz",
    title: {
      uz: "Yagona interaktiv davlat xizmatlari portali",
      en: "Single interactive portal of state services",
      ru: "Единый интерактивный портал госуслуг",
    },
    org: { uz: "my.gov.uz", en: "my.gov.uz", ru: "my.gov.uz" },
    topic: {
      uz: "Raqamlashtirish, davlat xizmatlari",
      en: "Digitalisation, public services",
      ru: "Цифровизация, госуслуги",
    },
    url: "https://my.gov.uz",
  },
  {
    id: "cer-certs",
    title: {
      uz: "Sertifikatlash markazi — elektron imzo va kiberxavfsizlik",
      en: "Certification centre — e-signature and cybersecurity",
      ru: "Центр сертификации — ЭЦП и кибербезопасность",
    },
    org: { uz: "cer.uz", en: "cer.uz", ru: "cer.uz" },
    topic: {
      uz: "Kiberxavfsizlik, elektron imzo",
      en: "Cybersecurity, e-signature",
      ru: "Кибербезопасность, ЭЦП",
    },
    url: "https://cer.uz",
  },
  {
    id: "un-cyber",
    title: {
      uz: "BMT — kiberjinoyatlar va onlayn xavfsizlik bo‘yicha ma’lumot",
      en: "UN — information on cybercrime and online safety",
      ru: "ООН — информация о киберпреступности и онлайн-безопасности",
    },
    org: { uz: "un.org", en: "un.org", ru: "un.org" },
    topic: {
      uz: "Kiberxavfsizlik, inson huquqlari",
      en: "Cybersecurity, human rights",
      ru: "Кибербезопасность, права человека",
    },
    url: "https://www.un.org/en/sections/issues-depth/cybercrime/index.html",
  },
  {
    id: "data-gov",
    title: {
      uz: "O‘zbekiston statistika qo‘mitasi — ochiq ma’lumotlar",
      en: "Statistics Committee of Uzbekistan — open data",
      ru: "Комитет статистики Узбекистана — открытые данные",
    },
    org: { uz: "stat.uz", en: "stat.uz", ru: "stat.uz" },
    topic: {
      uz: "Statistika, ijtimoiy ko‘rsatkichlar",
      en: "Statistics, social indicators",
      ru: "Статистика, социальные показатели",
    },
    url: "https://stat.uz",
  },
  {
    id: "youth-uz",
    title: {
      uz: "Yoshlar ishlari agentligi",
      en: "Youth Affairs Agency",
      ru: "Агентство по делам молодёжи",
    },
    org: { uz: "youth.uz", en: "youth.uz", ru: "youth.uz" },
    topic: {
      uz: "Yoshlar siyosati",
      en: "Youth policy",
      ru: "Молодёжная политика",
    },
    url: "https://youth.uz",
  },
];

export interface CyberScenario {
  id: string;
  question: Record<Lang, string>;
  safer: Record<Lang, string>;
  options: {
    text: Record<Lang, string>;
    correct: boolean;
    feedback: Record<Lang, string>;
  }[];
}

export const CYBER_SCENARIOS: CyberScenario[] = [
  {
    id: "sc1",
    question: {
      uz: "Sizga noma’lum raqamdan xabar keldi, ichida havola bor. Nima qilasiz?",
      en: "You get a message from an unknown number with a link inside. What do you do?",
      ru: "Вы получили сообщение с неизвестного номера со ссылкой. Что вы сделаете?",
    },
    safer: {
      uz: "Havolani ochmasdan turib jo‘natuvchini va manzilni tekshiring; shubhali bo‘lsa — o‘chiring.",
      en: "Before opening, verify the sender and the address; if suspicious — delete it.",
      ru: "Не открывая ссылку, проверьте отправителя и адрес; при сомнении — удалите.",
    },
    options: [
      {
        text: { uz: "Darhol ochaman", en: "Open it immediately", ru: "Сразу открою" },
        correct: false,
        feedback: {
          uz: "Noma’lum havolani ochish xavfli — fishing yoki zararli dastur bo‘lishi mumkin.",
          en: "Opening unknown links is risky — it may be phishing or malware.",
          ru: "Открывать неизвестные ссылки опасно — это может быть фишинг или вредонос.",
        },
      },
      {
        text: { uz: "Do‘stlarga yo‘layman", en: "Forward it to friends", ru: "Перешлю друзьям" },
        correct: false,
        feedback: {
          uz: "Yo‘lash xavfni tarqatadi. Avval jo‘natuvchini tekshiring.",
          en: "Forwarding spreads the risk. Verify the sender first.",
          ru: "Пересылка распространяет риск. Сначала проверьте отправителя.",
        },
      },
      {
        text: {
          uz: "Jo‘natuvchi va havolani avval tekshiraman",
          en: "Check the sender and the link first",
          ru: "Сначала проверю отправителя и ссылку",
        },
        correct: true,
        feedback: {
          uz: "To‘g‘ri. Jo‘natuvchini va havola manzilini tekshirish eng xavfsiz qadam.",
          en: "Correct. Verifying sender and URL is the safest step.",
          ru: "Верно. Проверка отправителя и адреса — самый безопасный шаг.",
        },
      },
      {
        text: {
          uz: "Biriktirilgan faylni yuklab olaman",
          en: "Download the attached file",
          ru: "Скачаю вложенный файл",
        },
        correct: false,
        feedback: {
          uz: "Noma’lum faylni yuklab olish zararli dastur o‘rnatishi mumkin.",
          en: "Downloading an unknown file may install malware.",
          ru: "Скачивание неизвестного файла может установить вредонос.",
        },
      },
    ],
  },
  {
    id: "sc2",
    question: {
      uz: "Emailingizga “hisobingiz bloklandi, parolni yangilang” degan xabar keldi. Nima qilasiz?",
      en: "You receive an email saying 'your account is blocked, update your password'. What do you do?",
      ru: "Вы получили письмо: «ваш аккаунт заблокирован, обновите пароль». Что вы сделаете?",
    },
    safer: {
      uz: "Brauzerda sayt manzilini qo‘lda yozib, rasmiy saytdan hisobingizni tekshiring.",
      en: "Type the site address manually in the browser and check your account on the official site.",
      ru: "Введите адрес сайта вручную и проверьте аккаунт на официальном сайте.",
    },
    options: [
      {
        text: {
          uz: "Xabardagi havolaga o‘tib, parolni kiritaman",
          en: "Click the link in the email and enter my password",
          ru: "Перейду по ссылке и введу пароль",
        },
        correct: false,
        feedback: {
          uz: "Bu fishing bo‘lishi mumkin. Hech qachon xabardagi havola orqali parol kiritmang.",
          en: "This could be phishing. Never enter your password through a link in a message.",
          ru: "Это может быть фишинг. Никогда не вводите пароль по ссылке из письма.",
        },
      },
      {
        text: {
          uz: "Brauzerda sayt manzilini qo‘lda yozib, rasmiy saytdan tekshiraman",
          en: "Type the site address manually in the browser and check the official site",
          ru: "Введу адрес сайта вручную и проверю на официальном сайте",
        },
        correct: true,
        feedback: {
          uz: "To‘g‘ri. Havola orqali emas, to‘g‘ridan-to‘g‘ri rasmiy saytga kiring.",
          en: "Correct. Go to the official site directly, not through a link.",
          ru: "Верно. Заходите на официальный сайт напрямую, а не по ссылке.",
        },
      },
      {
        text: {
          uz: "Xaboni o‘chirmasdan turib, hech narsa qilmayman",
          en: "Do nothing and keep the email",
          ru: "Ничего не делаю и оставлю письмо",
        },
        correct: false,
        feedback: {
          uz: "Xabarni o‘chirish va xabar berish yaxshiroq — lekin avval tekshirish ham kerak.",
          en: "Better to delete and report — but verification is still needed.",
          ru: "Лучше удалить и сообщить — но проверка всё равно нужна.",
        },
      },
      {
        text: {
          uz: "Parolni xaborga javoban yuboraman",
          en: "Reply to the email with my password",
          ru: "Отвечу на письмо и пришлю пароль",
        },
        correct: false,
        feedback: {
          uz: "Hech qachon parolni hech kimga yubormang — hatto rasmiy ko‘rinadiganlarga ham.",
          en: "Never send your password to anyone — even official-looking ones.",
          ru: "Никогда не отправляйте пароль никому — даже «официальным».",
        },
      },
    ],
  },
  {
    id: "sc3",
    question: {
      uz: "Ijtimoiy tarmoqda sizdan shaxsiy ma’lumot (manzil, tug‘ilgan sana) so‘raydigan test tarqaldi. Nima qilasiz?",
      en: "A quiz on social media asks for personal data (address, birth date). What do you do?",
      ru: "В соцсетях появился тест, запрашивающий личные данные (адрес, дату рождения). Что вы сделаете?",
    },
    safer: {
      uz: "Testni tark eting va shaxsiy ma’lumotni ulashmang.",
      en: "Leave the quiz and do not share personal data.",
      ru: "Покиньте тест и не делитесь личными данными.",
    },
    options: [
      {
        text: {
          uz: "Barcha savollarga to‘g‘ri javob beraman",
          en: "Answer all questions truthfully",
          ru: "Отвечу на все вопросы правдиво",
        },
        correct: false,
        feedback: {
          uz: "Bunday testlar ko‘pincha ma’lumot yig‘ish uchun. Shaxsiy ma’lumotni ulashmang.",
          en: "Such quizzes often collect data. Don't share personal information.",
          ru: "Такие тесты часто собирают данные. Не делитесь личной информацией.",
        },
      },
      {
        text: {
          uz: "Testni tark etaman va ma’lumot bermayman",
          en: "Leave the quiz and provide no data",
          ru: "Покину тест и не дам данные",
        },
        correct: true,
        feedback: {
          uz: "To‘g‘ri. Shaxsiy ma’lumot onlayn testlarda hech qachon kerak emas.",
          en: "Correct. Personal data is never needed for online quizzes.",
          ru: "Верно. Личные данные никогда не нужны онлайн-тестам.",
        },
      },
      {
        text: {
          uz: "Faqat tug‘ilgan sanani yozaman",
          en: "Only enter my birth date",
          ru: "Введу только дату рождения",
        },
        correct: false,
        feedback: {
          uz: "Tug‘ilgan sana ham parolni tiklash uchun ishlatiladi — uni ham berish xavfli.",
          en: "Birth date is used for password recovery — sharing it is risky too.",
          ru: "Дата рождения используется для восстановления пароля — это тоже рискованно.",
        },
      },
      {
        text: {
          uz: "Do‘stlarimga ham ulashaman",
          en: "Share it with my friends too",
          ru: "Поделюсь с друзьями",
        },
        correct: false,
        feedback: {
          uz: "Ulashish xavfni kengaytiradi. Avval ma’lumot xavfsizligini o‘ylang.",
          en: "Sharing widens the risk. Think about data safety first.",
          ru: "Пересылка расширяет риск. Сначала подумайте о безопасности данных.",
        },
      },
    ],
  },
  {
    id: "sc4",
    question: {
      uz: "Bir sayt bepul dastur taklif qilyapti, lekin u noma’lum. Nima qilasiz?",
      en: "A site offers a free program, but it is unknown. What do you do?",
      ru: "Сайт предлагает бесплатную программу, но он неизвестен. Что вы сделаете?",
    },
    safer: {
      uz: "Dasturni rasmiy manba yoki ishonchli do‘kondan yuklang.",
      en: "Download the program from the official source or a trusted store.",
      ru: "Скачайте программу из официального источника или надёжного магазина.",
    },
    options: [
      {
        text: {
          uz: "Yuklab olib, darhol o‘rnataman",
          en: "Download and install immediately",
          ru: "Скачаю и сразу установлю",
        },
        correct: false,
        feedback: {
          uz: "Noma’lum dastur zararli bo‘lishi mumkin. Avval manbani tekshiring.",
          en: "Unknown software may be malicious. Verify the source first.",
          ru: "Неизвестная программа может быть вредоносной. Сначала проверьте источник.",
        },
      },
      {
        text: {
          uz: "Rasmiy manbadan yoki do‘kondan yuklab olaman",
          en: "Download from the official source or store",
          ru: "Скачаю из официального источника или магазина",
        },
        correct: true,
        feedback: {
          uz: "To‘g‘ri. Dasturlarni faqat ishonchli manbalardan yuklang.",
          en: "Correct. Only download software from trusted sources.",
          ru: "Верно. Скачивайте программы только из надёжных источников.",
        },
      },
      {
        text: {
          uz: "Antivirusni o‘chirib qo‘yaman",
          en: "Turn off the antivirus",
          ru: "Отключу антивирус",
        },
        correct: false,
        feedback: {
          uz: "Antivirusni o‘chirish xavfli — u zararli dasturni to‘xtatolmaydi.",
          en: "Disabling antivirus is risky — it can't stop malware.",
          ru: "Отключать антивирус опасно — он не остановит вредонос.",
        },
      },
      {
        text: {
          uz: "Hech qanday tekshiruvsiz o‘rnataman",
          en: "Install without any checks",
          ru: "Установлю без проверок",
        },
        correct: false,
        feedback: {
          uz: "Tekshiruvsiz o‘rnatish tizimni xavf ostiga qo‘yadi.",
          en: "Installing without checks puts your system at risk.",
          ru: "Установка без проверок подвергает систему риску.",
        },
      },
    ],
  },
  {
    id: "sc5",
    question: {
      uz: "Wi-Fi tarmog‘ida “Bepul internet” degan ochiq tarmoq ko‘rdingiz. Nima qilasiz?",
      en: "You see an open Wi-Fi network named 'Free Internet'. What do you do?",
      ru: "Вы видите открытую Wi-Fi сеть с названием «Бесплатный интернет». Что вы сделаете?",
    },
    safer: {
      uz: "Ochiq tarmoqqa ulanmang yoki faqat VPN orqali ulaning.",
      en: "Do not connect to open networks, or connect only via VPN.",
      ru: "Не подключайтесь к открытым сетям или используйте VPN.",
    },
    options: [
      {
        text: {
          uz: "Ulanib, bank hisobimga kiraman",
          en: "Connect and log into my bank account",
          ru: "Подключусь и зайду в банковский аккаунт",
        },
        correct: false,
        feedback: {
          uz: "Ochiq Wi-Fi orqali maxfiy ma’lumot kiritish xavfli — ma’lumot o‘g‘irlanishi mumkin.",
          en: "Entering sensitive data over open Wi-Fi is risky — data may be intercepted.",
          ru: "Вводить данные через открытый Wi-Fi опасно — данные могут перехватить.",
        },
      },
      {
        text: {
          uz: "Ulanmayman yoki faqat VPN bilan ulanaman",
          en: "Don't connect, or connect only via VPN",
          ru: "Не подключусь или подключусь только через VPN",
        },
        correct: true,
        feedback: {
          uz: "To‘g‘ri. Ochiq tarmoqlarda VPN ishlatish yoki ulanmaslik eng xavfsiz.",
          en: "Correct. Using a VPN or not connecting is safest on open networks.",
          ru: "Верно. На открытых сетях лучше использовать VPN или не подключаться.",
        },
      },
      {
        text: {
          uz: "Ulanib, parollarni almashtiraman",
          en: "Connect and change my passwords",
          ru: "Подключусь и сменю пароли",
        },
        correct: false,
        feedback: {
          uz: "Ochiq tarmoqda parol almashtirish ham xavfli — ma’lumot o‘g‘irlanishi mumkin.",
          en: "Changing passwords on open Wi-Fi is also risky — data may be intercepted.",
          ru: "Менять пароли в открытой сети тоже опасно — данные могут перехватить.",
        },
      },
      {
        text: {
          uz: "Barcha hisoblarimga kirib tekshiraman",
          en: "Log into all my accounts to check",
          ru: "Зайду во все аккаунты для проверки",
        },
        correct: false,
        feedback: {
          uz: "Bir nechta hisobga kirish xavfni oshiradi. Ochiq tarmoqdan foydalanmang.",
          en: "Logging into multiple accounts increases risk. Avoid open networks.",
          ru: "Вход в несколько аккаунтов увеличивает риск. Избегайте открытых сетей.",
        },
      },
    ],
  },
];

export interface SearchableItem {
  type: "section" | "topic" | "source" | "faq" | "glossary";
  id: string;
  titleKey?: string; // translation key
  titleText?: Record<Lang, string>;
  descKey?: string;
  descText?: Record<Lang, string>;
  target?: string; // element id to scroll to
  href?: string;
  openGlossary?: boolean;
}

/** Build searchable corpus dynamically from translations + sources. */
export function buildSearchIndex(): SearchableItem[] {
  const items: SearchableItem[] = [];

  // Sections
  (["s1", "s2", "s3", "s4", "s5"] as const).forEach((s) => {
    items.push({
      type: "section",
      id: `section-${s}`,
      titleKey: `${s}.title`,
      descKey: `${s}.lead`,
      target: s,
    });
  });

  // Section 01 topics
  ([
    "vatan",
    "tinchlik",
    "hamjihatlik",
    "bagrikenglik",
    "hurmat",
    "tarix",
    "meros",
    "qadriyatlar",
    "kelajak",
  ] as const).forEach((k) => {
    items.push({
      type: "topic",
      id: `topic-${k}`,
      titleKey: `s1.values.${k}`,
      descKey: `s1.values.${k}.d`,
      target: "s1",
    });
  });

  // Section 02 topics
  ([
    "davlat",
    "ramzlar",
    "til",
    "qadriyatlar",
    "meros",
    "talim",
    "fan",
    "xalqaro",
    "huquq",
  ] as const).forEach((k) => {
    items.push({
      type: "topic",
      id: `gains-${k}`,
      titleKey: `s2.gains.${k}`,
      descKey: `s2.gains.${k}.d`,
      target: "s2",
    });
  });

  // Section 03 areas
  (["education", "healthcare", "digital", "business", "youth"] as const).forEach(
    (k) => {
      items.push({
        type: "topic",
        id: `area-${k}`,
        titleKey: `s3.area.${k}`,
        target: "s3",
      });
    }
  );

  // Section 04 topics
  ([
    "data",
    "passwords",
    "strong",
    "links",
    "phishing",
    "messages",
    "downloads",
    "social",
    "misinfo",
  ] as const).forEach((k) => {
    items.push({
      type: "topic",
      id: `cyber-${k}`,
      titleKey: `s4.topic.${k}`,
      descKey: `s4.topic.${k}.d`,
      target: "s4",
    });
  });

  // FAQ
  (["q1", "q2", "q3", "q4", "q5", "q6"] as const).forEach((k) => {
    items.push({
      type: "faq",
      id: `faq-${k}`,
      titleKey: `faq.${k}`,
      descKey: `faq.a${k.slice(1)}`,
      target: "faq",
    });
  });

  // Glossary terms
  ([
    "vatan", "mustaqillik", "islohot", "kiberxavfsizlik", "fishing",
    "parol", "haq", "meros", "hamjihatlik", "bagrikenglik", "taqdimot", "davlat",
    "konstitutsiya", "bayroq", "gerb", "madhiya", "VPN", "malware", "shifrlash", "profilaktika",
  ] as const).forEach((k) => {
    items.push({
      type: "glossary",
      id: `glossary-${k}`,
      titleKey: `term.${k}`,
      descKey: `term.${k}.d`,
      openGlossary: true,
    });
  });

  // Sources
  SOURCES.forEach((s) => {
    items.push({
      type: "source",
      id: s.id,
      titleText: s.title,
      descText: s.topic,
      target: "sources",
      href: s.url,
    });
  });

  return items;
}
