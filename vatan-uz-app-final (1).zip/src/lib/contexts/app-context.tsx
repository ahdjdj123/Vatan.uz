"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Lang, t as translate } from "@/lib/i18n";

export type Theme = "light" | "dark" | "system";
export type TextSize = "normal" | "large" | "xlarge";

export type SectionId = "hero" | "s1" | "s2" | "s3" | "s4" | "s5";

export interface ProgressState {
  visited: Record<SectionId, boolean>;
  reflections: Record<string, string>;
  scenarioScore: number;
  scenarioCompleted: number;
  presentationProgress: number;
  survey: SurveyQuestion[] | null;
  lastVisited: SectionId | null;
  bookmarks: string[];
  celebratedSections: string[];
  streak: number;
  lastVisitDate: string | null;
}

export interface SurveyQuestion {
  id: string;
  question: string;
  options: { label: string; count: number }[];
}

interface AppContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
  theme: Theme;
  setTheme: (t: Theme) => void;
  resolvedTheme: "light" | "dark";
  textSize: TextSize;
  setTextSize: (s: TextSize) => void;
  reducedMotion: boolean;
  setReducedMotion: (v: boolean) => void;
  highContrast: boolean;
  setHighContrast: (v: boolean) => void;
  progress: ProgressState;
  markVisited: (s: SectionId) => void;
  saveReflection: (key: string, value: string) => void;
  getReflection: (key: string) => string;
  setScenarioResult: (score: number, completed: number) => void;
  setPresentationProgress: (n: number) => void;
  setSurvey: (s: SurveyQuestion[] | null) => void;
  resetProgress: () => void;
  searchOpen: boolean;
  setSearchOpen: (v: boolean) => void;
  settingsOpen: boolean;
  setSettingsOpen: (v: boolean) => void;
  presentationOpen: boolean;
  setPresentationOpen: (v: boolean) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (v: boolean) => void;
  introSeen: boolean;
  setIntroSeen: (v: boolean) => void;
  lastVisited: SectionId | null;
  glossaryOpen: boolean;
  setGlossaryOpen: (v: boolean) => void;
  bookmarksOpen: boolean;
  setBookmarksOpen: (v: boolean) => void;
  achievementsOpen: boolean;
  setAchievementsOpen: (v: boolean) => void;
  quizOpen: boolean;
  setQuizOpen: (v: boolean) => void;
  dashboardOpen: boolean;
  setDashboardOpen: (v: boolean) => void;
  isBookmarked: (id: string) => boolean;
  toggleBookmark: (id: string) => void;
  clearBookmarks: () => void;
  studyMode: boolean;
  setStudyMode: (v: boolean) => void;
  celebrate: (key: string, messageKey: string) => void;
  celebration: { key: string; message: string } | null;
  dismissCelebration: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const DEFAULT_PROGRESS: ProgressState = {
  visited: {
    hero: false,
    s1: false,
    s2: false,
    s3: false,
    s4: false,
    s5: false,
  },
  reflections: {},
  scenarioScore: 0,
  scenarioCompleted: 0,
  presentationProgress: 0,
  survey: null,
  lastVisited: null,
  bookmarks: [],
  celebratedSections: [],
  streak: 0,
  lastVisitDate: null,
};

const STORAGE_KEY = "vatan.app.state.v1";

interface PersistedState {
  lang: Lang;
  theme: Theme;
  textSize: TextSize;
  reducedMotion: boolean;
  highContrast: boolean;
  progress: ProgressState;
  introSeen: boolean;
  studyMode: boolean;
}

function loadPersisted(): Partial<PersistedState> {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Partial<PersistedState>;
  } catch {
    return {};
  }
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Lang>("uz");
  const [theme, setThemeState] = useState<Theme>("light");
  const [textSize, setTextSizeState] = useState<TextSize>("normal");
  const [reducedMotion, setReducedMotionState] = useState(false);
  const [highContrast, setHighContrastState] = useState(false);
  const [progress, setProgress] = useState<ProgressState>(DEFAULT_PROGRESS);
  const [resolvedTheme, setResolvedTheme] = useState<"light" | "dark">("light");
  const [mounted, setMounted] = useState(false);

  const [searchOpen, setSearchOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [presentationOpen, setPresentationOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [introSeen, setIntroSeenState] = useState(false);
  const [glossaryOpen, setGlossaryOpen] = useState(false);
  const [bookmarksOpen, setBookmarksOpen] = useState(false);
  const [achievementsOpen, setAchievementsOpen] = useState(false);
  const [quizOpen, setQuizOpen] = useState(false);
  const [dashboardOpen, setDashboardOpen] = useState(false);
  const [studyMode, setStudyModeState] = useState(false);
  const [celebration, setCelebration] = useState<{ key: string; message: string } | null>(null);

  useEffect(() => {
    const p = loadPersisted();
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (p.lang) setLangState(p.lang);
     
    if (p.theme) setThemeState(p.theme);
     
    if (p.textSize) setTextSizeState(p.textSize);
     
    if (typeof p.reducedMotion === "boolean") setReducedMotionState(p.reducedMotion);
     
    if (typeof p.highContrast === "boolean") setHighContrastState(p.highContrast);
     
    if (p.progress) setProgress({ ...DEFAULT_PROGRESS, ...p.progress });

    if (typeof p.introSeen === "boolean") setIntroSeenState(p.introSeen);

    if (typeof p.studyMode === "boolean") setStudyModeState(p.studyMode);

    // Update streak based on last visit date
    const today = new Date().toISOString().slice(0, 10);
    const lastDate = p.progress?.lastVisitDate ?? null;
    let newStreak = p.progress?.streak ?? 0;
    if (lastDate !== today) {
      if (lastDate) {
        const last = new Date(lastDate);
        const diff = Math.round((Date.now() - last.getTime()) / 86400000);
        if (diff === 1) {
          newStreak = (p.progress?.streak ?? 0) + 1;
          setProgress((prev) => ({ ...prev, streak: newStreak, lastVisitDate: today }));
        } else if (diff > 1) {
          newStreak = 1;
          setProgress((prev) => ({ ...prev, streak: 1, lastVisitDate: today }));
        }
      } else {
        newStreak = 1;
        setProgress((prev) => ({ ...prev, streak: 1, lastVisitDate: today }));
      }
    }

    // Celebrate streak milestones
    const celebrated = p.progress?.celebratedSections ?? [];
    if (newStreak === 7 && !celebrated.includes("streak7")) {
      setTimeout(() => setCelebration({ key: "streak7", message: "celebrate.streak7" }), 800);
    } else if (newStreak === 14 && !celebrated.includes("streak14")) {
      setTimeout(() => setCelebration({ key: "streak14", message: "celebrate.streak14" }), 800);
    } else if (newStreak === 30 && !celebrated.includes("streak30")) {
      setTimeout(() => setCelebration({ key: "streak30", message: "celebrate.streak30" }), 800);
    }

    setMounted(true);
  }, []);

  useEffect(() => {
    if (!mounted) return;
    try {
      const data: PersistedState = {
        lang,
        theme,
        textSize,
        reducedMotion,
        highContrast,
        progress,
        introSeen,
        studyMode,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch {
      /* ignore */
    }
  }, [mounted, lang, theme, textSize, reducedMotion, highContrast, progress, introSeen, studyMode]);

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const apply = () => {
      const resolved =
        theme === "system" ? (media.matches ? "dark" : "light") : theme;
      setResolvedTheme(resolved as "light" | "dark");
      const root = document.documentElement;
      root.classList.toggle("dark", resolved === "dark");
    };
    apply();
    if (theme === "system") {
      media.addEventListener("change", apply);
      return () => media.removeEventListener("change", apply);
    }
  }, [theme]);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("reduce-motion", reducedMotion);
    root.classList.toggle("high-contrast", highContrast);
    root.classList.toggle("study-mode", studyMode);
    root.classList.remove("text-scale-large", "text-scale-xlarge");
    if (textSize === "large") root.classList.add("text-scale-large");
    if (textSize === "xlarge") root.classList.add("text-scale-xlarge");
  }, [reducedMotion, highContrast, textSize, studyMode]);

  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const setLang = useCallback((l: Lang) => setLangState(l), []);
  const setTheme = useCallback((th: Theme) => setThemeState(th), []);
  const setTextSize = useCallback((s: TextSize) => setTextSizeState(s), []);
  const setReducedMotion = useCallback(
    (v: boolean) => setReducedMotionState(v),
    []
  );
  const setHighContrast = useCallback(
    (v: boolean) => setHighContrastState(v),
    []
  );

  const setIntroSeen = useCallback((v: boolean) => setIntroSeenState(v), []);
  const setStudyMode = useCallback((v: boolean) => setStudyModeState(v), []);

  const isBookmarked = useCallback(
    (id: string) => progress.bookmarks.includes(id),
    [progress.bookmarks]
  );

  const toggleBookmark = useCallback((id: string) => {
    setProgress((prev) => {
      const has = prev.bookmarks.includes(id);
      return {
        ...prev,
        bookmarks: has
          ? prev.bookmarks.filter((b) => b !== id)
          : [...prev.bookmarks, id],
      };
    });
  }, []);

  const clearBookmarks = useCallback(() => {
    setProgress((prev) => ({ ...prev, bookmarks: [] }));
  }, []);

  const celebrate = useCallback((key: string, messageKey: string) => {
    setProgress((prev) => {
      if (prev.celebratedSections.includes(key)) return prev;
      return { ...prev, celebratedSections: [...prev.celebratedSections, key] };
    });
    setCelebration({ key, message: messageKey });
  }, []);

  const dismissCelebration = useCallback(() => setCelebration(null), []);

  const markVisited = useCallback((s: SectionId) => {
    setProgress((prev) => ({
      ...prev,
      visited: { ...prev.visited, [s]: true },
      lastVisited: s,
    }));
  }, []);

  const saveReflection = useCallback((key: string, value: string) => {
    setProgress((prev) => ({
      ...prev,
      reflections: { ...prev.reflections, [key]: value },
    }));
  }, []);

  const getReflection = useCallback(
    (key: string) => progress.reflections[key] ?? "",
    [progress.reflections]
  );

  const setScenarioResult = useCallback((score: number, completed: number) => {
    setProgress((prev) => ({
      ...prev,
      scenarioScore: Math.max(prev.scenarioScore, score),
      scenarioCompleted: Math.max(prev.scenarioCompleted, completed),
    }));
  }, []);

  const setPresentationProgress = useCallback((n: number) => {
    setProgress((prev) => ({
      ...prev,
      presentationProgress: Math.max(prev.presentationProgress, n),
    }));
  }, []);

  const setSurvey = useCallback((s: SurveyQuestion[] | null) => {
    setProgress((prev) => ({ ...prev, survey: s }));
  }, []);

  const resetProgress = useCallback(() => {
    setProgress({
      ...DEFAULT_PROGRESS,
      visited: {
        hero: false,
        s1: false,
        s2: false,
        s3: false,
        s4: false,
        s5: false,
      },
      reflections: {},
      scenarioScore: 0,
      scenarioCompleted: 0,
      presentationProgress: 0,
      survey: null,
      lastVisited: null,
      bookmarks: [],
      celebratedSections: [],
      streak: 0,
      lastVisitDate: null,
    });
  }, []);

  const tFn = useCallback((key: string) => translate(lang, key), [lang]);

  const value = useMemo<AppContextValue>(
    () => ({
      lang,
      setLang,
      t: tFn,
      theme,
      setTheme,
      resolvedTheme,
      textSize,
      setTextSize,
      reducedMotion,
      setReducedMotion,
      highContrast,
      setHighContrast,
      progress,
      markVisited,
      saveReflection,
      getReflection,
      setScenarioResult,
      setPresentationProgress,
      setSurvey,
      resetProgress,
      searchOpen,
      setSearchOpen,
      settingsOpen,
      setSettingsOpen,
      presentationOpen,
      setPresentationOpen,
      mobileMenuOpen,
      setMobileMenuOpen,
      introSeen,
      setIntroSeen,
      lastVisited: progress.lastVisited ?? null,
      glossaryOpen,
      setGlossaryOpen,
      bookmarksOpen,
      setBookmarksOpen,
      achievementsOpen,
      setAchievementsOpen,
      quizOpen,
      setQuizOpen,
      dashboardOpen,
      setDashboardOpen,
      isBookmarked,
      toggleBookmark,
      clearBookmarks,
      studyMode,
      setStudyMode,
      celebrate,
      celebration,
      dismissCelebration,
    }),
    [
      lang,
      setLang,
      tFn,
      theme,
      setTheme,
      resolvedTheme,
      textSize,
      setTextSize,
      reducedMotion,
      setReducedMotion,
      highContrast,
      setHighContrast,
      progress,
      markVisited,
      saveReflection,
      getReflection,
      setScenarioResult,
      setPresentationProgress,
      setSurvey,
      resetProgress,
      searchOpen,
      settingsOpen,
      presentationOpen,
      mobileMenuOpen,
      introSeen,
      setIntroSeen,
      progress.lastVisited,
      progress.bookmarks,
      glossaryOpen,
      bookmarksOpen,
      achievementsOpen,
      quizOpen,
      dashboardOpen,
      isBookmarked,
      toggleBookmark,
      clearBookmarks,
      studyMode,
      celebrate,
      celebration,
      dismissCelebration,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
