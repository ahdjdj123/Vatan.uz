import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AppProvider } from "@/lib/contexts/app-context";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin", "latin-ext", "cyrillic"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin", "latin-ext", "cyrillic"],
});

export const metadata: Metadata = {
  title: "Vatan.uz.app — Yagona Vatan, yagona xalq",
  description:
    "O‘zbekiston 9–11 sinf o‘quvchilari uchun interaktiv ta’limiy platforma: vatan, mustaqillik, islohotlar, kiberxavfsizlik va xulosa. / Interactive educational platform on Uzbekistan: homeland, independence, reforms, cybersecurity.",
  keywords: [
    "Vatan",
    "Uzbekistan",
    "ta'lim",
    "education",
    "mustaqillik",
    "islohotlar",
    "kiberxavfsizlik",
    "cybersecurity",
  ],
  authors: [{ name: "Vatan.uz.app student team" }],
  openGraph: {
    title: "Vatan.uz.app — Yagona Vatan, yagona xalq",
    description: "Interaktiv ta’limiy platforma.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="uz" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground min-h-screen`}
      >
        <AppProvider>{children}</AppProvider>
        <Toaster />
      </body>
    </html>
  );
}
