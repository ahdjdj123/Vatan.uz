"use client";

import { useEffect } from "react";
import dynamic from "next/dynamic";
import { Header } from "@/components/site/header";
import { Hero } from "@/components/site/hero";
import { Section01Vatan } from "@/components/site/sections/section-01-vatan";
import { Section02Mustaqillik } from "@/components/site/sections/section-02-mustaqillik";
import { Section03Islohotlar } from "@/components/site/sections/section-03-islohotlar";
import { Section04Kiber } from "@/components/site/sections/section-04-kiber";
import { Section05Xulosa } from "@/components/site/sections/section-05-xulosa";
import { SourcesSection, FAQSection, AboutSection } from "@/components/site/info-sections";
import { Footer } from "@/components/site/footer";
import { IntroExperience } from "@/components/site/intro-experience";
import { CelebrationToast } from "@/components/site/celebration-toast";
import { SectionDivider } from "@/components/site/section-divider";
import { useApp } from "@/lib/contexts/app-context";

// Lazy-load heavy modals (only mounted when opened)
const SearchModal = dynamic(() => import("@/components/site/search-modal").then(m => ({ default: m.SearchModal })), { ssr: false });
const SettingsPanel = dynamic(() => import("@/components/site/settings-panel").then(m => ({ default: m.SettingsPanel })), { ssr: false });
const PresentationMode = dynamic(() => import("@/components/site/presentation-mode").then(m => ({ default: m.PresentationMode })), { ssr: false });
const GlossaryModal = dynamic(() => import("@/components/site/glossary-modal").then(m => ({ default: m.GlossaryModal })), { ssr: false });
const BookmarksModal = dynamic(() => import("@/components/site/bookmarks-modal").then(m => ({ default: m.BookmarksModal })), { ssr: false });
const AchievementsModal = dynamic(() => import("@/components/site/achievements-modal").then(m => ({ default: m.AchievementsModal })), { ssr: false });
const MiniQuiz = dynamic(() => import("@/components/site/mini-quiz").then(m => ({ default: m.MiniQuiz })), { ssr: false });
const ProgressDashboard = dynamic(() => import("@/components/site/progress-dashboard").then(m => ({ default: m.ProgressDashboard })), { ssr: false });
const KeyboardShortcuts = dynamic(() => import("@/components/site/keyboard-shortcuts").then(m => ({ default: m.KeyboardShortcuts })), { ssr: false });
const ResumeBanner = dynamic(() => import("@/components/site/resume-banner").then(m => ({ default: m.ResumeBanner })), { ssr: false });
const ProjectMap = dynamic(() => import("@/components/site/project-map").then(m => ({ default: m.ProjectMap })), { ssr: false });

export default function Home() {
  const { markVisited, t } = useApp();

  // Mark hero visited on mount
  useEffect(() => {
    markVisited("hero");
  }, [markVisited]);

  return (
    <div className="relative flex min-h-screen flex-col bg-background overflow-x-hidden">
      {/* Skip to content — accessibility */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[90] focus:px-4 focus:py-2 focus:rounded-md focus:bg-[var(--vatan-blue)] focus:text-white focus:text-[13px] focus:font-medium focus:shadow-lg"
      >
        {t("a11y.skip")}
      </a>

      <IntroExperience />
      <Header />
      <main id="main-content" className="flex-1">
        <Hero />
        <Section01Vatan />
        <SectionDivider nextSectionId="s2" nextSectionNum="02" nextSectionKey="nav.02" />
        <Section02Mustaqillik />
        <SectionDivider nextSectionId="s3" nextSectionNum="03" nextSectionKey="nav.03" />
        <Section03Islohotlar />
        <SectionDivider nextSectionId="s4" nextSectionNum="04" nextSectionKey="nav.04" />
        <Section04Kiber />
        <SectionDivider nextSectionId="s5" nextSectionNum="05" nextSectionKey="nav.05" />
        <Section05Xulosa />
        <SectionDivider />
        <SourcesSection />
        <FAQSection />
        <AboutSection />
      </main>
      <Footer />
      <ProjectMap />

      {/* Overlays */}
      <SearchModal />
      <SettingsPanel />
      <PresentationMode />
      <GlossaryModal />
      <BookmarksModal />
      <AchievementsModal />
      <MiniQuiz />
      <ProgressDashboard />
      <CelebrationToast />
      <ResumeBanner />
      <KeyboardShortcuts />
    </div>
  );
}
