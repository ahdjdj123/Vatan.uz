"use client";

import React, { useEffect } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { scrollToSection } from "@/lib/use-active-section";
import { Bookmark, X, Trash2, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { DiamondCluster } from "@/components/site/motifs";

const SECTIONS = [
  { id: "s1", num: "01", key: "nav.01" },
  { id: "s2", num: "02", key: "nav.02" },
  { id: "s3", num: "03", key: "nav.03" },
  { id: "s4", num: "04", key: "nav.04" },
  { id: "s5", num: "05", key: "nav.05" },
] as const;

export function BookmarksModal() {
  const { t, bookmarksOpen, setBookmarksOpen, progress, toggleBookmark, clearBookmarks } = useApp();

  useEffect(() => {
    if (!bookmarksOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setBookmarksOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [bookmarksOpen, setBookmarksOpen]);

  if (!bookmarksOpen) return null;

  const bookmarked = SECTIONS.filter((s) => progress.bookmarks.includes(s.id));

  const onClear = () => {
    if (window.confirm(t("bookmark.clear.confirm"))) {
      clearBookmarks();
    }
  };

  return (
    <div
      className="fixed inset-0 z-[70] flex items-start sm:items-center justify-center pt-[8vh] sm:pt-0 px-4"
      role="dialog"
      aria-modal="true"
      aria-label={t("bookmark.title")}
    >
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
        onClick={() => setBookmarksOpen(false)}
      />
      <div className="relative w-full max-w-lg rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise max-h-[84vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center">
              <Bookmark className="w-4 h-4 fill-current" />
            </div>
            <div>
              <div className="text-[10px] eyebrow text-[var(--vatan-blue)] font-semibold">
                {t("bookmark.eyebrow")}
              </div>
              <h2 className="text-[16px] font-semibold text-foreground">
                {t("bookmark.title")}
              </h2>
            </div>
          </div>
          <button
            onClick={() => setBookmarksOpen(false)}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("common.close")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto vatan-scroll p-4">
          {bookmarked.length === 0 ? (
            <div className="px-4 py-12 text-center">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-muted/60 text-muted-foreground mb-3">
                <Bookmark className="w-6 h-6" />
              </div>
              <p className="text-[13.5px] text-muted-foreground leading-relaxed max-w-[320px] mx-auto">
                {t("bookmark.empty")}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {bookmarked.map((s) => (
                <div
                  key={s.id}
                  className="group flex items-center gap-3 rounded-xl border border-border bg-card/60 p-3.5 hover:border-[var(--vatan-blue)]/40 hover:bg-card transition-all vatan-rise"
                >
                  <span className="font-mono text-[12px] text-[var(--vatan-blue)] tabular-nums w-7 shrink-0">
                    {s.num}
                  </span>
                  <button
                    onClick={() => {
                      setBookmarksOpen(false);
                      setTimeout(() => scrollToSection(s.id), 80);
                    }}
                    className="flex-1 min-w-0 flex items-center gap-2 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                  >
                    <span className="text-[14.5px] font-medium text-foreground truncate">
                      {t(s.key)}
                    </span>
                    <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                  <button
                    onClick={() => toggleBookmark(s.id)}
                    className="p-1.5 rounded-md text-[var(--vatan-blue)] hover:bg-[var(--vatan-blue-soft)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    aria-label={t("bookmark.remove")}
                  >
                    <Bookmark className="w-4 h-4 fill-current" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground shrink-0">
          <div className="flex items-center gap-2">
            <DiamondCluster className="w-3 h-3 text-[var(--vatan-brass)]/60" />
            <span className="tabular-nums">
              {bookmarked.length} {t("bookmark.count")}
            </span>
          </div>
          {bookmarked.length > 0 && (
            <button
              onClick={onClear}
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-[var(--vatan-red)] hover:bg-[var(--vatan-red-soft)]/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <Trash2 className="w-3 h-3" />
              {t("bookmark.clear")}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
