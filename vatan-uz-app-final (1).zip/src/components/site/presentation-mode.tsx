"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { ChevronLeft, ChevronRight, X, Maximize2, Minimize2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { SunRaysMotif, HumoCurveMotif } from "@/components/site/motifs";
import { CYBER_SCENARIOS } from "@/lib/content";

type Visual = "values" | "timeline" | "reform" | "scenarios" | "conclusions";

interface Slide {
  /** presentation content key prefix, e.g. "pres.s1.1" */
  key: string;
  section: string; // s1..s5
  num: string; // 01..05
  total: number;
  /** optional visual layout */
  visual?: Visual;
  /** explicit bullet keys to render as concise points */
  bullets?: string[];
  /** whether to show the takeaway block */
  takeaway?: boolean;
}

const SLIDES: Slide[] = [
  // S1
  { key: "pres.s1.1", section: "s1", num: "01", total: 5, bullets: ["pres.s1.1.b1", "pres.s1.1.b2", "pres.s1.1.b3"], takeaway: true },
  { key: "pres.s1.2", section: "s1", num: "01", total: 5, visual: "values" },
  { key: "pres.s1.3", section: "s1", num: "01", total: 5, bullets: ["pres.s1.3.b1", "pres.s1.3.b2", "pres.s1.3.b3"] },
  // S2
  { key: "pres.s2.1", section: "s2", num: "02", total: 5, bullets: ["pres.s2.1.b1", "pres.s2.1.b2"], takeaway: true },
  { key: "pres.s2.2", section: "s2", num: "02", total: 5, visual: "timeline" },
  // S3
  { key: "pres.s3.1", section: "s3", num: "03", total: 5, bullets: ["pres.s3.1.b1", "pres.s3.1.b2", "pres.s3.1.b3"], takeaway: true },
  { key: "pres.s3.2", section: "s3", num: "03", total: 5, visual: "reform" },
  // S4
  { key: "pres.s4.1", section: "s4", num: "04", total: 5, bullets: ["pres.s4.1.b1", "pres.s4.1.b2"], takeaway: true },
  { key: "pres.s4.2", section: "s4", num: "04", total: 5, visual: "scenarios" },
  { key: "pres.s4.3", section: "s4", num: "04", total: 5, bullets: ["pres.s4.3.b1", "pres.s4.3.b2", "pres.s4.3.b3"] },
  // S5
  { key: "pres.s5.1", section: "s5", num: "05", total: 5, bullets: ["pres.s5.1.b1", "pres.s5.1.b2"], takeaway: true },
  { key: "pres.s5.2", section: "s5", num: "05", total: 5, visual: "conclusions" },
];

export function PresentationMode() {
  const { t, lang, presentationOpen, setPresentationOpen, setPresentationProgress, reducedMotion } = useApp();
  const [idx, setIdx] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);

  const slide = SLIDES[idx];
  const sectionSlides = SLIDES.filter((s) => s.num === slide.num);
  const sectionSlideIdx = sectionSlides.findIndex((s) => s === slide);

  const goNext = useCallback(() => {
    setIdx((i) => {
      const next = Math.min(i + 1, SLIDES.length - 1);
      setPresentationProgress(next + 1);
      return next;
    });
  }, [setPresentationProgress]);

  const goPrev = useCallback(() => {
    setIdx((i) => Math.max(i - 1, 0));
  }, []);

  // Open: reset to start
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (presentationOpen) setIdx(0);
  }, [presentationOpen]);

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen?.().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen?.().then(() => setIsFullscreen(false)).catch(() => {});
    }
  }, []);

  useEffect(() => {
    const onFs = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const accentColor = useMemo(() => {
    switch (slide.section) {
      case "s3": return "var(--vatan-green)";
      case "s5": return "var(--vatan-brass)";
      default: return "var(--vatan-blue)";
    }
  }, [slide.section]);

  // Keyboard
  useEffect(() => {
    if (!presentationOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setPresentationOpen(false);
      else if (e.key === "ArrowRight" || e.key === " " || e.key === "PageDown") {
        e.preventDefault();
        goNext();
      } else if (e.key === "ArrowLeft" || e.key === "PageUp") {
        e.preventDefault();
        goPrev();
      } else if (e.key === "Home") setIdx(0);
      else if (e.key === "End") setIdx(SLIDES.length - 1);
      else if (e.key.toLowerCase() === "f") toggleFullscreen();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [presentationOpen, goNext, goPrev, setPresentationOpen, toggleFullscreen]);

  if (!presentationOpen) return null;

  const progressPct = ((idx + 1) / SLIDES.length) * 100;
  const rise = reducedMotion ? "" : "vatan-rise";

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[80] bg-[var(--vatan-ivory)] dark:bg-[#14181A] text-foreground flex flex-col vatan-rise"
      role="dialog"
      aria-modal="true"
      aria-label={t("pres.title")}
    >
      {/* Background motifs */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        <SunRaysMotif className="absolute -top-32 -right-32 w-[700px] h-[700px] text-[var(--vatan-brass)] opacity-[0.06]" />
        <HumoCurveMotif className="absolute -bottom-12 -left-12 w-[500px] h-[240px] text-[var(--vatan-blue)] opacity-[0.06]" />
      </div>

      {/* Top bar */}
      <div className="relative z-10 flex items-center justify-between px-4 sm:px-8 py-3.5 border-b border-border/60 shrink-0">
        <div className="flex items-center gap-2.5 sm:gap-3">
          <span
            className="font-mono text-[11px] sm:text-[12px] font-bold tabular-nums px-2 py-1 rounded"
            style={{ color: accentColor, backgroundColor: `color-mix(in srgb, ${accentColor} 14%, transparent)` }}
          >
            {slide.num} {t("pres.of")} 0{slide.total}
          </span>
          <span className="text-[11px] sm:text-[12px] eyebrow text-muted-foreground hidden sm:block">
            {t("pres.title")}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("pres.fullscreen")}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setPresentationOpen(false)}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("pres.exit")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress bar */}
      <div className="relative z-10 h-1 w-full bg-muted/40 shrink-0" role="progressbar" aria-valuenow={idx + 1} aria-valuemin={1} aria-valuemax={SLIDES.length} aria-label={t("pres.progress")}>
        <div
          className="h-full transition-all duration-500 ease-out"
          style={{ width: `${progressPct}%`, backgroundColor: accentColor }}
        />
      </div>

      {/* Slide content */}
      <div className="relative z-10 flex-1 overflow-y-auto vatan-scroll">
        <div className="mx-auto max-w-5xl px-5 sm:px-10 py-8 sm:py-14">
          {/* Section number + slide indicator */}
          <div className="flex items-center gap-3 mb-5 sm:mb-6">
            <span className="font-mono text-[13px] sm:text-[14px] font-semibold tabular-nums" style={{ color: accentColor }}>
              {slide.num}
            </span>
            <span className="h-px w-10 sm:w-12" style={{ backgroundColor: accentColor }} />
            <span className="eyebrow text-[10px] sm:text-[11px] font-semibold" style={{ color: accentColor }}>
              {t(`${slide.section}.eyebrow`).replace(/^\d+\s·\s/, "")}
            </span>
            <span className="text-[11px] text-muted-foreground ml-auto font-mono tabular-nums">
              {sectionSlideIdx + 1}/{sectionSlides.length}
            </span>
          </div>

          {/* Title */}
          <h2
            key={`title-${idx}`}
            className={cn("display-heading font-semibold text-foreground leading-[1.02] mb-4 sm:mb-5", rise)}
            style={{ fontSize: "clamp(32px, 6vw, 72px)" }}
          >
            {t(`${slide.key}.title`)}
          </h2>

          {/* Lead */}
          <p
            key={`lead-${idx}`}
            className={cn("text-[var(--vatan-slate)] max-w-3xl mb-7 sm:mb-8", rise)}
            style={{ fontSize: "clamp(17px, 2.2vw, 24px)", lineHeight: 1.45 }}
          >
            {t(`${slide.key}.lead`)}
          </p>

          {/* Visuals */}
          {slide.visual === "values" && <ValuesVisual accent={accentColor} rise={rise} />}
          {slide.visual === "timeline" && <TimelineVisual accent={accentColor} rise={rise} />}
          {slide.visual === "reform" && <ReformVisual accent={accentColor} rise={rise} />}
          {slide.visual === "scenarios" && <ScenariosVisual accent={accentColor} rise={rise} />}
          {slide.visual === "conclusions" && <ConclusionsVisual accent={accentColor} rise={rise} />}

          {/* Bullets */}
          {!slide.visual && slide.bullets && slide.bullets.length > 0 && (
            <div className="mt-2 space-y-3.5">
              {slide.bullets.map((b, i) => (
                <div
                  key={`${idx}-b-${i}`}
                  className={cn("flex items-start gap-3.5", rise)}
                  style={{ animationDelay: `${i * 70}ms` }}
                >
                  <span
                    className="shrink-0 mt-2 w-6 h-6 rounded-md flex items-center justify-center font-mono text-[11px] font-bold"
                    style={{ color: accentColor, backgroundColor: `color-mix(in srgb, ${accentColor} 12%, transparent)` }}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <p className="text-foreground leading-snug" style={{ fontSize: "clamp(16px, 2vw, 20px)" }}>
                    {t(b)}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* Takeaway */}
          {slide.takeaway && (
            <div
              className={cn("mt-8 sm:mt-10 rounded-2xl border-l-2 p-5 sm:p-6", rise)}
              style={{
                borderColor: accentColor,
                backgroundColor: `color-mix(in srgb, ${accentColor} 8%, transparent)`,
              }}
            >
              <div className="flex items-start gap-3">
                <span
                  className="eyebrow text-[10px] font-bold shrink-0 mt-1"
                  style={{ color: accentColor }}
                >
                  {t("pres.takeaway.label")}
                </span>
                <p className="text-foreground font-medium leading-relaxed" style={{ fontSize: "clamp(15px, 1.8vw, 18px)" }}>
                  {t(`${slide.key}.takeaway`)}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom controls */}
      <div className="relative z-10 flex items-center justify-between gap-2 px-3 sm:px-8 py-3.5 border-t border-border/60 shrink-0">
        <button
          onClick={goPrev}
          disabled={idx === 0}
          className="inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2.5 rounded-lg text-[13px] font-medium text-foreground hover:bg-muted/60 disabled:opacity-30 disabled:hover:bg-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          <ChevronLeft className="w-4 h-4" />
          <span className="hidden sm:inline">{t("pres.prev")}</span>
        </button>

        {/* Dot navigation (scrollable on mobile) */}
        <div className="flex items-center gap-1.5 overflow-x-auto vatan-scroll max-w-[40%] sm:max-w-none py-1">
          {SLIDES.map((s, i) => (
            <button
              key={i}
              onClick={() => setIdx(i)}
              className={cn(
                "h-1.5 rounded-full transition-all shrink-0",
                i === idx ? "w-6 sm:w-8" : "w-1.5 hover:w-3",
                i <= idx ? "" : "opacity-40"
              )}
              style={{ backgroundColor: i === idx ? accentColor : "var(--muted-foreground)" }}
              aria-label={`${t("pres.section.of")} ${i + 1}`}
              aria-current={i === idx}
            />
          ))}
        </div>

        <div className="flex items-center gap-2 sm:gap-3">
          <span className="hidden sm:inline text-[11px] text-muted-foreground font-mono tabular-nums">
            {idx + 1} / {SLIDES.length}
          </span>
          <button
            onClick={goNext}
            disabled={idx === SLIDES.length - 1}
            className="inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2.5 rounded-lg text-[13px] font-medium text-white transition-colors disabled:opacity-30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            style={{ backgroundColor: accentColor }}
          >
            <span className="hidden sm:inline">{t("pres.next")}</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Keyboard hint */}
      <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 text-[10px] text-muted-foreground/60 hidden lg:block pointer-events-none">
        {t("pres.kbd")}
      </div>
    </div>
  );
}

function ValuesVisual({ accent, rise }: { accent: string; rise: string }) {
  const { t } = useApp();
  const values = [
    "s1.values.vatan", "s1.values.tinchlik", "s1.values.hamjihatlik",
    "s1.values.bagrikenglik", "s1.values.hurmat", "s1.values.tarix",
    "s1.values.meros", "s1.values.qadriyatlar", "s1.values.kelajak",
  ];
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 sm:gap-3 mt-6 sm:mt-8">
      {values.map((b, i) => (
        <div
          key={b}
          className={cn("rounded-xl border border-border bg-card/60 p-3.5 sm:p-4", rise)}
          style={{ animationDelay: `${i * 45}ms` }}
        >
          <span className="font-mono text-[11px] tabular-nums block mb-1.5" style={{ color: accent }}>
            {String(i + 1).padStart(2, "0")}
          </span>
          <p className="text-[13.5px] sm:text-[14px] font-semibold text-foreground">{t(b)}</p>
          <p className="text-[11.5px] sm:text-[12px] text-muted-foreground leading-relaxed mt-1">{t(`${b}.d`)}</p>
        </div>
      ))}
    </div>
  );
}

function TimelineVisual({ accent, rise }: { accent: string; rise: string }) {
  const { t } = useApp();
  const gains = [
    "s2.gains.davlat", "s2.gains.ramzlar", "s2.gains.til",
    "s2.gains.talim", "s2.gains.fan", "s2.gains.xalqaro", "s2.gains.huquq",
  ];
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3 mt-6 sm:mt-8">
      {gains.map((b, i) => (
        <div
          key={b}
          className={cn("rounded-xl border border-border bg-card/60 p-4", rise)}
          style={{ animationDelay: `${i * 45}ms` }}
        >
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: accent }} />
            <span className="text-[10px] eyebrow text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
          </div>
          <p className="text-[14px] sm:text-[15px] font-semibold text-foreground">{t(b)}</p>
          <p className="text-[12px] sm:text-[12.5px] text-muted-foreground leading-relaxed mt-1">{t(`${b}.d`)}</p>
        </div>
      ))}
    </div>
  );
}

function ReformVisual({ accent, rise }: { accent: string; rise: string }) {
  const { t } = useApp();
  const areas = ["education", "healthcare", "digital", "business", "youth"];
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2.5 sm:gap-3 mt-6 sm:mt-8">
      {areas.map((a, i) => (
        <div
          key={a}
          className={cn("rounded-xl border border-border bg-card/60 p-4 sm:p-5", rise)}
          style={{ animationDelay: `${i * 55}ms` }}
        >
          <span className="font-mono text-[20px] sm:text-[24px] font-bold tabular-nums block mb-1" style={{ color: accent, opacity: 0.3 }}>
            {String(i + 1).padStart(2, "0")}
          </span>
          <p className="text-[15px] sm:text-[16px] font-semibold text-foreground mb-2">{t(`s3.area.${a}`)}</p>
          <div className="space-y-1.5 text-[11.5px] sm:text-[12.5px]">
            <p className="text-[var(--vatan-red)] leading-snug">
              <span className="eyebrow mr-1">{t("s3.framework.problem")}:</span>
              {t(`s3.area.${a}.p`)}
            </p>
            <p className="text-[var(--vatan-blue)] leading-snug">
              <span className="eyebrow mr-1">{t("s3.framework.solution")}:</span>
              {t(`s3.area.${a}.s`)}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

function ScenariosVisual({ accent, rise }: { accent: string; rise: string }) {
  const { t, lang } = useApp();
  return (
    <div className="mt-6 sm:mt-8 grid sm:grid-cols-2 gap-2.5 sm:gap-3">
      {CYBER_SCENARIOS.map((sc, i) => (
        <div
          key={sc.id}
          className={cn("rounded-xl border border-border bg-card/60 p-4 sm:p-5", rise)}
          style={{ animationDelay: `${i * 65}ms` }}
        >
          <div className="flex items-center gap-2 mb-3">
            <span
              className="w-7 h-7 rounded-full flex items-center justify-center font-mono text-[12px] font-bold text-white"
              style={{ backgroundColor: accent }}
            >
              {i + 1}
            </span>
            <span className="text-[10px] eyebrow text-muted-foreground">{t("s4.scenario.progress")}</span>
          </div>
          <p className="text-[13.5px] sm:text-[14.5px] text-foreground leading-relaxed mb-3">{sc.question[lang]}</p>
          <div className="space-y-1">
            {sc.options.map((opt, j) => (
              <div key={j} className="flex items-center gap-2 text-[12px] sm:text-[12.5px]">
                <span
                  className={cn(
                    "w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold shrink-0",
                    opt.correct ? "bg-[var(--vatan-green)] text-white" : "bg-muted text-muted-foreground"
                  )}
                >
                  {String.fromCharCode(65 + j)}
                </span>
                <span className={opt.correct ? "text-foreground font-medium" : "text-muted-foreground"}>
                  {opt.text[lang]}
                </span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function ConclusionsVisual({ accent, rise }: { accent: string; rise: string }) {
  const { t } = useApp();
  const items = ["s5.conclusions.1", "s5.conclusions.2", "s5.conclusions.3", "s5.conclusions.4", "s5.conclusions.5"];
  return (
    <div className="mt-6 sm:mt-8 space-y-2.5 sm:space-y-3">
      {items.map((b, i) => (
        <div
          key={b}
          className={cn("flex items-center gap-4 rounded-xl border border-border bg-card/60 p-4 sm:p-5", rise)}
          style={{ animationDelay: `${i * 65}ms` }}
        >
          <span
            className="font-mono font-bold tabular-nums shrink-0"
            style={{ color: accent, opacity: 0.3, fontSize: "clamp(28px, 4vw, 40px)" }}
          >
            {String(i + 1).padStart(2, "0")}
          </span>
          <p className="font-medium text-foreground leading-snug" style={{ fontSize: "clamp(15px, 2vw, 20px)" }}>
            {t(b)}
          </p>
        </div>
      ))}
    </div>
  );
}
