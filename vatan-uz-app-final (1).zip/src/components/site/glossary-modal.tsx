"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { BookOpen, X, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { DiamondCluster } from "@/components/site/motifs";

const TERMS = [
  "vatan",
  "mustaqillik",
  "islohot",
  "kiberxavfsizlik",
  "fishing",
  "parol",
  "haq",
  "meros",
  "hamjihatlik",
  "bagrikenglik",
  "taqdimot",
  "davlat",
  "konstitutsiya",
  "bayroq",
  "gerb",
  "madhiya",
  "VPN",
  "malware",
  "shifrlash",
  "profilaktika",
] as const;

export function GlossaryModal() {
  const { t, glossaryOpen, setGlossaryOpen, celebrate, progress } = useApp();
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (glossaryOpen) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setQuery("");
      setTimeout(() => inputRef.current?.focus(), 60);
      // Celebrate first glossary open (for Scholar achievement)
      if (!progress.celebratedSections.includes("glossary-opened")) {
        celebrate("glossary-opened", "ach.scholar.title");
      }
    }
  }, [glossaryOpen, celebrate, progress.celebratedSections]);

  useEffect(() => {
    if (!glossaryOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setGlossaryOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [glossaryOpen, setGlossaryOpen]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return TERMS;
    return TERMS.filter((term) => {
      const title = t(`term.${term}`).toLowerCase();
      const desc = t(`term.${term}.d`).toLowerCase();
      return title.includes(q) || desc.includes(q) || term.includes(q);
    });
  }, [query, t]);

  if (!glossaryOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-start justify-center pt-[8vh] px-4"
      role="dialog"
      aria-modal="true"
      aria-label={t("glossary.title")}
    >
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
        onClick={() => setGlossaryOpen(false)}
      />
      <div className="relative w-full max-w-2xl rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise max-h-[84vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center">
              <BookOpen className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] eyebrow text-[var(--vatan-blue)] font-semibold">
                {t("glossary.eyebrow")}
              </div>
              <h2 className="text-[16px] font-semibold text-foreground">
                {t("glossary.title")}
              </h2>
            </div>
          </div>
          <button
            onClick={() => setGlossaryOpen(false)}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("common.close")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search */}
        <div className="px-5 py-3 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5 rounded-lg border border-border bg-background/60 px-3 py-2">
            <Search className="w-4 h-4 text-muted-foreground shrink-0" />
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("glossary.search")}
              className="flex-1 bg-transparent text-[14px] text-foreground placeholder:text-muted-foreground focus:outline-none"
              aria-label={t("glossary.search")}
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="text-[11px] text-muted-foreground hover:text-foreground px-1.5"
                aria-label={t("common.clear")}
              >
                ✕
              </button>
            )}
          </div>
          <p className="mt-2 text-[11.5px] text-muted-foreground">{t("glossary.hint")}</p>
        </div>

        {/* Terms list */}
        <div className="flex-1 overflow-y-auto vatan-scroll p-4">
          {filtered.length === 0 ? (
            <div className="px-4 py-10 text-center">
              <p className="text-[14px] text-muted-foreground">{t("glossary.empty")}</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-2.5">
              {filtered.map((term, i) => (
                <div
                  key={term}
                  className="group rounded-xl border border-border bg-card/60 p-4 hover:border-[var(--vatan-blue)]/40 hover:bg-card transition-all vatan-rise"
                  style={{ animationDelay: `${i * 25}ms` }}
                >
                  <div className="flex items-start gap-2.5">
                    <span className="shrink-0 font-mono text-[10px] text-[var(--vatan-brass)] tabular-nums mt-1">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-[14.5px] font-semibold text-foreground mb-1">
                        {t(`term.${term}`)}
                      </h3>
                      <p className="text-[12.5px] leading-relaxed text-muted-foreground">
                        {t(`term.${term}.d`)}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-2.5 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground shrink-0">
          <div className="flex items-center gap-2">
            <DiamondCluster className="w-3 h-3 text-[var(--vatan-brass)]/60" />
            <span>{filtered.length} {filtered.length === 1 ? "term" : "terms"}</span>
          </div>
          <span className="hidden sm:block">Esc — {t("common.close").toLowerCase()}</span>
        </div>
      </div>
    </div>
  );
}
