"use client";

import React from "react";
import { SectionShell, SectionContext, ReflectionCard, Takeaway } from "@/components/site/section-shell";
import { WheatMotif, DiamondCluster } from "@/components/site/motifs";
import { useApp } from "@/lib/contexts/app-context";

const VALUES = [
  { key: "vatan", icon: "flag" },
  { key: "tinchlik", icon: "dove" },
  { key: "hamjihatlik", icon: "people" },
  { key: "bagrikenglik", icon: "open" },
  { key: "hurmat", icon: "hand" },
  { key: "tarix", icon: "scroll" },
  { key: "meros", icon: "monument" },
  { key: "qadriyatlar", icon: "gem" },
  { key: "kelajak", icon: "sun" },
] as const;

function ValueIcon({ name }: { name: string }) {
  const common = "w-5 h-5";
  switch (name) {
    case "flag":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M5 21V4M5 4l10 2-3 4 3 4-10-2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "dove":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M3 13c4-1 7-4 9-8 1 3 4 5 7 5-2 4-6 7-11 7-2 0-4-1-5-2Z" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M3 13c0 2 1 3 2 4" strokeLinecap="round" />
        </svg>
      );
    case "people":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="9" cy="8" r="3" />
          <path d="M3 20c0-3 3-5 6-5s6 2 6 5" strokeLinecap="round" />
          <circle cx="17" cy="9" r="2.5" />
          <path d="M14 16c2-1 5-1 7 1" strokeLinecap="round" />
        </svg>
      );
    case "open":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 21V9M5 9l7-5 7 5M7 11v6h10v-6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "hand":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M6 11V6.5a1.5 1.5 0 013 0V11M9 11V5a1.5 1.5 0 013 0v6M12 11V6a1.5 1.5 0 013 0v5M15 11V8a1.5 1.5 0 013 0v7c0 3-2 6-6 6s-6-2-7-5l-2-4c-.5-1 .5-2 1.5-1.5L6 12" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "scroll":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M6 4h12v14a3 3 0 01-3 3H6zM6 4a2 2 0 00-2 2v2h2M18 4a2 2 0 012 2v2h-2M9 9h6M9 13h6M9 17h3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "monument":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 3l4 4-4 2-4-2 4-4ZM8 9l-2 12M16 9l2 12M7 21h10M10 13v8M14 13v8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "gem":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M6 3h12l4 6-10 12L2 9l4-6ZM2 9h20M9 3l-3 6 6 12M15 3l3 6-6 12" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "sun":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2" strokeLinecap="round" />
        </svg>
      );
    default:
      return null;
  }
}

export function Section01Vatan() {
  return (
    <SectionShell
      id="s1"
      num="01"
      eyebrowKey="s1.eyebrow"
      titleKey="s1.title"
      leadKey="s1.lead"
      accent="blue"
      readMinutes={4}
      decorative={
        <div className="pointer-events-none absolute top-20 right-0 w-px h-32 bg-gradient-to-b from-transparent via-[var(--vatan-brass)]/30 to-transparent" aria-hidden="true" />
      }
      factVariant={1}
    >
      <SectionContext titleKey="s1.context.title" bodyKey="s1.context.body" />

      {/* Values grid */}
      <ValuesGrid />

      <ReflectionCard
        storageKey="s1.reflection"
        eyebrowKey="s1.reflect.eyebrow"
        titleKey="s1.reflect.title"
        hintKey="s1.reflect.hint"
        placeholderKey="s1.reflect.placeholder"
      />

      <Takeaway>
        <ReflectionTakeaway />
      </Takeaway>
    </SectionShell>
  );
}

function ValuesGrid() {
  const { t } = useApp();
  return (
    <div className="mt-14">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-[15px] eyebrow text-muted-foreground font-semibold">
          {t("s1.values.title")}
        </h3>
        <DiamondCluster className="w-4 h-4 text-[var(--vatan-brass)]/70" />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 [grid-auto-rows:1fr]">
        {VALUES.map((v, i) => (
          <div
            key={v.key}
            className="group relative rounded-xl border border-border bg-card/60 p-5 hover:border-[var(--vatan-blue)]/40 hover:bg-card hover:shadow-[0_8px_24px_-12px_rgba(30,115,190,0.18)] transition-all duration-300 flex flex-col"
            style={{ animationDelay: `${i * 30}ms` }}
          >
            <div className="flex items-start gap-3.5 flex-1">
              <div className="shrink-0 w-10 h-10 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center group-hover:bg-[var(--vatan-blue)] group-hover:text-white transition-colors">
                <ValueIcon name={v.icon} />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="text-[15px] font-semibold text-foreground mb-1">
                  {t(`s1.values.${v.key}`)}
                </h4>
                <p className="text-[13px] leading-relaxed text-muted-foreground">
                  {t(`s1.values.${v.key}.d`)}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Subtle wheat motif at the corner of grid area */}
      <div className="pointer-events-none hidden lg:block absolute right-6 -mt-2 w-16 h-32 opacity-20 text-[var(--vatan-brass)]">
        <WheatMotif className="w-full h-full" />
      </div>
    </div>
  );
}

function ReflectionTakeaway() {
  const { t } = useApp();
  return <>{t("s1.reflect.takeaway")}</>;
}
