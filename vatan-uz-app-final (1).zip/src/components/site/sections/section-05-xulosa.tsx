"use client";

import React, { useEffect, useState } from "react";
import { SectionShell, Takeaway, ReflectionCard } from "@/components/site/section-shell";
import { useApp } from "@/lib/contexts/app-context";
import { SunRaysMotif, DiamondCluster, CottonMotif } from "@/components/site/motifs";
import { BarChart3, BookOpen, Trash2, Plus, Star, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import type { SurveyQuestion } from "@/lib/contexts/app-context";

const DEMO_SURVEY: SurveyQuestion[] = [
  {
    id: "demo1",
    question: "demo", // replaced by translation in render
    options: [
      { label: "A", count: 0 },
      { label: "B", count: 0 },
      { label: "C", count: 0 },
    ],
  },
];

const CONCLUSIONS = [
  "s5.conclusions.1",
  "s5.conclusions.2",
  "s5.conclusions.3",
  "s5.conclusions.4",
  "s5.conclusions.5",
] as const;

export function Section05Xulosa() {
  const { t, lang, progress, setSurvey } = useApp();
  const [mode, setMode] = useState<"demo" | "real">("demo");

  // Demo survey content translated
  const demoSurvey: SurveyQuestion[] = [
    {
      id: "demo-q1",
      question: lang === "uz"
        ? "Sizningcha, bizni yagona xalq sifatida nima birlashtiradi?"
        : lang === "en"
        ? "What unites us as one people?"
        : "Что, по-вашему, объединяет нас как единый народ?",
      options: [
        { label: lang === "uz" ? "Umumiy tarix" : lang === "en" ? "Shared history" : "Общая история", count: 12 },
        { label: lang === "uz" ? "Til va madaniyat" : lang === "en" ? "Language and culture" : "Язык и культура", count: 9 },
        { label: lang === "uz" ? "Umumiy kelajak" : lang === "en" ? "Shared future" : "Общее будущее", count: 7 },
      ],
    },
    {
      id: "demo-q2",
      question: lang === "uz"
        ? "Kiberxavfsizlik bo‘yicha eng muhim qoida?"
        : lang === "en"
        ? "Most important cybersecurity rule?"
        : "Самое важное правило кибербезопасности?",
      options: [
        { label: lang === "uz" ? "Kuchli parol" : lang === "en" ? "Strong password" : "Надёжный пароль", count: 14 },
        { label: lang === "uz" ? "Shubhali havolalardan qochish" : lang === "en" ? "Avoid suspicious links" : "Избегать подозрительных ссылок", count: 11 },
        { label: lang === "uz" ? "Shaxsiy ma’lumotni bermaslik" : lang === "en" ? "Don't share personal data" : "Не давать личные данные", count: 3 },
      ],
    },
  ];

  const realSurvey = progress.survey ?? [];
  const shown = mode === "demo" ? demoSurvey : realSurvey;

  const [newQ, setNewQ] = useState("");
  const [newOpts, setNewOpts] = useState(["", ""]);

  const addSurvey = () => {
    if (!newQ.trim() || newOpts.filter((o) => o.trim()).length < 2) return;
    const q: SurveyQuestion = {
      id: `q-${Date.now()}`,
      question: newQ.trim(),
      options: newOpts
        .filter((o) => o.trim())
        .map((o) => ({ label: o.trim(), count: 0 })),
    };
    setSurvey([...realSurvey, q]);
    setNewQ("");
    setNewOpts(["", ""]);
  };

  const updateOptCount = (qId: string, optIdx: number, delta: number) => {
    const updated = realSurvey.map((q) =>
      q.id === qId
        ? {
            ...q,
            options: q.options.map((o, i) =>
              i === optIdx ? { ...o, count: Math.max(0, o.count + delta) } : o
            ),
          }
        : q
    );
    setSurvey(updated);
  };

  const clearSurvey = () => setSurvey(null);

  return (
    <SectionShell
      id="s5"
      num="05"
      eyebrowKey="s5.eyebrow"
      titleKey="s5.title"
      leadKey="s5.lead"
      accent="brass"
      readMinutes={4}
      className="bg-gradient-to-b from-transparent via-[#F3EAD3]/30 to-transparent"
      decorative={
        <>
          <SunRaysMotif className="pointer-events-none absolute -top-10 -right-20 w-[400px] h-[400px] text-[var(--vatan-brass)] opacity-[0.08]" aria-hidden="true" />
          <CottonMotif className="pointer-events-none hidden lg:block absolute bottom-10 left-4 w-16 h-20 text-[var(--vatan-green)] opacity-[0.12]" aria-hidden="true" />
        </>
      }
      factVariant={1}
    >
      {/* Research intro */}
      <div className="mt-10 rounded-2xl border border-border bg-card/60 p-6 sm:p-7">
        <div className="flex items-start gap-4">
          <div className="hidden sm:flex shrink-0 w-11 h-11 rounded-xl bg-[var(--vatan-brass-soft)] text-[var(--vatan-brass)] items-center justify-center">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-[18px] sm:text-[20px] font-semibold text-foreground mb-2">
              {t("s5.research.title")}
            </h3>
            <p className="text-[14.5px] leading-relaxed text-muted-foreground">
              {t("s5.research.body")}
            </p>
          </div>
        </div>
      </div>

      {/* Survey visualization */}
      <div className="mt-12">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[var(--vatan-brass)]" />
            <h3 className="text-[16px] font-semibold text-foreground">
              {t("s5.survey.title")}
            </h3>
          </div>
          {/* mode switch */}
          <div className="inline-flex p-1 rounded-lg bg-muted/60 text-[12px]">
            <button
              onClick={() => setMode("demo")}
              className={cn(
                "px-3 py-1.5 rounded-md font-medium transition-colors",
                mode === "demo"
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t("s5.survey.demo")}
            </button>
            <button
              onClick={() => setMode("real")}
              className={cn(
                "px-3 py-1.5 rounded-md font-medium transition-colors",
                mode === "real"
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {t("s5.survey.real")}
            </button>
          </div>
        </div>
        <p className="text-[12.5px] text-muted-foreground mb-4">{t("s5.survey.hint")}</p>

        {/* Clarity banner — distinguishes demo from real data */}
        <div
          className={cn(
            "mb-5 rounded-lg border px-4 py-2.5 text-[12px] leading-relaxed flex items-start gap-2",
            mode === "demo"
              ? "border-[var(--vatan-brass)]/30 bg-[var(--vatan-brass-soft)]/40 text-[var(--vatan-brass)]"
              : "border-[var(--vatan-green)]/30 bg-[var(--vatan-green-soft)]/40 text-[var(--vatan-green)]"
          )}
        >
          <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
          <span>{mode === "demo" ? t("survey.demoBanner") : t("survey.realBanner")}</span>
        </div>

        {mode === "demo" ? (
          <div className="space-y-5">
            {demoSurvey.map((q) => (
              <SurveyCard key={q.id} q={q} demo />
            ))}
          </div>
        ) : (
          <div className="space-y-5">
            {realSurvey.length === 0 ? (
              <div className="rounded-xl border border-dashed border-border p-8 text-center text-[13px] text-muted-foreground">
                {t("s5.survey.hint")}
              </div>
            ) : (
              realSurvey.map((q) => (
                <SurveyCard
                  key={q.id}
                  q={q}
                  onCount={(optIdx, delta) => updateOptCount(q.id, optIdx, delta)}
                  onDelete={() => {
                    setSurvey(realSurvey.filter((x) => x.id !== q.id));
                  }}
                />
              ))
            )}

            {/* Add question */}
            <div className="rounded-xl border border-border bg-card/60 p-5">
              <div className="flex items-center gap-2 mb-3">
                <Plus className="w-4 h-4 text-[var(--vatan-brass)]" />
                <span className="text-[13px] font-semibold text-foreground">
                  {t("s5.survey.add")}
                </span>
              </div>
              <input
                value={newQ}
                onChange={(e) => setNewQ(e.target.value)}
                placeholder={t("s5.survey.placeholder")}
                className="w-full rounded-lg border border-border bg-background px-3 py-2.5 text-[14px] text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring mb-3"
              />
              <div className="space-y-2 mb-3">
                {newOpts.map((o, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="font-mono text-[11px] text-muted-foreground w-5">
                      {String.fromCharCode(65 + i)}
                    </span>
                    <input
                      value={o}
                      onChange={(e) => {
                        const next = [...newOpts];
                        next[i] = e.target.value;
                        setNewOpts(next);
                      }}
                      placeholder={`${t("s5.survey.option")} ${i + 1}`}
                      className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-[13px] text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                    {newOpts.length > 2 && (
                      <button
                        onClick={() => setNewOpts(newOpts.filter((_, idx) => idx !== i))}
                        className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60"
                        aria-label="remove"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between">
                <button
                  onClick={() => setNewOpts([...newOpts, ""])}
                  className="text-[12px] text-[var(--vatan-blue)] hover:underline font-medium"
                >
                  + {t("s5.survey.option")}
                </button>
                <div className="flex items-center gap-2">
                  {realSurvey.length > 0 && (
                    <button
                      onClick={clearSurvey}
                      className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md text-[12px] text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      {t("s5.survey.clear")}
                    </button>
                  )}
                  <button
                    onClick={addSurvey}
                    disabled={!newQ.trim() || newOpts.filter((o) => o.trim()).length < 2}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-md bg-[var(--vatan-brass)] text-white text-[13px] font-medium disabled:opacity-40 hover:bg-[var(--vatan-brass)]/90 transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    {t("common.save")}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Final reflection homework */}
      <div className="mt-14">
        <div className="mb-3 flex items-center gap-2">
          <Star className="w-4 h-4 text-[var(--vatan-brass)]" />
          <span className="text-[12px] eyebrow text-[var(--vatan-brass)] font-semibold">
            {t("s5.reflection.title")}
          </span>
        </div>
        <div className="rounded-2xl border border-[var(--vatan-brass)]/30 bg-gradient-to-br from-[var(--vatan-brass-soft)]/40 to-transparent p-6 mb-2">
          <p className="text-[20px] sm:text-[24px] font-semibold text-foreground leading-snug">
            “{t("s5.reflection.topic")}”
          </p>
          <p className="text-[13px] text-muted-foreground mt-2">{t("s5.reflection.hint")}</p>
        </div>
        <ReflectionCard
          storageKey="s5.reflection"
          eyebrowKey="s5.reflection.title"
          titleKey="s5.reflection.topic"
          hintKey="s5.reflection.hint"
          placeholderKey="s5.reflection.placeholder"
        />
      </div>

      {/* Conclusions */}
      <div className="mt-14">
        <div className="flex items-center gap-2 mb-5">
          <DiamondCluster className="w-4 h-4 text-[var(--vatan-brass)]" />
          <h3 className="text-[16px] font-semibold text-foreground">
            {t("s5.conclusions.title")}
          </h3>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 [grid-auto-rows:1fr]">
          {CONCLUSIONS.map((c, i) => (
            <div
              key={c}
              className="group rounded-xl border border-border bg-card/60 p-5 relative overflow-hidden hover:border-[var(--vatan-brass)]/40 hover:bg-card transition-all flex flex-col"
            >
              <span className="absolute top-3 right-3 font-mono text-[28px] font-bold text-[var(--vatan-brass)]/15 tabular-nums group-hover:text-[var(--vatan-brass)]/30 transition-colors">
                0{i + 1}
              </span>
              <p className="text-[14px] leading-relaxed text-foreground/90 relative z-10 flex-1 flex items-center">
                {t(c)}
              </p>
            </div>
          ))}
        </div>
      </div>

      <Takeaway>
        {t("s5.conclusions.5")}
      </Takeaway>
    </SectionShell>
  );
}

function SurveyCard({
  q,
  demo,
  onCount,
  onDelete,
}: {
  q: SurveyQuestion;
  demo?: boolean;
  onCount?: (optIdx: number, delta: number) => void;
  onDelete?: () => void;
}) {
  const { t } = useApp();
  const total = q.options.reduce((s, o) => s + o.count, 0);
  const max = Math.max(1, ...q.options.map((o) => o.count));

  return (
    <div className="rounded-xl border border-border bg-card/60 p-5">
      <div className="flex items-start justify-between gap-3 mb-4">
        <p className="text-[14.5px] font-semibold text-foreground leading-snug flex-1">
          {q.question}
        </p>
        {onDelete && (
          <button
            onClick={onDelete}
            className="p-1.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 shrink-0"
            aria-label="delete"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
      <div className="space-y-2.5">
        {q.options.map((o, i) => {
          const pct = total > 0 ? Math.round((o.count / total) * 100) : 0;
          const widthPct = (o.count / max) * 100;
          return (
            <div key={i}>
              <div className="flex items-center justify-between mb-1 text-[13px]">
                <span className="text-foreground/90">{o.label}</span>
                <span className="font-mono text-muted-foreground tabular-nums">
                  {o.count} · {pct}%
                </span>
              </div>
              <div className="h-2.5 rounded-full bg-muted overflow-hidden">
                <div
                  className="h-full rounded-full bg-[var(--vatan-blue)] transition-all duration-500"
                  style={{ width: `${widthPct}%` }}
                />
              </div>
              {!demo && onCount && (
                <div className="flex items-center gap-1 mt-1.5">
                  <button
                    onClick={() => onCount(i, 1)}
                    className="px-2 py-0.5 rounded text-[11px] bg-[var(--vatan-green-soft)] text-[var(--vatan-green)] hover:bg-[var(--vatan-green)] hover:text-white transition-colors font-medium"
                  >
                    +1
                  </button>
                  <button
                    onClick={() => onCount(i, -1)}
                    className="px-2 py-0.5 rounded text-[11px] bg-muted text-muted-foreground hover:bg-[var(--vatan-red-soft)] hover:text-[var(--vatan-red)] transition-colors font-medium"
                  >
                    −1
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="mt-3 pt-3 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
        <span>{demo ? "demo" : t("s5.survey.real").toLowerCase()}</span>
        <span className="font-mono tabular-nums">
          {t("s5.survey.count")}: {total}
        </span>
      </div>
    </div>
  );
}
