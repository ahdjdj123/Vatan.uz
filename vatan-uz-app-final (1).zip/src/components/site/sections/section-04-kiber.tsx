"use client";

import React, { useState } from "react";
import { SectionShell, SectionContext, Takeaway } from "@/components/site/section-shell";
import { useApp } from "@/lib/contexts/app-context";
import { CYBER_SCENARIOS } from "@/lib/content";
import { HumoCurveMotif, DiamondCluster } from "@/components/site/motifs";
import { CheckCircle2, XCircle, ChevronRight, RotateCcw, ShieldCheck } from "lucide-react";
import { cn } from "@/lib/utils";

const TOPICS = [
  { key: "data", icon: "user" },
  { key: "passwords", icon: "key" },
  { key: "strong", icon: "lock" },
  { key: "links", icon: "link" },
  { key: "phishing", icon: "fish" },
  { key: "messages", icon: "msg" },
  { key: "downloads", icon: "download" },
  { key: "social", icon: "share" },
  { key: "misinfo", icon: "alert" },
] as const;

function TopicIcon({ name, className = "w-5 h-5" }: { name: string; className?: string }) {
  switch (name) {
    case "user":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="12" cy="8" r="4" />
          <path d="M4 20c0-4 4-6 8-6s8 2 8 6" strokeLinecap="round" />
        </svg>
      );
    case "key":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="7" cy="14" r="3" />
          <path d="M9.5 11.5L20 1M16 5l3 3M14 7l3 3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "lock":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <rect x="4" y="11" width="16" height="10" rx="2" />
          <path d="M8 11V7a4 4 0 018 0v4" strokeLinecap="round" />
        </svg>
      );
    case "link":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M10 13a4 4 0 005.66 0l3-3a4 4 0 00-5.66-5.66l-1 1M14 11a4 4 0 00-5.66 0l-3 3a4 4 0 005.66 5.66l1-1" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "fish":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M3 12c3-4 8-5 12-3l5 3-5 3c-4 2-9 1-12-3ZM18 9l3-2M18 15l3 2M3 12c2 1 2 1 4 0M3 12c2-1 2-1 4 0" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "msg":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M21 12c0 4-4 7-9 7-1 0-2 0-3-.3L4 20l1.3-3.5C4 15 3 13.5 3 12c0-4 4-7 9-7s9 3 9 7Z" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "download":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 3v12M7 10l5 5 5-5M5 21h14" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "share":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="6" cy="12" r="2.5" />
          <circle cx="18" cy="6" r="2.5" />
          <circle cx="18" cy="18" r="2.5" />
          <path d="M8 11l8-4M8 13l8 4" strokeLinecap="round" />
        </svg>
      );
    case "alert":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 3l9 16H3l9-16ZM12 9v5M12 17h0" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    default:
      return null;
  }
}

export function Section04Kiber() {
  const { t, lang, setScenarioResult, progress, celebrate } = useApp();
  const [scenarioIdx, setScenarioIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  const scenario = CYBER_SCENARIOS[scenarioIdx];
  const isLast = scenarioIdx === CYBER_SCENARIOS.length - 1;
  const allAnswered = scenarioIdx >= CYBER_SCENARIOS.length;

  const onChoose = (idx: number) => {
    if (selected !== null) return;
    setSelected(idx);
    const option = scenario.options[idx];
    const newScore = option.correct ? score + 1 : score;
    if (option.correct) {
      setScore(newScore);
    }
    const newCompleted = scenarioIdx + 1;
    setScenarioResult(newScore, newCompleted);
    // Celebrate when all scenarios done
    if (newCompleted >= CYBER_SCENARIOS.length && !progress.celebratedSections.includes("quiz-done")) {
      celebrate("quiz-done", "celebrate.quizDone");
    }
  };

  const next = () => {
    if (isLast) return;
    setScenarioIdx((i) => i + 1);
    setSelected(null);
  };

  const retry = () => {
    setScenarioIdx(0);
    setSelected(null);
    setScore(0);
  };

  return (
    <SectionShell
      id="s4"
      num="04"
      eyebrowKey="s4.eyebrow"
      titleKey="s4.title"
      leadKey="s4.lead"
      accent="blue"
      readMinutes={6}
      decorative={
        <>
          <HumoCurveMotif className="pointer-events-none hidden md:block absolute top-20 right-0 w-[300px] h-[140px] text-[var(--vatan-blue)] opacity-[0.08]" aria-hidden="true" />
        </>
      }
      factVariant={1}
    >
      {/* Context banner */}
      <div className="mt-10 mb-2">
        <div className="inline-flex items-center gap-2 rounded-full bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] px-3 py-1 text-[12px] font-medium">
          <ShieldCheck className="w-3.5 h-3.5" />
          {t("s4.context")}
        </div>
      </div>

      <SectionContext titleKey="s4.topics.title" bodyKey="s4.lead" />

      {/* Topics grid */}
      <div className="mt-12">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-[15px] eyebrow text-muted-foreground font-semibold">
            {t("s4.topics.title")}
          </h3>
          <DiamondCluster className="w-4 h-4 text-[var(--vatan-blue)]/70" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 [grid-auto-rows:1fr]">
          {TOPICS.map((topic) => (
            <div
              key={topic.key}
              className="group rounded-xl border border-border bg-card/60 p-4 hover:border-[var(--vatan-blue)]/40 hover:bg-card hover:shadow-[0_8px_24px_-12px_rgba(30,115,190,0.18)] transition-all flex flex-col"
            >
              <div className="flex items-start gap-3 flex-1">
                <div className="shrink-0 w-9 h-9 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center group-hover:bg-[var(--vatan-blue)] group-hover:text-white transition-colors">
                  <TopicIcon name={topic.icon} className="w-[18px] h-[18px]" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-[14px] font-semibold text-foreground mb-0.5">
                    {t(`s4.topic.${topic.key}`)}
                  </h4>
                  <p className="text-[12.5px] leading-relaxed text-muted-foreground">
                    {t(`s4.topic.${topic.key}.d`)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interactive scenarios */}
      <div className="mt-16">
        <div className="flex items-center justify-between mb-6">
          <div>
            <span className="eyebrow text-[11px] text-[var(--vatan-blue)] font-semibold block mb-1">
              {t("s4.scenario.eyebrow")}
            </span>
            <h3 className="text-[18px] sm:text-[20px] font-semibold text-foreground">
              {t("s4.scenario.title")}
            </h3>
          </div>
          <div className="text-right">
            <div className="text-[11px] eyebrow text-muted-foreground">
              {t("s4.scenario.score")}
            </div>
            <div className="font-mono text-[20px] font-bold text-[var(--vatan-blue)] tabular-nums">
              {score}
              <span className="text-muted-foreground/50 text-[14px]">/{CYBER_SCENARIOS.length}</span>
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-card/70 p-6 sm:p-7">
          {/* progress */}
          <div className="flex items-center gap-2 mb-5">
            {CYBER_SCENARIOS.map((_, i) => (
              <div
                key={i}
                className={cn(
                  "h-1 flex-1 rounded-full transition-colors",
                  i < scenarioIdx ? "bg-[var(--vatan-green)]" :
                  i === scenarioIdx ? "bg-[var(--vatan-blue)]" : "bg-muted"
                )}
              />
            ))}
          </div>

          {progress.scenarioCompleted > 0 && progress.scenarioCompleted >= CYBER_SCENARIOS.length && allAnswered ? (
            <div className="text-center py-10">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[var(--vatan-green-soft)] text-[var(--vatan-green)] mb-4">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h4 className="text-[20px] font-semibold text-foreground mb-2">
                {t("s4.scenario.completed")}
              </h4>
              <p className="text-[14px] text-muted-foreground mb-6">
                {t("s4.scenario.score")}: <span className="font-mono font-bold text-[var(--vatan-green)]">{progress.scenarioScore}/{CYBER_SCENARIOS.length}</span>
              </p>
              <button
                onClick={retry}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border text-[14px] font-medium hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <RotateCcw className="w-4 h-4" />
                {t("s4.scenario.retry")}
              </button>
            </div>
          ) : (
            <>
              <div className="mb-2 text-[12px] eyebrow text-muted-foreground">
                {t("s4.scenario.progress")} {scenarioIdx + 1} {t("pres.of")} {CYBER_SCENARIOS.length}
              </div>
              <p className="text-[16px] sm:text-[18px] font-medium text-foreground leading-relaxed mb-2">
                {scenario.question[lang]}
              </p>
              <p className="text-[12.5px] text-muted-foreground mb-5">
                {t("s4.scenario.hint")}
              </p>

              <div className="grid sm:grid-cols-2 gap-2.5">
                {scenario.options.map((opt, i) => {
                  const isPicked = selected === i;
                  const showState = selected !== null;
                  const stateCls = showState
                    ? opt.correct
                      ? "border-[var(--vatan-green)] bg-[var(--vatan-green-soft)]/50"
                      : isPicked
                      ? "border-[var(--vatan-red)] bg-[var(--vatan-red-soft)]/40"
                      : "border-border opacity-60"
                    : "border-border hover:border-[var(--vatan-blue)]/50 hover:bg-muted/40";
                  return (
                    <button
                      key={i}
                      onClick={() => onChoose(i)}
                      disabled={selected !== null}
                      className={cn(
                        "group flex items-start gap-3 p-4 rounded-xl border text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                        stateCls
                      )}
                    >
                      <span className={cn(
                        "shrink-0 w-6 h-6 rounded-full flex items-center justify-center font-mono text-[11px] font-bold border",
                        showState && opt.correct
                          ? "bg-[var(--vatan-green)] text-white border-[var(--vatan-green)]"
                          : showState && isPicked
                          ? "bg-[var(--vatan-red)] text-white border-[var(--vatan-red)]"
                          : "border-border text-muted-foreground group-hover:border-[var(--vatan-blue)]/50"
                      )}>
                        {showState && opt.correct ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : showState && isPicked ? (
                          <XCircle className="w-4 h-4" />
                        ) : (
                          String.fromCharCode(65 + i)
                        )}
                      </span>
                      <span className="text-[14px] leading-relaxed text-foreground flex-1 pt-0.5">
                        {opt.text[lang]}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* feedback */}
              {selected !== null && (
                <div className="mt-5 vatan-rise space-y-3">
                  {/* correct/incorrect status + explanation */}
                  <div className={cn(
                    "rounded-xl p-4 sm:p-5",
                    scenario.options[selected].correct
                      ? "bg-[var(--vatan-green-soft)]/60 border border-[var(--vatan-green)]/20"
                      : "bg-[var(--vatan-red-soft)]/50 border border-[var(--vatan-red)]/20"
                  )}>
                    <div className="flex items-center gap-2 mb-2.5">
                      {scenario.options[selected].correct ? (
                        <CheckCircle2 className="w-4 h-4 text-[var(--vatan-green)]" />
                      ) : (
                        <XCircle className="w-4 h-4 text-[var(--vatan-red)]" />
                      )}
                      <span className={cn(
                        "text-[12px] eyebrow font-semibold",
                        scenario.options[selected].correct ? "text-[var(--vatan-green)]" : "text-[var(--vatan-red)]"
                      )}>
                        {scenario.options[selected].correct ? t("s4.scenario.correct") : t("s4.scenario.incorrect")}
                      </span>
                    </div>
                    <div className="space-y-2">
                      <p className="text-[13.5px] leading-relaxed text-foreground/90">
                        {scenario.options[selected].feedback[lang]}
                      </p>
                    </div>
                  </div>

                  {/* safer action — always shown after answering */}
                  <div className="rounded-xl border border-[var(--vatan-blue)]/20 bg-[var(--vatan-blue-soft)]/40 p-4 sm:p-5">
                    <div className="flex items-start gap-2.5">
                      <ShieldCheck className="w-4 h-4 text-[var(--vatan-blue)] shrink-0 mt-0.5" />
                      <div>
                        <div className="text-[10px] eyebrow font-semibold text-[var(--vatan-blue)] mb-1">
                          {t("s4.scenario.safer")}
                        </div>
                        <p className="text-[13.5px] leading-relaxed text-foreground/90">
                          {scenario.safer[lang]}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-3 flex-wrap">
                    <span className="text-[12px] text-muted-foreground tabular-nums">
                      {t("s4.scenario.score")}: <span className="font-mono font-bold text-[var(--vatan-green)]">{score}/{CYBER_SCENARIOS.length}</span>
                    </span>
                    {!isLast ? (
                      <button
                        onClick={next}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[var(--vatan-blue)] text-white text-[14px] font-medium hover:bg-[var(--vatan-blue-deep)] active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        {t("s4.scenario.next")}
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    ) : (
                      <button
                        onClick={retry}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border text-[14px] font-medium hover:bg-muted/60 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <RotateCcw className="w-4 h-4" />
                        {t("s4.scenario.retry")}
                      </button>
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <Takeaway>
        {t("s4.takeaway")}
      </Takeaway>
    </SectionShell>
  );
}
