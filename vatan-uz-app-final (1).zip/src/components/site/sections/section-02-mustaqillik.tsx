"use client";

import React from "react";
import { SectionShell, SectionContext, Takeaway } from "@/components/site/section-shell";
import { useApp } from "@/lib/contexts/app-context";
import { CrescentStarMotif, DiamondCluster } from "@/components/site/motifs";

const GAINS = [
  { key: "davlat", icon: "landmark" },
  { key: "ramzlar", icon: "flag" },
  { key: "til", icon: "book" },
  { key: "qadriyatlar", icon: "gem" },
  { key: "meros", icon: "monument" },
  { key: "talim", icon: "cap" },
  { key: "fan", icon: "atom" },
  { key: "xalqaro", icon: "globe" },
  { key: "huquq", icon: "scale" },
] as const;

const TIMELINE = [
  {
    year: "1991",
    titleKey: "tl.1991.t",
    descKey: "tl.1991.d",
  },
  {
    year: "1992",
    titleKey: "tl.1992.t",
    descKey: "tl.1992.d",
  },
  {
    year: "1995",
    titleKey: "tl.1995.t",
    descKey: "tl.1995.d",
  },
  {
    year: "2017+",
    titleKey: "tl.2017.t",
    descKey: "tl.2017.d",
  },
] as const;

// We need timeline translations — add them inline as constants mapped by lang to avoid
// bloating i18n with too many keys. Actually we'll add keys to i18n dynamically here.
function useTimelineData() {
  const { lang } = useApp();
  const data: Record<string, Record<string, string>> = {
    uz: {
      "tl.1991.t": "Mustaqillik e’lon qilindi",
      "tl.1991.d":
        "1991-yil 31-avgustda O‘zbekiston Respublikasining davlat mustaqilligi e’lon qilindi. 1-sentyabr Mustaqillik kuni sifatida nishonlanadi.",
      "tl.1992.t": "Konstitutsiya qabul qilindi",
      "tl.1992.d":
        "1992-yil 8-dekabrda O‘zbekiston Respublikasining Konstitutsiyasi qabul qilindi — davlat va fuqaroning huquqiy asosi.",
      "tl.1995.t": "Davlat ramzlari shakllandi",
      "tl.1995.d":
        "Bayroq, gerb va madhiya — milliy o‘zlikni ifodalovchi ramzlar mustahkamlanib bordi.",
      "tl.2017.t": "Islohotlar bosqichi",
      "tl.2017.d":
        "Keng qamrovli islohotlar davri boshlandi: ta’lim, iqtisodiyot va davlat boshqaruvi sohasida.",
    },
    en: {
      "tl.1991.t": "Independence declared",
      "tl.1991.d":
        "On 31 August 1991, the state independence of the Republic of Uzbekistan was declared. 1 September is celebrated as Independence Day.",
      "tl.1992.t": "Constitution adopted",
      "tl.1992.d":
        "On 8 December 1992, the Constitution of the Republic of Uzbekistan was adopted — the legal basis for the state and citizens.",
      "tl.1995.t": "State symbols formed",
      "tl.1995.d":
        "The flag, emblem and anthem — symbols of national identity — became established.",
      "tl.2017.t": "Reform phase",
      "tl.2017.d":
        "A broad reform period began: in education, economy and public administration.",
    },
    ru: {
      "tl.1991.t": "Провозглашение независимости",
      "tl.1991.d":
        "31 августа 1991 года была провозглашена государственная независимость Республики Узбекистан. 1 сентября отмечается как День независимости.",
      "tl.1992.t": "Принята Конституция",
      "tl.1992.d":
        "8 декабря 1992 года принята Конституция Республики Узбекистан — правовая основа государства и граждан.",
      "tl.1995.t": "Сформировались символы",
      "tl.1995.d":
        "Флаг, герб и гимн — символы национальной идентичности — утвердились.",
      "tl.2017.t": "Этап реформ",
      "tl.2017.d":
        "Начался период широких реформ: в образовании, экономике и госуправлении.",
    },
  };
  return data[lang];
}

function GainIcon({ name }: { name: string }) {
  const common = "w-5 h-5";
  switch (name) {
    case "landmark":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M3 21h18M5 21V9l7-5 7 5v12M9 21v-6h6v6M9 11h0M15 11h0" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "flag":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M5 21V4M5 4l10 2-3 4 3 4-10-2" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "book":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M4 4v16a2 2 0 002-2V6a2 2 0 012-2h12v16H8a2 2 0 00-2 2M8 8h8M8 12h8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "gem":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M6 3h12l4 6-10 12L2 9l4-6ZM2 9h20M9 3l-3 6 6 12M15 3l3 6-6 12" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "monument":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 3l4 4-4 2-4-2 4-4ZM8 9l-2 12M16 9l2 12M7 21h10M10 13v8M14 13v8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "cap":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M2 9l10-5 10 5-10 5L2 9ZM6 11v5c0 1 3 2 6 2s6-1 6-2v-5M22 9v6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "atom":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="12" cy="12" r="1.5" />
          <ellipse cx="12" cy="12" rx="10" ry="4" />
          <ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(60 12 12)" />
          <ellipse cx="12" cy="12" rx="10" ry="4" transform="rotate(120 12 12)" />
        </svg>
      );
    case "globe":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="12" cy="12" r="9" />
          <path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" strokeLinecap="round" />
        </svg>
      );
    case "scale":
      return (
        <svg className={common} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 3v18M5 7h14M5 7l-3 6c0 2 2 3 3 3s3-1 3-3l-3-6ZM19 7l-3 6c0 2 2 3 3 3s3-1 3-3l-3-6ZM8 21h8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    default:
      return null;
  }
}

export function Section02Mustaqillik() {
  const { t } = useApp();
  const tl = useTimelineData();

  return (
    <SectionShell
      id="s2"
      num="02"
      eyebrowKey="s2.eyebrow"
      titleKey="s2.title"
      leadKey="s2.lead"
      accent="blue"
      readMinutes={5}
      className="bg-gradient-to-b from-transparent via-[#F3F0E6]/40 to-transparent"
      decorative={
        <CrescentStarMotif className="pointer-events-none absolute top-24 left-4 w-16 h-16 text-[var(--vatan-blue)] opacity-[0.08]" aria-hidden="true" />
      }
      factVariant={1}
    >
      {/* Core question */}
      <div className="mt-10 mb-10">
        <div className="rounded-2xl border border-[var(--vatan-blue)]/20 bg-[var(--vatan-blue-soft)]/50 p-6 sm:p-8">
          <p className="text-[13px] eyebrow text-[var(--vatan-blue)] font-semibold mb-2">
            {t("nav.02")}
          </p>
          <p className="text-[22px] sm:text-[26px] font-semibold text-foreground leading-snug">
            {t("s2.question")}
          </p>
        </div>
      </div>

      <SectionContext titleKey="s2.context.title" bodyKey="s2.context.body" />

      {/* Gains grid */}
      <div className="mt-14">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-[15px] eyebrow text-muted-foreground font-semibold">
            {t("s2.gains.title")}
          </h3>
          <DiamondCluster className="w-4 h-4 text-[var(--vatan-brass)]/70" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 [grid-auto-rows:1fr]">
          {GAINS.map((g) => (
            <div
              key={g.key}
              className="group rounded-xl border border-border bg-card/60 p-5 hover:border-[var(--vatan-blue)]/40 hover:bg-card hover:shadow-[0_8px_24px_-12px_rgba(30,115,190,0.18)] transition-all flex flex-col"
            >
              <div className="flex items-start gap-3.5 flex-1">
                <div className="shrink-0 w-10 h-10 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center group-hover:bg-[var(--vatan-blue)] group-hover:text-white transition-colors">
                  <GainIcon name={g.icon} />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-[15px] font-semibold text-foreground mb-1">
                    {t(`s2.gains.${g.key}`)}
                  </h4>
                  <p className="text-[13px] leading-relaxed text-muted-foreground">
                    {t(`s2.gains.${g.key}.d`)}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div className="mt-16">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[15px] eyebrow text-muted-foreground font-semibold">
            {t("s2.timeline.title")}
          </h3>
        </div>
        <p className="text-[12px] text-muted-foreground/80 mb-8 max-w-2xl">
          {t("s2.timeline.note")}
        </p>

        <div className="relative">
          {/* horizontal line (desktop) */}
          <div className="hidden md:block absolute top-[26px] left-0 right-0 h-px bg-border" aria-hidden="true" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 md:gap-4">
            {TIMELINE.map((item, i) => (
              <div key={item.year} className="relative">
                {/* dot */}
                <div className="flex md:block items-center gap-3 mb-3 md:mb-4">
                  <div className="relative z-10 w-3.5 h-3.5 rounded-full bg-[var(--vatan-blue)] ring-4 ring-[var(--vatan-blue-soft)]/60 shrink-0" />
                  <span className="md:hidden font-mono text-[13px] font-semibold text-[var(--vatan-blue)] tabular-nums">
                    {item.year}
                  </span>
                </div>
                <div className="hidden md:block font-mono text-[18px] font-semibold text-[var(--vatan-blue)] tabular-nums mb-2">
                  {item.year}
                </div>
                <h4 className="text-[14px] font-semibold text-foreground mb-1.5 leading-snug">
                  {tl[item.titleKey]}
                </h4>
                <p className="text-[13px] leading-relaxed text-muted-foreground">
                  {tl[item.descKey]}
                </p>
                {i < TIMELINE.length - 1 && (
                  <div className="md:hidden absolute left-1.5 top-7 bottom-0 w-px bg-border" aria-hidden="true" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <Takeaway>
        {t("s2.takeaway")}
      </Takeaway>
    </SectionShell>
  );
}
