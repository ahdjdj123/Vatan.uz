"use client";

import React, { useState } from "react";
import { SectionShell, SectionContext, Takeaway } from "@/components/site/section-shell";
import { useApp } from "@/lib/contexts/app-context";
import { SOURCES } from "@/lib/content";
import { WheatMotif, DiamondCluster } from "@/components/site/motifs";
import { ArrowDown, ArrowRight, CheckCircle2, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";

const AREAS = [
  { key: "education", icon: "cap", sourceId: "gov-uz" },
  { key: "healthcare", icon: "heart", sourceId: "gov-uz" },
  { key: "digital", icon: "monitor", sourceId: "mygov-uz" },
  { key: "business", icon: "store", sourceId: "gov-uz" },
  { key: "youth", icon: "users", sourceId: "youth-uz" },
] as const;

function AreaIcon({ name, className = "w-5 h-5" }: { name: string; className?: string }) {
  switch (name) {
    case "cap":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M2 9l10-5 10 5-10 5L2 9ZM6 11v5c0 1 3 2 6 2s6-1 6-2v-5M22 9v6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "heart":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 21s-7-5-7-11a5 5 0 0110-1 5 5 0 0110 1c0 6-7 11-7 11h-6Z" strokeLinecap="round" strokeLinejoin="round" transform="translate(-2 0)" />
        </svg>
      );
    case "monitor":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <rect x="3" y="4" width="18" height="13" rx="2" />
          <path d="M8 21h8M12 17v4" strokeLinecap="round" />
        </svg>
      );
    case "store":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M3 9l1.5-5h15L21 9M3 9v11h18V9M3 9h18M9 20v-6h6v6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "users":
      return (
        <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="9" cy="8" r="3" />
          <path d="M3 20c0-3 3-5 6-5s6 2 6 5" strokeLinecap="round" />
          <circle cx="17" cy="9" r="2.5" />
          <path d="M14 16c2-1 5-1 7 1" strokeLinecap="round" />
        </svg>
      );
    default:
      return null;
  }
}

export function Section03Islohotlar() {
  const { t, lang } = useApp();
  const [active, setActive] = useState<number>(0);

  const current = AREAS[active];
  const source = SOURCES.find((s) => s.id === current.sourceId);

  return (
    <SectionShell
      id="s3"
      num="03"
      eyebrowKey="s3.eyebrow"
      titleKey="s3.title"
      leadKey="s3.lead"
      accent="green"
      readMinutes={5}
      className="bg-gradient-to-b from-transparent via-[var(--vatan-green-soft)]/20 to-transparent"
      decorative={
        <WheatMotif className="pointer-events-none hidden lg:block absolute top-32 right-8 w-20 h-40 text-[var(--vatan-green)] opacity-[0.12]" aria-hidden="true" />
      }
      factVariant={1}
    >
      <SectionContext titleKey="s3.note.title" bodyKey="s3.note.body" />

      {/* Framework diagram — Problem → Solution → Result */}
      <div className="mt-12 rounded-2xl border border-border bg-card/60 p-5 sm:p-6">
        <div className="grid grid-cols-3 gap-3 sm:gap-4 items-stretch">
          <FrameworkStep
            label={t("s3.framework.problem")}
            num="1"
            color="var(--vatan-red)"
            bg="var(--vatan-red-soft)"
          />
          <div className="flex items-center justify-center">
            <ArrowDown className="md:hidden w-5 h-5 text-muted-foreground" />
            <ArrowRight className="hidden md:block w-5 h-5 text-muted-foreground" />
          </div>
          <FrameworkStep
            label={t("s3.framework.solution")}
            num="2"
            color="var(--vatan-blue)"
            bg="var(--vatan-blue-soft)"
          />
        </div>
        <div className="flex items-center justify-center my-3" aria-hidden="true">
          <ArrowDown className="md:hidden w-5 h-5 text-muted-foreground rotate-0" />
          <span className="hidden md:block w-px h-6 bg-border" />
        </div>
        <div className="grid grid-cols-3 gap-3 sm:gap-4">
          <div className="col-span-3">
            <FrameworkResultStep label={t("s3.framework.result")} />
          </div>
        </div>
      </div>

      {/* Areas selection */}
      <div className="mt-14">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-[15px] eyebrow text-muted-foreground font-semibold">
            {t("s3.areas.title")}
          </h3>
          <DiamondCluster className="w-4 h-4 text-[var(--vatan-green)]/70" />
        </div>

        {/* tabs */}
        <div className="flex flex-wrap gap-1.5 mb-6 p-1 rounded-xl bg-muted/50 w-full overflow-x-auto vatan-scroll">
          {AREAS.map((a, i) => (
            <button
              key={a.key}
              onClick={() => setActive(i)}
              className={cn(
                "flex items-center gap-2 px-3.5 py-2 rounded-lg text-[13px] font-medium whitespace-nowrap transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                active === i
                  ? "bg-card text-foreground shadow-sm border border-[var(--vatan-green)]/30"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              )}
              aria-pressed={active === i}
            >
              <AreaIcon name={a.icon} className="w-4 h-4" />
              {t(`s3.area.${a.key}`)}
            </button>
          ))}
        </div>

        {/* active area detail card */}
        <div className="rounded-2xl border border-border bg-card/70 p-6 sm:p-7 vatan-rise">
          <div className="flex items-start gap-4 mb-5">
            <div className="shrink-0 w-12 h-12 rounded-xl bg-[var(--vatan-green-soft)] text-[var(--vatan-green)] flex items-center justify-center">
              <AreaIcon name={current.icon} className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-[20px] font-semibold text-foreground">
                {t(`s3.area.${current.key}`)}
              </h4>
              <p className="text-[12px] text-muted-foreground eyebrow mt-1">Reform area</p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            {/* Problem */}
            <div className="rounded-xl border-l-2 border-[var(--vatan-red)] bg-[var(--vatan-red-soft)]/40 p-4 sm:p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="eyebrow text-[10px] font-semibold text-[var(--vatan-red)]">
                  {t("s3.framework.problem")}
                </span>
              </div>
              <p className="text-[14px] leading-relaxed text-foreground/90">
                {t(`s3.area.${current.key}.p`)}
              </p>
            </div>
            {/* Solution */}
            <div className="rounded-xl border-l-2 border-[var(--vatan-blue)] bg-[var(--vatan-blue-soft)]/40 p-4 sm:p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="eyebrow text-[10px] font-semibold text-[var(--vatan-blue)]">
                  {t("s3.framework.solution")}
                </span>
              </div>
              <p className="text-[14px] leading-relaxed text-foreground/90">
                {t(`s3.area.${current.key}.s`)}
              </p>
            </div>
          </div>

          {source && (
            <div className="mt-5 flex items-center gap-2 text-[12px] text-muted-foreground">
              <span>{t("s3.source.label")}</span>
              <a
                href={source.url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-[var(--vatan-blue)] hover:underline font-medium"
              >
                {source.org[lang]}
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          )}
        </div>
      </div>

      <Takeaway>
        {t("s3.takeaway")}
      </Takeaway>
    </SectionShell>
  );
}

function FrameworkStep({
  label,
  num,
  color,
  bg,
}: {
  label: string;
  num: string;
  color: string;
  bg: string;
}) {
  return (
    <div
      className="rounded-xl p-4 sm:p-5 text-center"
      style={{ backgroundColor: `color-mix(in srgb, ${bg} 50%, transparent)` }}
    >
      <div
        className="mx-auto w-8 h-8 rounded-full flex items-center justify-center font-mono text-[12px] font-bold mb-2 text-white"
        style={{ backgroundColor: color }}
      >
        {num}
      </div>
      <div className="text-[13px] sm:text-[14px] font-semibold" style={{ color }}>
        {label}
      </div>
    </div>
  );
}

function FrameworkResultStep({ label }: { label: string }) {
  return (
    <div className="rounded-xl p-4 sm:p-5 text-center bg-[var(--vatan-green-soft)]/50 border border-[var(--vatan-green)]/20">
      <div className="inline-flex items-center gap-2">
        <CheckCircle2 className="w-5 h-5 text-[var(--vatan-green)]" />
        <span className="text-[14px] sm:text-[15px] font-bold text-[var(--vatan-green)] tracking-wide">
          {label}
        </span>
      </div>
    </div>
  );
}
