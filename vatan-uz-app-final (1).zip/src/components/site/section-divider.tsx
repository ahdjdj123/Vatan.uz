"use client";

import React from "react";
import { useApp } from "@/lib/contexts/app-context";
import { DiamondCluster, CottonMotif } from "@/components/site/motifs";
import { cn } from "@/lib/utils";

interface SectionDividerProps {
  /** next section id for label, e.g. "s2" */
  nextSectionId?: string;
  /** next section num, e.g. "02" */
  nextSectionNum?: string;
  /** next section translation key, e.g. "nav.02" */
  nextSectionKey?: string;
  className?: string;
}

/**
 * Ornamental divider placed between major sections to create
 * a visual "reset" and improve scroll rhythm.
 */
export function SectionDivider({
  nextSectionId,
  nextSectionNum,
  nextSectionKey,
  className,
}: SectionDividerProps) {
  const { t } = useApp();
  const hasNext = nextSectionId && nextSectionNum && nextSectionKey;

  return (
    <div
      className={cn(
        "relative py-8 sm:py-10 flex items-center justify-center",
        className
      )}
      aria-hidden="true"
    >
      {/* center ornamental cluster */}
      <div className="flex items-center gap-3 sm:gap-4 text-muted-foreground/60">
        <span className="block h-px w-12 sm:w-20 bg-gradient-to-r from-transparent to-current" />
        <DiamondCluster className="w-4 h-4 text-[var(--vatan-brass)]" />
        <span className="block h-px w-4 bg-current" />
        <CottonMotif className="w-6 h-8 text-[var(--vatan-brass)]/70" />
        <span className="block h-px w-4 bg-current" />
        <DiamondCluster className="w-4 h-4 text-[var(--vatan-brass)]" />
        <span className="block h-px w-12 sm:w-20 bg-gradient-to-l from-transparent to-current" />
      </div>

      {hasNext && (
        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 text-[10px] eyebrow text-muted-foreground/70 whitespace-nowrap bg-background px-2">
          {nextSectionNum} · {t("divider.next")}
        </div>
      )}
    </div>
  );
}
