"use client";

import React from "react";
import { useApp, type SectionId } from "@/lib/contexts/app-context";
import { scrollToSection } from "@/lib/use-active-section";
import { Check, Circle } from "lucide-react";
import { cn } from "@/lib/utils";

interface SectionChecklistProps {
  variant?: "full" | "compact";
}

const SECTIONS: { id: SectionId; num: string; key: string }[] = [
  { id: "s1", num: "01", key: "nav.01" },
  { id: "s2", num: "02", key: "nav.02" },
  { id: "s3", num: "03", key: "nav.03" },
  { id: "s4", num: "04", key: "nav.04" },
  { id: "s5", num: "05", key: "nav.05" },
];

const REFLECTION_KEYS: Record<SectionId, string[]> = {
  hero: [],
  s1: ["s1.reflection"],
  s2: [],
  s3: [],
  s4: [],
  s5: ["s5.reflection"],
};

export function SectionChecklist({ variant = "full" }: SectionChecklistProps) {
  const { t, progress, markVisited } = useApp();

  const getSectionStatus = (id: SectionId) => {
    const visited = progress.visited[id];
    const reflectionKeys = REFLECTION_KEYS[id] || [];
    const hasReflection = reflectionKeys.some((k) => (progress.reflections[k] || "").trim().length > 0);
    const hasInteraction =
      id === "s4" ? progress.scenarioCompleted > 0 : id === "s5" ? (progress.survey?.length ?? 0) > 0 : false;
    const hasContent = id === "s1" || id === "s2" || id === "s3"; // read-only sections

    let score = 0;
    if (visited) score++;
    if (hasInteraction) score++;
    if (hasReflection) score++;

    const total = id === "s4" || id === "s5" || id === "s1" ? 3 : 1;
    const complete = score >= total;

    return { visited, hasInteraction, hasReflection, hasContent, complete, score, total };
  };

  if (variant === "compact") {
    const completed = SECTIONS.filter((s) => getSectionStatus(s.id).complete).length;
    return (
      <div className="flex items-center gap-1.5">
        {SECTIONS.map((s) => {
          const status = getSectionStatus(s.id);
          return (
            <span
              key={s.id}
              className={cn(
                "h-1.5 w-5 rounded-full transition-colors",
                status.complete ? "bg-[var(--vatan-green)]" : status.visited ? "bg-[var(--vatan-blue)]" : "bg-muted"
              )}
              title={`${s.num} ${t(s.key)}`}
            />
          );
        })}
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      {SECTIONS.map((s) => {
        const status = getSectionStatus(s.id);
        return (
          <button
            key={s.id}
            onClick={() => {
              markVisited(s.id);
              scrollToSection(s.id);
            }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg border border-border hover:bg-muted/40 hover:border-foreground/20 transition-all text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring group"
          >
            <span className="font-mono text-[11px] text-muted-foreground tabular-nums w-5 shrink-0">
              {s.num}
            </span>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[13.5px] font-medium text-foreground truncate">
                  {t(s.key)}
                </span>
                {status.complete && (
                  <span className="inline-flex items-center gap-0.5 text-[10px] eyebrow font-semibold text-[var(--vatan-green)] shrink-0">
                    <Check className="w-2.5 h-2.5" />
                    {t("checklist.complete")}
                  </span>
                )}
              </div>
              {/* status badges */}
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <StatusBadge
                  active={status.visited}
                  label={t("checklist.visited")}
                />
                {s.id === "s4" && (
                  <StatusBadge
                    active={status.hasInteraction}
                    label={t("checklist.interacted")}
                  />
                )}
                {s.id === "s5" && (
                  <StatusBadge
                    active={status.hasInteraction}
                    label={t("checklist.interacted")}
                  />
                )}
                {(REFLECTION_KEYS[s.id] || []).length > 0 && (
                  <StatusBadge
                    active={status.hasReflection}
                    label={t("checklist.reflected")}
                  />
                )}
              </div>
            </div>
            <span
              className={cn(
                "shrink-0 w-7 h-7 rounded-full flex items-center justify-center transition-colors",
                status.complete
                  ? "bg-[var(--vatan-green)] text-white"
                  : status.visited
                  ? "bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)]"
                  : "bg-muted text-muted-foreground"
              )}
            >
              {status.complete ? (
                <Check className="w-3.5 h-3.5" />
              ) : status.score > 0 ? (
                <span className="text-[10px] font-mono font-bold tabular-nums">
                  {status.score}/{status.total}
                </span>
              ) : (
                <Circle className="w-3 h-3" />
              )}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function StatusBadge({ active, label }: { active: boolean; label: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 text-[10px] eyebrow font-medium px-1.5 py-0.5 rounded",
        active
          ? "text-[var(--vatan-green)] bg-[var(--vatan-green-soft)]/50"
          : "text-muted-foreground/60 bg-muted/40"
      )}
    >
      <span className={cn("w-1 h-1 rounded-full", active ? "bg-[var(--vatan-green)]" : "bg-muted-foreground/40")} />
      {label}
    </span>
  );
}
