"use client";

import React from "react";
import { useApp } from "@/lib/contexts/app-context";
import { Lightbulb } from "lucide-react";
import { cn } from "@/lib/utils";

interface FactBoxProps {
  /** section key, e.g. "s1" — picks fact.{sectionKey}.{1|2} */
  sectionKey: string;
  /** which fact variant (1 or 2); defaults to 1 */
  variant?: 1 | 2;
  className?: string;
}

/**
 * "Bilasizmi?" / "Did you know?" / "Знаете ли вы?" callout box.
 * Adds educational depth and breaks visual monotony between sections.
 */
export function FactBox({ sectionKey, variant = 1, className }: FactBoxProps) {
  const { t } = useApp();
  const factKey = `fact.${sectionKey}.${variant}`;

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl border border-[var(--vatan-brass)]/25 bg-gradient-to-br from-[var(--vatan-brass-soft)]/50 via-[var(--vatan-brass-soft)]/20 to-transparent p-5 sm:p-6",
        className
      )}
    >
      {/* decorative corner motif */}
      <div
        className="pointer-events-none absolute -top-6 -right-6 w-28 h-28 rounded-full bg-[var(--vatan-brass)]/8"
        aria-hidden="true"
      />
      <div className="relative flex items-start gap-3.5">
        <div className="shrink-0 w-10 h-10 rounded-xl bg-[var(--vatan-brass)] text-white flex items-center justify-center shadow-sm">
          <Lightbulb className="w-5 h-5" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="eyebrow text-[10px] font-bold text-[var(--vatan-brass)] mb-1.5">
            {t("fact.label")}
          </div>
          <p className="text-[14.5px] sm:text-[15.5px] leading-relaxed text-foreground/90 font-medium">
            {t(factKey)}
          </p>
        </div>
      </div>
    </div>
  );
}
