"use client";

import React, { useEffect, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { scrollToSection } from "@/lib/use-active-section";
import { X, ArrowRight, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const SECTION_NAMES: Record<string, string> = {
  s1: "nav.01",
  s2: "nav.02",
  s3: "nav.03",
  s4: "nav.04",
  s5: "nav.05",
};

/**
 * Resume banner — shows briefly for returning users who have visited
 * at least one section but haven't seen all. Dismissible, auto-hides.
 */
export function ResumeBanner() {
  const { t, progress, markVisited, introSeen } = useApp();
  const [dismissed, setDismissed] = useState(false);
  const [visible, setVisible] = useState(false);

  const last = progress.lastVisited;
  const visitedCount = ["s1","s2","s3","s4","s5"].filter((s) => progress.visited[s as keyof typeof progress.visited]).length;
  const shouldShow =
    introSeen &&
    last &&
    visitedCount > 0 &&
    visitedCount < 5 &&
    SECTION_NAMES[last];

  useEffect(() => {
    if (shouldShow && !dismissed) {
      const timer = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(timer);
    }
  }, [shouldShow, dismissed]);

  if (!shouldShow || dismissed || !visible) return null;

  const handleContinue = () => {
    if (last) {
      markVisited(last as any);
      scrollToSection(last);
    }
    setDismissed(true);
  };

  return (
    <div className="fixed top-20 sm:top-[88px] right-4 z-[60] vatan-toast-in max-w-[320px]">
      <div className="rounded-xl border border-[var(--vatan-blue)]/30 bg-[var(--vatan-blue-soft)]/95 backdrop-blur-md p-4 shadow-[0_8px_30px_-8px_rgba(30,115,190,0.3)]">
        <div className="flex items-start gap-3">
          <div className="shrink-0 w-8 h-8 rounded-full bg-[var(--vatan-blue)] text-white flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[10px] eyebrow text-[var(--vatan-blue)] font-semibold mb-0.5">
              {t("resume.title")}
            </div>
            <p className="text-[13px] text-foreground leading-snug">
              {t("resume.desc")}: <span className="font-semibold">{t(SECTION_NAMES[last!])}</span>
            </p>
            <button
              onClick={handleContinue}
              className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-[var(--vatan-blue)] text-white text-[12px] font-medium hover:bg-[var(--vatan-blue-deep)] transition-colors"
            >
              {t("resume.continue")}
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="shrink-0 p-1 rounded-md text-muted-foreground hover:text-foreground transition-colors"
            aria-label={t("resume.dismiss")}
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
