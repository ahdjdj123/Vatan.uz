"use client";

import React, { useEffect, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { Map as MapIcon, X, Check, Circle } from "lucide-react";
import { cn } from "@/lib/utils";
import { DiamondCluster } from "@/components/site/motifs";

export function ProjectMap() {
  const { t, lang } = useApp();
  const [open, setOpen] = useState(false);

  const splitItems = (key: string) =>
    t(key)
      .split("·")
      .map((s) => s.trim())
      .filter(Boolean);

  const ALPHA_ITEMS = splitItems("map.alpha.items");
  const BETA_ITEMS = splitItems("map.beta.items");
  const FINAL_ITEMS = splitItems("map.final.items");

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const stages = [
    {
      key: "alpha",
      label: t("map.alpha"),
      desc: t("map.alpha.desc"),
      items: ALPHA_ITEMS,
      done: true,
      current: false,
      accent: "var(--vatan-blue)",
    },
    {
      key: "beta",
      label: t("map.beta"),
      desc: t("map.beta.desc"),
      items: BETA_ITEMS,
      done: true,
      current: false,
      accent: "var(--vatan-green)",
    },
    {
      key: "final",
      label: t("map.final"),
      desc: t("map.final.desc"),
      items: FINAL_ITEMS,
      done: true,
      current: true,
      accent: "var(--vatan-brass)",
    },
  ];

  return (
    <div className="border-t border-border/60 bg-muted/20">
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-[11px] text-muted-foreground/70">
            <DiamondCluster className="w-3 h-3 text-[var(--vatan-brass)]/60" />
            <span className="eyebrow">{t("about.madeBy")}</span>
          </div>
          <button
            onClick={() => setOpen(true)}
            className="group inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("map.title")}
          >
            <MapIcon className="w-3.5 h-3.5 group-hover:text-[var(--vatan-blue)] transition-colors" />
            <span className="eyebrow">{t("map.title")}</span>
          </button>
        </div>
      </div>

      {/* Modal */}
      {open && (
        <div
          className="fixed inset-0 z-[70] flex items-start sm:items-center justify-center pt-[8vh] sm:pt-0 px-4"
          role="dialog"
          aria-modal="true"
          aria-label={t("map.title")}
        >
          <div
            className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
            onClick={() => setOpen(false)}
          />
          <div className="relative w-full max-w-2xl rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise max-h-[84vh] flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
              <div>
                <div className="eyebrow text-[10px] text-muted-foreground font-semibold mb-0.5">
                  {t("map.eyebrow")}
                </div>
                <h2 className="text-[16px] font-semibold text-foreground">{t("map.title")}</h2>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={t("map.close")}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto vatan-scroll p-5">
              <div className="grid sm:grid-cols-3 gap-3">
                {stages.map((stage) => (
                  <div
                    key={stage.key}
                    className={cn(
                      "rounded-xl border p-4 flex flex-col transition-all",
                      stage.current
                        ? "border-[var(--vatan-brass)]/50 bg-[var(--vatan-brass-soft)]/40 ring-1 ring-[var(--vatan-brass)]/20"
                        : "border-border bg-card/60"
                    )}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1.5">
                        <span
                          className="font-mono text-[11px] font-bold px-1.5 py-0.5 rounded"
                          style={{
                            color: stage.accent,
                            backgroundColor: `color-mix(in srgb, ${stage.accent} 12%, transparent)`,
                          }}
                        >
                          {stage.label}
                        </span>
                        {stage.current && (
                          <span className="text-[9px] eyebrow font-bold text-[var(--vatan-brass)] px-1.5 py-0.5 rounded bg-[var(--vatan-brass)]/15">
                            {t("map.current")}
                          </span>
                        )}
                      </div>
                      {stage.done ? (
                        <span
                          className="inline-flex items-center gap-1 text-[10px] eyebrow font-semibold"
                          style={{ color: stage.accent }}
                        >
                          <Check className="w-3 h-3" />
                          {t("map.done")}
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[10px] eyebrow font-semibold text-muted-foreground">
                          <Circle className="w-3 h-3" />
                          {t("map.pending")}
                        </span>
                      )}
                    </div>
                    <p className={cn(
                      "text-[12px] mb-3 leading-relaxed",
                      stage.current ? "text-foreground/80 font-medium" : "text-muted-foreground"
                    )}>
                      {stage.desc}
                    </p>
                    <ul className="space-y-1.5 mt-auto">
                      {stage.items.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-[12px]">
                          <span
                            className={cn(
                              "shrink-0 mt-0.5 w-3.5 h-3.5 rounded-full flex items-center justify-center",
                              stage.done ? "" : "opacity-40"
                            )}
                            style={{
                              backgroundColor: stage.done
                                ? `color-mix(in srgb, ${stage.accent} 18%, transparent)`
                                : "var(--muted)",
                              color: stage.accent,
                            }}
                          >
                            {stage.done ? (
                              <Check className="w-2.5 h-2.5" />
                            ) : (
                              <Circle className="w-1.5 h-1.5" />
                            )}
                          </span>
                          <span className={stage.done ? "text-foreground/80" : "text-muted-foreground/70"}>
                            {item}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              <div className="mt-4 rounded-lg bg-muted/40 border border-border/60 px-4 py-3">
                <p className="text-[11.5px] text-muted-foreground leading-relaxed">
                  {t("map.note")}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
