"use client";

import React, { useEffect, useMemo } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { Trophy, X, Lock, CheckCircle2, BookOpen, Compass, Lightbulb, ShieldCheck, Bookmark, Flame, BookMarked, Presentation, GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils";

interface Achievement {
  key: string;
  titleKey: string;
  descKey: string;
  icon: React.ElementType;
  accent: string;
  check: (progress: ReturnType<typeof useApp>["progress"]) => boolean;
}

const ACHIEVEMENTS: Achievement[] = [
  {
    key: "firstSteps",
    titleKey: "ach.firstSteps.title",
    descKey: "ach.firstSteps.desc",
    icon: BookOpen,
    accent: "var(--vatan-blue)",
    check: (p) => Object.values(p.visited).some(Boolean),
  },
  {
    key: "explorer",
    titleKey: "ach.explorer.title",
    descKey: "ach.explorer.desc",
    icon: Compass,
    accent: "var(--vatan-blue)",
    check: (p) => ["s1","s2","s3","s4","s5"].every((s) => p.visited[s as keyof typeof p.visited]),
  },
  {
    key: "thinker",
    titleKey: "ach.thinker.title",
    descKey: "ach.thinker.desc",
    icon: Lightbulb,
    accent: "var(--vatan-brass)",
    check: (p) => Object.values(p.reflections).some((v) => v.trim().length > 0),
  },
  {
    key: "guardian",
    titleKey: "ach.guardian.title",
    descKey: "ach.guardian.desc",
    icon: ShieldCheck,
    accent: "var(--vatan-green)",
    check: (p) => p.scenarioCompleted >= 5,
  },
  {
    key: "collector",
    titleKey: "ach.collector.title",
    descKey: "ach.collector.desc",
    icon: Bookmark,
    accent: "var(--vatan-blue)",
    check: (p) => p.bookmarks.length >= 3,
  },
  {
    key: "streak3",
    titleKey: "ach.streak3.title",
    descKey: "ach.streak3.desc",
    icon: Flame,
    accent: "var(--vatan-red)",
    check: (p) => p.streak >= 3,
  },
  {
    key: "scholar",
    titleKey: "ach.scholar.title",
    descKey: "ach.scholar.desc",
    icon: BookMarked,
    accent: "var(--vatan-blue)",
    check: (p) => p.celebratedSections.some((c) => c.startsWith("glossary")),
  },
  {
    key: "presenter",
    titleKey: "ach.presenter.title",
    descKey: "ach.presenter.desc",
    icon: Presentation,
    accent: "var(--vatan-brass)",
    check: (p) => p.presentationProgress > 0,
  },
  {
    key: "quizMaster",
    titleKey: "ach.quizMaster.title",
    descKey: "ach.quizMaster.desc",
    icon: GraduationCap,
    accent: "var(--vatan-green)",
    check: (p) => p.celebratedSections.includes("mini-quiz-done"),
  },
];

export function AchievementsModal() {
  const { t, achievementsOpen, setAchievementsOpen, progress } = useApp();

  useEffect(() => {
    if (!achievementsOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setAchievementsOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [achievementsOpen, setAchievementsOpen]);

  const unlockedCount = useMemo(
    () => ACHIEVEMENTS.filter((a) => a.check(progress)).length,
    [progress]
  );

  if (!achievementsOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[70] flex items-start sm:items-center justify-center pt-[8vh] sm:pt-0 px-4"
      role="dialog"
      aria-modal="true"
      aria-label={t("ach.title")}
    >
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
        onClick={() => setAchievementsOpen(false)}
      />
      <div className="relative w-full max-w-2xl rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise max-h-[84vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--vatan-brass-soft)] text-[var(--vatan-brass)] flex items-center justify-center">
              <Trophy className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] eyebrow text-[var(--vatan-brass)] font-semibold">
                {t("ach.eyebrow")}
              </div>
              <h2 className="text-[16px] font-semibold text-foreground">
                {t("ach.title")}
              </h2>
            </div>
          </div>
          <button
            onClick={() => setAchievementsOpen(false)}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("ach.close")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Progress summary */}
        <div className="px-5 py-3 border-b border-border bg-muted/30 shrink-0">
          <div className="flex items-center justify-between gap-3">
            <span className="text-[12px] text-muted-foreground">
              {t("ach.progress")}
            </span>
            <span className="font-mono text-[14px] font-bold text-foreground tabular-nums">
              {unlockedCount}/{ACHIEVEMENTS.length}
            </span>
          </div>
          <div className="mt-1.5 h-1.5 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full bg-[var(--vatan-brass)] transition-all duration-500"
              style={{ width: `${(unlockedCount / ACHIEVEMENTS.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Achievements grid */}
        <div className="flex-1 overflow-y-auto vatan-scroll p-4">
          <div className="grid sm:grid-cols-2 gap-2.5">
            {ACHIEVEMENTS.map((a, i) => {
              const unlocked = a.check(progress);
              const Icon = a.icon;
              return (
                <div
                  key={a.key}
                  className={cn(
                    "rounded-xl border p-4 flex items-start gap-3 transition-all vatan-rise",
                    unlocked
                      ? "border-border bg-card/60"
                      : "border-border/60 bg-muted/20 opacity-70"
                  )}
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  <div
                    className={cn(
                      "shrink-0 w-10 h-10 rounded-lg flex items-center justify-center transition-colors",
                      unlocked ? "" : "grayscale"
                    )}
                    style={{
                      backgroundColor: unlocked
                        ? `color-mix(in srgb, ${a.accent} 14%, transparent)`
                        : "var(--muted)",
                      color: unlocked ? a.accent : "var(--muted-foreground)",
                    }}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <h3 className="text-[14px] font-semibold text-foreground truncate">
                        {t(a.titleKey)}
                      </h3>
                      {unlocked ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-[var(--vatan-green)] shrink-0" />
                      ) : (
                        <Lock className="w-3 h-3 text-muted-foreground/50 shrink-0" />
                      )}
                    </div>
                    <p className="text-[12px] text-muted-foreground leading-relaxed">
                      {t(a.descKey)}
                    </p>
                    <span
                      className={cn(
                        "inline-block mt-1.5 text-[9px] eyebrow font-semibold",
                        unlocked ? "text-[var(--vatan-green)]" : "text-muted-foreground/50"
                      )}
                    >
                      {unlocked ? t("ach.unlocked") : t("ach.locked")}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
