"use client";

import React, { useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { cn } from "@/lib/utils";
import { OrnamentalDivider } from "@/components/site/motifs";
import { Copy, Download, Check, Bookmark, Clock } from "lucide-react";
import { FactBox } from "@/components/site/fact-box";

interface SectionShellProps {
  id: string;
  num: string;
  eyebrowKey: string;
  titleKey: string;
  leadKey?: string;
  accent?: "blue" | "green" | "brass";
  children: React.ReactNode;
  className?: string;
  decorative?: React.ReactNode;
  /** fact variant (1 or 2); omit to hide the "Bilasizmi?" box */
  factVariant?: 1 | 2;
  /** estimated reading time in minutes */
  readMinutes?: number;
}

const accentColor: Record<string, string> = {
  blue: "var(--vatan-blue)",
  green: "var(--vatan-green)",
  brass: "var(--vatan-brass)",
};

export function SectionShell({
  id,
  num,
  eyebrowKey,
  titleKey,
  leadKey,
  accent = "blue",
  children,
  className,
  decorative,
  factVariant,
  readMinutes,
}: SectionShellProps) {
  const { t, isBookmarked, toggleBookmark, celebrate } = useApp();
  const color = accentColor[accent];
  const bookmarked = isBookmarked(id);

  const onToggleBookmark = () => {
    const wasBookmarked = bookmarked;
    toggleBookmark(id);
    if (!wasBookmarked) {
      celebrate(`bookmark-${id}`, "celebrate.bookmark");
    }
  };

  return (
    <section
      id={id}
      className={cn("relative py-20 sm:py-24 lg:py-28 scroll-mt-20", className)}
      aria-labelledby={`${id}-title`}
    >
      {decorative}
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="max-w-3xl">
          <div className="flex items-center gap-3 mb-5 flex-wrap">
            <span
              className="font-mono text-[12px] font-semibold tabular-nums px-2 py-0.5 rounded"
              style={{ color, backgroundColor: `color-mix(in srgb, ${color} 12%, transparent)` }}
            >
              {num}
            </span>
            <span className="h-px w-8" style={{ backgroundColor: color }} />
            <span className="eyebrow text-[11px] font-semibold" style={{ color }}>
              {t(eyebrowKey).replace(/^\d+\s·\s/, "")}
            </span>
            {/* Reading time + bookmark toggle */}
            <div className="ml-auto flex items-center gap-2">
              {readMinutes && (
                <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground tabular-nums">
                  <Clock className="w-3 h-3" />
                  {readMinutes} {t("readtime.min")}
                </span>
              )}
              <button
                onClick={onToggleBookmark}
                className={cn(
                  "p-1.5 rounded-md transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  bookmarked
                    ? "text-[var(--vatan-blue)] bg-[var(--vatan-blue-soft)]"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted/60"
                )}
                aria-label={bookmarked ? t("bookmark.remove") : t("bookmark.add")}
                aria-pressed={bookmarked}
                title={bookmarked ? t("bookmark.remove") : t("bookmark.add")}
              >
                <Bookmark className={cn("w-4 h-4", bookmarked && "fill-current")} />
              </button>
            </div>
          </div>
          <h2
            id={`${id}-title`}
            className="display-heading font-semibold text-foreground text-[34px] sm:text-[44px] lg:text-[56px] leading-[1.02]"
          >
            {t(titleKey)}
          </h2>
          {leadKey && (
            <p className="mt-5 text-[16px] sm:text-[18px] leading-relaxed text-[var(--vatan-slate)] max-w-2xl">
              {t(leadKey)}
            </p>
          )}
          <div className="mt-7">
            <OrnamentalDivider />
          </div>
        </div>

        {children}

        {factVariant && <FactBox sectionKey={id} variant={factVariant} className="mt-12" />}
      </div>
    </section>
  );
}

export function SectionContext({
  titleKey,
  bodyKey,
}: {
  titleKey: string;
  bodyKey: string;
}) {
  const { t } = useApp();
  return (
    <div className="mt-10 rounded-2xl border border-border bg-card/60 p-6 sm:p-7">
      <div className="flex items-start gap-4">
        <div className="hidden sm:block w-1 self-stretch rounded-full bg-[var(--vatan-blue)]" />
        <div>
          <h3 className="text-[13px] eyebrow text-[var(--vatan-blue)] font-semibold mb-2">
            {t(titleKey)}
          </h3>
          <p className="text-[15px] leading-relaxed text-foreground/90">{t(bodyKey)}</p>
        </div>
      </div>
    </div>
  );
}

export function Takeaway({ children }: { children: React.ReactNode }) {
  return (
    <div className="mt-12 rounded-2xl border-l-2 border-[var(--vatan-green)] bg-[var(--vatan-green-soft)]/60 p-6">
      <div className="flex items-start gap-3">
        <span className="eyebrow text-[10px] font-semibold text-[var(--vatan-green)] mt-1 shrink-0">
          TAKEAWAY
        </span>
        <p className="text-[15px] sm:text-[16px] leading-relaxed font-medium text-foreground">
          {children}
        </p>
      </div>
    </div>
  );
}

export function ReflectionCard({
  storageKey,
  eyebrowKey,
  titleKey,
  hintKey,
  placeholderKey,
}: {
  storageKey: string;
  eyebrowKey: string;
  titleKey: string;
  hintKey: string;
  placeholderKey: string;
}) {
  const { t, getReflection, saveReflection, celebrate } = useApp();
  const initial = getReflection(storageKey);
  const [value, setValue] = useState(initial);
  const [saved, setSaved] = useState(false);
  const isDirty = value.trim() !== initial.trim();

  React.useEffect(() => {
    setValue(getReflection(storageKey));
  }, [getReflection, storageKey]);

  const onSave = () => {
    const wasEmpty = !getReflection(storageKey).trim();
    saveReflection(storageKey, value);
    setSaved(true);
    setTimeout(() => setSaved(false), 2200);
    if (wasEmpty && value.trim()) {
      celebrate(`reflection-${storageKey}`, "celebrate.reflection");
    }
  };

  return (
    <div className="mt-10 rounded-2xl border border-[var(--vatan-brass)]/30 bg-[var(--vatan-brass-soft)]/40 p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
        <div className="flex items-center gap-2">
          <span className="eyebrow text-[11px] font-semibold text-[var(--vatan-brass)]">
            {t(eyebrowKey)}
          </span>
        </div>
        {initial.trim().length > 0 && (
          <span className="inline-flex items-center gap-1.5 text-[11px] text-[var(--vatan-green)] font-medium">
            <span className="w-1.5 h-1.5 rounded-full bg-[var(--vatan-green)]" />
            {t("reflect.editHint")}
          </span>
        )}
      </div>
      <h3 className="text-[17px] sm:text-[19px] font-semibold text-foreground leading-snug mb-2.5">
        {t(titleKey)}
      </h3>
      <p className="text-[12.5px] sm:text-[13px] text-muted-foreground mb-4">{t(hintKey)}</p>
      <textarea
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder={t(placeholderKey)}
        rows={4}
        className="w-full rounded-lg border border-border bg-background/70 px-4 py-3 text-[14px] leading-relaxed text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:border-[var(--vatan-brass)]/40 resize-y vatan-scroll transition-colors"
        aria-label={t(titleKey)}
      />
      <div className="mt-3 flex items-center justify-between gap-3 flex-wrap">
        <span className="text-[11.5px] text-muted-foreground tabular-nums">
          {value.trim().length > 0 ? `${value.trim().length} ${t("reflect.charCount")}` : ""}
        </span>
        <div className="flex items-center gap-2 flex-wrap">
          {saved && (
            <span className="inline-flex items-center gap-1.5 text-[12px] text-[var(--vatan-green)] font-medium vatan-rise">
              <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 8.5l3 3 7-7" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              {t("reflect.savedToast")}
            </span>
          )}
          {value.trim().length > 0 && (
            <ShareButtons value={value} titleKey={titleKey} />
          )}
          <button
            onClick={onSave}
            disabled={value.trim().length === 0 || (!isDirty && !saved)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-[var(--vatan-brass)] text-white text-[13px] font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-[var(--vatan-brass)]/90 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
          >
            {saved ? t("common.saved") : isDirty ? t("common.save") : t("common.saved")}
          </button>
        </div>
      </div>
    </div>
  );
}

function ShareButtons({ value, titleKey }: { value: string; titleKey: string }) {
  const { t } = useApp();
  const [copied, setCopied] = useState(false);

  const onCopy = async () => {
    const text = `${t("share.title")}: ${t(titleKey)}\n\n${value.trim()}\n\n— Vatan.uz.app`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* ignore */
    }
  };

  const onDownload = () => {
    const date = new Date().toLocaleDateString();
    const text = `${t("share.title")}: ${t(titleKey)}\n${t("share.date")}: ${date}\n\n${value.trim()}\n\n— Vatan.uz.app`;
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vatan-reflection-${titleKey}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex items-center gap-1">
      <button
        onClick={onCopy}
        className="inline-flex items-center gap-1.5 px-2.5 py-2 rounded-md text-[12px] text-muted-foreground hover:text-foreground hover:bg-muted/60 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label={t("share.copy")}
      >
        {copied ? (
          <>
            <Check className="w-3.5 h-3.5 text-[var(--vatan-green)]" />
            <span className="text-[var(--vatan-green)]">{t("share.copied")}</span>
          </>
        ) : (
          <>
            <Copy className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t("share.copy")}</span>
          </>
        )}
      </button>
      <button
        onClick={onDownload}
        className="inline-flex items-center gap-1.5 px-2.5 py-2 rounded-md text-[12px] text-muted-foreground hover:text-foreground hover:bg-muted/60 active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label={t("share.download")}
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">{t("share.download")}</span>
      </button>
    </div>
  );
}
