"use client";

import React, { useEffect } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { CheckCircle2, Sparkles } from "lucide-react";

/**
 * Subtle celebration toast that appears briefly when a milestone is reached.
 * Non-intrusive, auto-dismisses, respects reduced motion.
 */
export function CelebrationToast() {
  const { celebration, dismissCelebration, t, reducedMotion } = useApp();

  useEffect(() => {
    if (!celebration) return;
    const dur = reducedMotion ? 1200 : 3200;
    const timer = window.setTimeout(dismissCelebration, dur);
    return () => window.clearTimeout(timer);
  }, [celebration, dismissCelebration, reducedMotion]);

  if (!celebration) return null;

  return (
    <div
      className="fixed top-20 sm:top-24 left-1/2 -translate-x-1/2 z-[85] vatan-toast-in"
      role="status"
      aria-live="polite"
    >
      <div className="flex items-center gap-3 rounded-xl border border-[var(--vatan-green)]/30 bg-[var(--vatan-green-soft)]/95 backdrop-blur-md px-4 py-3 shadow-[0_8px_30px_-8px_rgba(21,148,71,0.4)]">
        <div className="shrink-0 w-8 h-8 rounded-full bg-[var(--vatan-green)] text-white flex items-center justify-center">
          <CheckCircle2 className="w-5 h-5" />
        </div>
        <div className="flex flex-col">
          <span className="text-[10px] eyebrow text-[var(--vatan-green)] font-semibold flex items-center gap-1">
            <Sparkles className="w-3 h-3" />
            {t("celebrate.section")}
          </span>
          <span className="text-[14px] font-semibold text-foreground">
            {t(celebration.message)}
          </span>
        </div>
        <button
          onClick={dismissCelebration}
          className="ml-2 p-1 rounded-md text-muted-foreground hover:text-foreground transition-colors"
          aria-label={t("celebrate.continue")}
        >
          <svg viewBox="0 0 16 16" className="w-3.5 h-3.5" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M4 4l8 8M12 4l-8 8" strokeLinecap="round" />
          </svg>
        </button>
      </div>
    </div>
  );
}
