"use client";

import React from "react";
import { useApp } from "@/lib/contexts/app-context";
import { SOURCES } from "@/lib/content";
import { ExternalLink, Sparkles } from "lucide-react";
import { DiamondCluster, CottonMotif } from "@/components/site/motifs";

export function SourcesSection() {
  const { t, lang } = useApp();

  return (
    <section
      id="sources"
      className="relative py-20 sm:py-24 scroll-mt-20"
      aria-labelledby="sources-title"
    >
      <CottonMotif className="pointer-events-none hidden lg:block absolute top-12 right-8 w-14 h-20 text-[var(--vatan-brass)] opacity-[0.15]" aria-hidden="true" />
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-10">
          <div className="flex items-center gap-3 mb-5">
            <span className="h-px w-8 bg-[var(--vatan-brass)]" />
            <span className="eyebrow text-[11px] text-[var(--vatan-brass)] font-semibold">
              {t("sources.eyebrow")}
            </span>
          </div>
          <h2
            id="sources-title"
            className="display-heading font-semibold text-foreground text-[32px] sm:text-[40px] lg:text-[48px] leading-[1.05]"
          >
            {t("sources.title")}
          </h2>
          <p className="mt-4 text-[15px] text-[var(--vatan-slate)] max-w-2xl">
            {t("sources.hint")}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {SOURCES.map((s, i) => (
            <a
              key={s.id}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group rounded-xl border border-border bg-card/60 p-5 hover:border-[var(--vatan-blue)]/40 hover:bg-card transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-[11px] text-muted-foreground tabular-nums">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[12px] eyebrow text-[var(--vatan-blue)] font-semibold">
                    {s.org[lang]}
                  </span>
                </div>
                <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-[var(--vatan-blue)] transition-colors" />
              </div>
              <h3 className="text-[15px] font-semibold text-foreground leading-snug mb-2">
                {s.title[lang]}
              </h3>
              <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
                <span className="eyebrow text-[10px]">{t("sources.topic")}:</span>
                <span>{s.topic[lang]}</span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

export function FAQSection() {
  const { t } = useApp();
  const [open, setOpen] = React.useState<number | null>(0);

  const faqs = [
    { q: "faq.q1", a: "faq.a1" },
    { q: "faq.q2", a: "faq.a2" },
    { q: "faq.q3", a: "faq.a3" },
    { q: "faq.q4", a: "faq.a4" },
    { q: "faq.q5", a: "faq.a5" },
    { q: "faq.q6", a: "faq.a6" },
  ];

  return (
    <section
      id="faq"
      className="relative py-20 sm:py-24 scroll-mt-20 bg-gradient-to-b from-transparent via-muted/30 to-transparent"
      aria-labelledby="faq-title"
    >
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mb-10">
          <div className="flex items-center gap-3 mb-5">
            <span className="h-px w-8 bg-[var(--vatan-blue)]" />
            <span className="eyebrow text-[11px] text-[var(--vatan-blue)] font-semibold">
              {t("faq.eyebrow")}
            </span>
          </div>
          <h2
            id="faq-title"
            className="display-heading font-semibold text-foreground text-[32px] sm:text-[40px] lg:text-[48px] leading-[1.05]"
          >
            {t("faq.title")}
          </h2>
          <p className="mt-4 text-[15px] text-[var(--vatan-slate)]">{t("faq.hint")}</p>
        </div>

        <div className="max-w-3xl divide-y divide-border border-y border-border">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <div key={i}>
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 py-5 text-left group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md px-2 -mx-2"
                  aria-expanded={isOpen}
                >
                  <span className="flex items-start gap-3">
                    <span className="font-mono text-[12px] text-[var(--vatan-blue)] tabular-nums mt-1">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-[15px] sm:text-[16px] font-semibold text-foreground">
                      {t(f.q)}
                    </span>
                  </span>
                  <span
                    className={`shrink-0 w-6 h-6 rounded-full border border-border flex items-center justify-center transition-transform ${
                      isOpen ? "rotate-45 bg-[var(--vatan-blue)] border-[var(--vatan-blue)] text-white" : "text-muted-foreground"
                    }`}
                    aria-hidden="true"
                  >
                    <svg viewBox="0 0 16 16" className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M8 3v10M3 8h10" strokeLinecap="round" />
                    </svg>
                  </span>
                </button>
                <div
                  className={`grid transition-all duration-300 ${
                    isOpen ? "grid-rows-[1fr] opacity-100 pb-5" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden">
                    <p className="text-[14px] sm:text-[14.5px] leading-relaxed text-muted-foreground pl-7 pr-8">
                      {t(f.a)}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export function AboutSection() {
  const { t } = useApp();

  const roles = [
    { key: "research", icon: "search" },
    { key: "content", icon: "doc" },
    { key: "design", icon: "palette" },
    { key: "dev", icon: "code" },
    { key: "presentation", icon: "present" },
  ] as const;

  return (
    <section
      id="about"
      className="relative py-20 sm:py-24 scroll-mt-20"
      aria-labelledby="about-title"
    >
      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-10 items-start">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3 mb-5">
              <span className="h-px w-8 bg-[var(--vatan-blue)]" />
              <span className="eyebrow text-[11px] text-[var(--vatan-blue)] font-semibold">
                {t("about.eyebrow")}
              </span>
            </div>
            <h2
              id="about-title"
              className="display-heading font-semibold text-foreground text-[32px] sm:text-[40px] lg:text-[48px] leading-[1.05]"
            >
              {t("about.title")}
            </h2>
            <p className="mt-5 text-[15px] leading-relaxed text-[var(--vatan-slate)]">
              {t("about.body")}
            </p>

            {/* Made by Abdushukur's team attribution */}
            <div className="mt-6 inline-flex items-center gap-3 rounded-xl border border-[var(--vatan-brass)]/30 bg-[var(--vatan-brass-soft)]/40 px-4 py-3">
              <div className="shrink-0 w-9 h-9 rounded-lg bg-[var(--vatan-brass)] text-white flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="text-[10px] eyebrow text-[var(--vatan-brass)] font-semibold mb-0.5">
                  {t("about.madeByLabel")}
                </div>
                <div className="text-[14px] font-semibold text-foreground">
                  {t("about.madeBy")}
                </div>
              </div>
            </div>

            <div className="mt-5 flex items-center gap-3">
              <DiamondCluster className="w-4 h-4 text-[var(--vatan-brass)]" />
              <span className="text-[13px] text-muted-foreground">{t("brand.tagline")}</span>
            </div>
          </div>

          <div className="lg:col-span-7">
            <h3 className="text-[13px] eyebrow text-muted-foreground font-semibold mb-4">
              {t("about.roles.title")}
            </h3>
            <div className="grid sm:grid-cols-2 gap-3">
              {roles.map((r) => (
                <div
                  key={r.key}
                  className="rounded-xl border border-border bg-card/60 p-4 flex items-start gap-3"
                >
                  <div className="shrink-0 w-9 h-9 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center">
                    <RoleIcon name={r.icon} />
                  </div>
                  <div>
                    <h4 className="text-[14px] font-semibold text-foreground mb-0.5">
                      {t(`about.role.${r.key}`)}
                    </h4>
                    <p className="text-[12.5px] leading-relaxed text-muted-foreground">
                      {t(`about.role.${r.key}.d`)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function RoleIcon({ name }: { name: string }) {
  const c = "w-[18px] h-[18px]";
  switch (name) {
    case "search":
      return (
        <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <circle cx="11" cy="11" r="7" />
          <path d="M21 21l-5-5" strokeLinecap="round" />
        </svg>
      );
    case "doc":
      return (
        <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M6 3h9l5 5v13a1 1 0 01-1 1H6a1 1 0 01-1-1V4a1 1 0 011-1ZM14 3v6h5M9 13h6M9 17h6" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "palette":
      return (
        <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M12 3a9 9 0 100 18c1 0 1.5-1 1.5-2s-.5-2 .5-2H17a4 4 0 004-4c0-5-4-9-9-9Z" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="8" cy="11" r="1" fill="currentColor" />
          <circle cx="11" cy="7" r="1" fill="currentColor" />
          <circle cx="16" cy="9" r="1" fill="currentColor" />
        </svg>
      );
    case "code":
      return (
        <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <path d="M8 6L2 12l6 6M16 6l6 6-6 6M14 4l-4 16" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "present":
      return (
        <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
          <rect x="3" y="4" width="18" height="12" rx="1" />
          <path d="M3 16l9 5 9-5M8 10h0M12 10h0M16 10h0" strokeLinecap="round" />
        </svg>
      );
    default:
      return null;
  }
}
