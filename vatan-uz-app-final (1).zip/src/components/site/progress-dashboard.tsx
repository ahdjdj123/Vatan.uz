"use client";

import React, { useEffect, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { BarChart3, X, Download, Check, Flame, Trophy, Bookmark, Lightbulb, ShieldCheck, GraduationCap } from "lucide-react";
import { cn } from "@/lib/utils";

const SECTIONS = [
  { id: "s1", num: "01", key: "nav.01" },
  { id: "s2", num: "02", key: "nav.02" },
  { id: "s3", num: "03", key: "nav.03" },
  { id: "s4", num: "04", key: "nav.04" },
  { id: "s5", num: "05", key: "nav.05" },
] as const;

export function ProgressDashboard() {
  const { t, dashboardOpen, setDashboardOpen, progress } = useApp();
  const [exported, setExported] = useState(false);

  useEffect(() => {
    if (!dashboardOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setDashboardOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [dashboardOpen, setDashboardOpen]);

  if (!dashboardOpen) return null;

  const visitedCount = SECTIONS.filter((s) => progress.visited[s.id]).length;
  const reflectionCount = Object.values(progress.reflections).filter((v) => v.trim().length > 0).length;
  const bookmarkCount = progress.bookmarks.length;
  const achievementCount = [
    Object.values(progress.visited).some(Boolean),
    ["s1","s2","s3","s4","s5"].every((s) => progress.visited[s as keyof typeof progress.visited]),
    reflectionCount > 0,
    progress.scenarioCompleted >= 5,
    bookmarkCount >= 3,
    progress.streak >= 3,
    progress.celebratedSections.some((c) => c.startsWith("glossary")),
    progress.presentationProgress > 0,
  ].filter(Boolean).length;

  const onExport = () => {
    const date = new Date().toLocaleDateString();
    const text = `Vatan.uz.app — ${t("dashboard.title")}
${t("dashboard.eyebrow")}: ${date}

${t("dashboard.sections")}: ${visitedCount}/5
${t("dashboard.reflections")}: ${reflectionCount}
${t("dashboard.bookmarks")}: ${bookmarkCount}
${t("dashboard.scenarios")}: ${progress.scenarioCompleted}/5
${t("dashboard.streak")}: ${progress.streak} ${t("streak.days")}
${t("dashboard.achievements")}: ${achievementCount}/9

— Vatan.uz.app`;
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `vatan-progress-${date}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    setExported(true);
    setTimeout(() => setExported(false), 1800);
  };

  const stats = [
    {
      label: t("dashboard.sections"),
      value: `${visitedCount}/5`,
      icon: BarChart3,
      color: "var(--vatan-blue)",
      pct: (visitedCount / 5) * 100,
    },
    {
      label: t("dashboard.scenarios"),
      value: `${progress.scenarioCompleted}/5`,
      icon: ShieldCheck,
      color: "var(--vatan-green)",
      pct: (progress.scenarioCompleted / 5) * 100,
    },
    {
      label: t("dashboard.reflections"),
      value: `${reflectionCount}`,
      icon: Lightbulb,
      color: "var(--vatan-brass)",
      pct: reflectionCount > 0 ? 100 : 0,
    },
    {
      label: t("dashboard.bookmarks"),
      value: `${bookmarkCount}`,
      icon: Bookmark,
      color: "var(--vatan-blue)",
      pct: Math.min(100, (bookmarkCount / 5) * 100),
    },
    {
      label: t("dashboard.streak"),
      value: `${progress.streak}`,
      icon: Flame,
      color: "var(--vatan-red)",
      pct: Math.min(100, (progress.streak / 7) * 100),
    },
    {
      label: t("dashboard.achievements"),
      value: `${achievementCount}/9`,
      icon: Trophy,
      color: "var(--vatan-brass)",
      pct: (achievementCount / 9) * 100,
    },
  ];

  return (
    <div
      className="fixed inset-0 z-[70] flex items-start sm:items-center justify-center pt-[8vh] sm:pt-0 px-4"
      role="dialog"
      aria-modal="true"
      aria-label={t("dashboard.title")}
    >
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
        onClick={() => setDashboardOpen(false)}
      />
      <div className="relative w-full max-w-2xl rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise max-h-[84vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center">
              <BarChart3 className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] eyebrow text-[var(--vatan-blue)] font-semibold">
                {t("dashboard.eyebrow")}
              </div>
              <h2 className="text-[16px] font-semibold text-foreground">
                {t("dashboard.title")}
              </h2>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onExport}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
              aria-label={t("dashboard.export")}
            >
              {exported ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[var(--vatan-green)]" />
                  <span className="text-[var(--vatan-green)]">{t("dashboard.exported")}</span>
                </>
              ) : (
                <>
                  <Download className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{t("dashboard.export")}</span>
                </>
              )}
            </button>
            <button
              onClick={() => setDashboardOpen(false)}
              className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
              aria-label={t("dashboard.close")}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stats grid */}
        <div className="flex-1 overflow-y-auto vatan-scroll p-5">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {stats.map((s, i) => {
              const Icon = s.icon;
              return (
                <div
                  key={i}
                  className="rounded-xl border border-border bg-card/60 p-4 vatan-rise"
                  style={{ animationDelay: `${i * 40}ms` }}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <div
                      className="w-7 h-7 rounded-md flex items-center justify-center"
                      style={{ backgroundColor: `color-mix(in srgb, ${s.color} 14%, transparent)`, color: s.color }}
                    >
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="font-mono text-[18px] font-bold text-foreground tabular-nums">
                      {s.value}
                    </span>
                  </div>
                  <div className="text-[11px] text-muted-foreground mb-2">{s.label}</div>
                  <div className="h-1 rounded-full bg-muted overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${s.pct}%`, backgroundColor: s.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Section breakdown */}
          <div className="mt-5">
            <div className="text-[11px] eyebrow text-muted-foreground font-semibold mb-2 px-1">
              {t("dashboard.sections")}
            </div>
            <div className="grid grid-cols-5 gap-1.5">
              {SECTIONS.map((s) => {
                const visited = progress.visited[s.id];
                return (
                  <div
                    key={s.id}
                    className={cn(
                      "rounded-lg border p-2 text-center transition-colors",
                      visited
                        ? "border-[var(--vatan-blue)]/30 bg-[var(--vatan-blue-soft)]/40"
                        : "border-border bg-muted/20"
                    )}
                  >
                    <div className={cn(
                      "font-mono text-[11px] font-bold tabular-nums",
                      visited ? "text-[var(--vatan-blue)]" : "text-muted-foreground"
                    )}>
                      {s.num}
                    </div>
                    <div className={cn(
                      "mt-1 w-1.5 h-1.5 rounded-full mx-auto",
                      visited ? "bg-[var(--vatan-blue)]" : "bg-muted-foreground/30"
                    )} />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
