"use client";

import React from "react";
import { useApp } from "@/lib/contexts/app-context";
import { scrollToSection } from "@/lib/use-active-section";
import { ShieldCheck, ArrowUp, Heart, BookMarked, Trophy, GraduationCap } from "lucide-react";
import { OrnamentalDivider, DiamondCluster } from "@/components/site/motifs";
import { ShortcutsHintButton } from "@/components/site/keyboard-shortcuts";

const NAV_SECTIONS = [
  { id: "s1", num: "01", key: "nav.01" },
  { id: "s2", num: "02", key: "nav.02" },
  { id: "s3", num: "03", key: "nav.03" },
  { id: "s4", num: "04", key: "nav.04" },
  { id: "s5", num: "05", key: "nav.05" },
] as const;

export function Footer() {
  const { t, setGlossaryOpen, setAchievementsOpen, setQuizOpen } = useApp();

  return (
    <footer className="relative mt-auto border-t border-border bg-gradient-to-b from-transparent to-muted/40">
      {/* Top decorative band */}
      <div className="h-1 w-full bg-gradient-to-r from-[var(--vatan-blue)] via-[var(--vatan-green)] to-[var(--vatan-brass)] opacity-60" />

      <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-2 md:grid-cols-12 gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-5">
            <div className="flex items-center gap-2.5 mb-3">
              <FooterLogo className="w-8 h-8 text-[var(--vatan-blue)]" />
              <span className="font-semibold text-[15px] tracking-tight">
                Vatan<span className="text-[var(--vatan-blue)]">.uz</span>.app
              </span>
            </div>
            <p className="text-[14px] text-foreground font-medium mb-1">
              {t("footer.tagline")}
            </p>
            <p className="text-[13px] text-muted-foreground leading-relaxed max-w-sm">
              {t("about.body")}
            </p>
            <div className="mt-5">
              <OrnamentalDivider />
            </div>
          </div>

          {/* Sections */}
          <div className="md:col-span-3">
            <h4 className="eyebrow text-[11px] text-muted-foreground font-semibold mb-3">
              {t("footer.sections")}
            </h4>
            <ul className="space-y-2">
              {NAV_SECTIONS.map((s) => (
                <li key={s.id}>
                  <button
                    onClick={() => scrollToSection(s.id)}
                    className="group inline-flex items-center gap-2 text-[13.5px] text-foreground/80 hover:text-[var(--vatan-blue)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                  >
                    <span className="font-mono text-[11px] text-muted-foreground group-hover:text-[var(--vatan-blue)] tabular-nums">
                      {s.num}
                    </span>
                    {t(s.key)}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div className="md:col-span-2">
            <h4 className="eyebrow text-[11px] text-muted-foreground font-semibold mb-3">
              {t("footer.resources")}
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => scrollToSection("about")}
                  className="text-[13.5px] text-foreground/80 hover:text-[var(--vatan-blue)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                >
                  {t("nav.about")}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("sources")}
                  className="text-[13.5px] text-foreground/80 hover:text-[var(--vatan-blue)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                >
                  {t("nav.sources")}
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollToSection("faq")}
                  className="text-[13.5px] text-foreground/80 hover:text-[var(--vatan-blue)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                >
                  {t("nav.faq")}
                </button>
              </li>
              <li>
                <button
                  onClick={() => setGlossaryOpen(true)}
                  className="inline-flex items-center gap-1.5 text-[13.5px] text-foreground/80 hover:text-[var(--vatan-blue)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                >
                  <BookMarked className="w-3.5 h-3.5 opacity-70" />
                  {t("glossary.title")}
                </button>
              </li>
            </ul>
          </div>

          {/* Privacy */}
          <div className="md:col-span-2">
            <h4 className="eyebrow text-[11px] text-muted-foreground font-semibold mb-3 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[var(--vatan-green)]" />
              {t("footer.privacy")}
            </h4>
            <p className="text-[12.5px] text-muted-foreground leading-relaxed">
              {t("footer.privacy.body")}
            </p>
          </div>
        </div>

        {/* Bottom row */}
        <div className="mt-12 pt-6 border-t border-border flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2 text-[12px] text-muted-foreground">
              <DiamondCluster className="w-3 h-3 text-[var(--vatan-brass)]" />
              <span>{t("footer.made")}</span>
            </div>
            <ShortcutsHintButton />
            <button
              onClick={() => setAchievementsOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={t("ach.title")}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span className="eyebrow hidden sm:inline">{t("ach.title")}</span>
            </button>
            <button
              onClick={() => setQuizOpen(true)}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={t("quiz.title")}
            >
              <GraduationCap className="w-3.5 h-3.5" />
              <span className="eyebrow hidden sm:inline">{t("quiz.title")}</span>
            </button>
          </div>
          <button
            onClick={() => scrollToSection("hero")}
            className="group inline-flex items-center gap-2 text-[12px] text-muted-foreground hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md px-2 py-1"
          >
            {t("footer.top")}
            <span className="w-7 h-7 rounded-full border border-border flex items-center justify-center group-hover:border-[var(--vatan-blue)] group-hover:text-[var(--vatan-blue)] transition-colors">
              <ArrowUp className="w-3.5 h-3.5" />
            </span>
          </button>
        </div>
      </div>
    </footer>
  );
}

function FooterLogo({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true" fill="none">
      <path d="M24 6a14 14 0 1 0 0 28 15.5 15.5 0 0 1 0-28Z" fill="currentColor" />
      <circle cx="16" cy="20" r="11" fill="var(--background)" />
      <path d="M30 11l1.4 2.9 3.1.45-2.25 2.2.53 3.1L30 21.4l-2.78 1.46.53-3.1L25.5 17.55l3.1-.45L30 11Z" fill="currentColor" />
      <circle cx="20" cy="20" r="18" stroke="var(--vatan-brass)" strokeWidth="0.8" opacity="0.5" />
    </svg>
  );
}
