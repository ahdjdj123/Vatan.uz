"use client";

import React, { useEffect, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { Keyboard, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface ShortcutGroup {
  label: string;
  keys: { key: string; desc: string }[];
}

export function KeyboardShortcuts() {
  const { t } = useApp();
  const [open, setOpen] = useState(false);

  // Global "?" to toggle + custom event from hint button
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const tag = target.tagName;
      const isTyping = tag === "INPUT" || tag === "TEXTAREA" || target.isContentEditable;
      if (e.key === "?" && !isTyping) {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    const onCustom = () => setOpen((v) => !v);
    window.addEventListener("keydown", onKey);
    window.addEventListener("vatan:shortcuts", onCustom);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("vatan:shortcuts", onCustom);
    };
  }, [open]);

  const groups: ShortcutGroup[] = [
    {
      label: t("kbd.eyebrow"),
      keys: [
        { key: "/", desc: t("kbd.search") },
        { key: "P", desc: t("kbd.presentation") },
        { key: "S", desc: t("kbd.settings") },
        { key: "G", desc: t("kbd.glossary") },
        { key: "B", desc: t("bookmark.title") },
        { key: "M", desc: t("kbd.menu") },
        { key: "1—5", desc: t("kbd.nav") },
        { key: "?", desc: t("kbd.title") },
        { key: "Esc", desc: t("kbd.esc") },
      ],
    },
  ];

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[75] flex items-center justify-center px-4"
      role="dialog"
      aria-modal="true"
      aria-label={t("kbd.title")}
    >
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
        onClick={() => setOpen(false)}
      />
      <div className="relative w-full max-w-md rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--vatan-blue-soft)] text-[var(--vatan-blue)] flex items-center justify-center">
              <Keyboard className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] eyebrow text-[var(--vatan-blue)] font-semibold">
                {t("kbd.eyebrow")}
              </div>
              <h2 className="text-[16px] font-semibold text-foreground">
                {t("kbd.title")}
              </h2>
            </div>
          </div>
          <button
            onClick={() => setOpen(false)}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("common.close")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Shortcuts */}
        <div className="p-4 space-y-1.5">
          {groups[0].keys.map((s) => (
            <div
              key={s.key}
              className="flex items-center justify-between gap-3 px-2 py-2 rounded-md hover:bg-muted/40 transition-colors"
            >
              <span className="text-[13.5px] text-foreground">{s.desc}</span>
              <kbd className="inline-flex items-center justify-center min-w-[28px] h-7 px-2 rounded-md border border-border bg-muted/60 font-mono text-[12px] font-semibold text-foreground">
                {s.key}
              </kbd>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-5 py-2.5 border-t border-border text-[11px] text-muted-foreground">
          Esc — {t("common.close").toLowerCase()}
        </div>
      </div>
    </div>
  );
}

/** Small hint button that can be placed in the footer to open the shortcuts overlay. */
export function ShortcutsHintButton() {
  const { t } = useApp();
  return (
    <button
      onClick={() => window.dispatchEvent(new CustomEvent("vatan:shortcuts"))}
      className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-[11px] text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      aria-label={t("kbd.title")}
    >
      <Keyboard className="w-3.5 h-3.5" />
      <span className="eyebrow hidden sm:inline">{t("kbd.hint")}</span>
      <kbd className="hidden sm:inline-flex items-center justify-center min-w-[20px] h-5 px-1 rounded border border-border bg-muted/60 font-mono text-[10px] font-semibold">
        ?
      </kbd>
    </button>
  );
}
