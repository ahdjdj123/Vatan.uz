"use client";

import React, { useEffect, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { useActiveSection, scrollToSection } from "@/lib/use-active-section";
import {
  Search,
  Settings,
  Presentation,
  Menu,
  X,
  Globe,
  ChevronRight,
  BookMarked,
  Bookmark,
  Focus,
  Trophy,
  BarChart3,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { LANGS } from "@/lib/i18n";

const NAV_SECTIONS = [
  { id: "s1", num: "01", key: "nav.01" },
  { id: "s2", num: "02", key: "nav.02" },
  { id: "s3", num: "03", key: "nav.03" },
  { id: "s4", num: "04", key: "nav.04" },
  { id: "s5", num: "05", key: "nav.05" },
] as const;

export function Header() {
  const { t, setSearchOpen, setSettingsOpen, setPresentationOpen, setMobileMenuOpen, mobileMenuOpen, lang, setLang, setGlossaryOpen, setBookmarksOpen, setAchievementsOpen, setDashboardOpen, progress, studyMode, setStudyMode } =
    useApp();
  const bookmarkCount = progress.bookmarks.length;
  // Compute unlocked achievement count
  const achievementCount = [
    Object.values(progress.visited).some(Boolean),
    ["s1","s2","s3","s4","s5"].every((s) => progress.visited[s as keyof typeof progress.visited]),
    Object.values(progress.reflections).some((v) => v.trim().length > 0),
    progress.scenarioCompleted >= 5,
    progress.bookmarks.length >= 3,
    progress.streak >= 3,
    progress.celebratedSections.some((c) => c.startsWith("glossary")),
    progress.presentationProgress > 0,
    progress.celebratedSections.includes("mini-quiz-done"),
  ].filter(Boolean).length;
  const [scrolled, setScrolled] = useState(false);
  const [scrollPct, setScrollPct] = useState(0);
  const active = useActiveSection(["hero", "s1", "s2", "s3", "s4", "s5"]);

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 40);
      const docH = document.documentElement.scrollHeight - window.innerHeight;
      setScrollPct(docH > 0 ? Math.min(100, (y / docH) * 100) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, []);

  // Close mobile menu on resize to desktop
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth >= 1024) setMobileMenuOpen(false);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, [setMobileMenuOpen]);

  // Lock scroll when mobile menu open
  useEffect(() => {
    document.body.style.overflow = mobileMenuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen]);

  // Global keyboard shortcuts: S/P/G/M and 1-5
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const tag = target.tagName;
      const isTyping = tag === "INPUT" || tag === "TEXTAREA" || target.isContentEditable;
      if (isTyping || e.metaKey || e.ctrlKey || e.altKey) return;
      const k = e.key.toLowerCase();
      if (k === "s") { e.preventDefault(); setSearchOpen(true); }
      else if (k === "p") { e.preventDefault(); setPresentationOpen(true); }
      else if (k === "g") { e.preventDefault(); setGlossaryOpen(true); }
      else if (k === "b") { e.preventDefault(); setBookmarksOpen(true); }
      else if (k === "m") { e.preventDefault(); setMobileMenuOpen(true); }
      else if (["1", "2", "3", "4", "5"].includes(k)) {
        e.preventDefault();
        const secId = `s${k}`;
        scrollToSection(secId);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setSearchOpen, setPresentationOpen, setGlossaryOpen, setBookmarksOpen, setMobileMenuOpen]);

  const go = (id: string) => {
    setMobileMenuOpen(false);
    scrollToSection(id);
  };

  return (
    <>
      <header
        className={cn(
          "fixed top-0 inset-x-0 z-40 transition-all duration-300",
          scrolled
            ? "bg-background/85 backdrop-blur-md border-b border-border/70 shadow-[0_1px_0_0_rgba(0,0,0,0.02)]"
            : "bg-transparent border-b border-transparent"
        )}
      >
        <div className="mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 lg:h-[72px] items-center justify-between gap-4">
            {/* Logo */}
            <button
              onClick={() => go("hero")}
              className="group flex items-center gap-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md"
              aria-label={t("nav.home")}
            >
              <LogoMark className="w-8 h-8 text-[var(--vatan-blue)] transition-transform group-hover:scale-105" />
              <span className="flex flex-col leading-none">
                <span className="font-semibold text-[15px] tracking-tight text-foreground">
                  Vatan<span className="text-[var(--vatan-blue)]">.uz</span>.app
                </span>
                <span className="text-[10px] text-muted-foreground eyebrow mt-0.5 hidden sm:block">
                  {t("brand.tagline")}
                </span>
              </span>
            </button>

            {/* Center nav (desktop) */}
            <nav className="hidden lg:flex items-center gap-1" aria-label={t("nav.section")}>
              {NAV_SECTIONS.map((s) => {
                const isActive = active === s.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => go(s.id)}
                    className={cn(
                      "group relative flex items-center gap-2 px-3 py-2 rounded-md text-[13.5px] transition-colors",
                      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                      isActive
                        ? "text-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    )}
                    aria-current={isActive ? "page" : undefined}
                  >
                    <span
                      className={cn(
                        "text-[11px] font-mono tabular-nums transition-colors",
                        isActive ? "text-[var(--vatan-blue)]" : "text-muted-foreground/70"
                      )}
                    >
                      {s.num}
                    </span>
                    <span className="font-medium">{t(s.key)}</span>
                    <span
                      className={cn(
                        "absolute -bottom-px left-3 right-3 h-[2px] rounded-full bg-[var(--vatan-blue)] transition-all duration-300",
                        isActive ? "opacity-100 scale-x-100" : "opacity-0 scale-x-0"
                      )}
                    />
                  </button>
                );
              })}
            </nav>

            {/* Right controls — simplified: Search + Language + Settings + Presentation */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => setSearchOpen(true)}
                className="flex items-center gap-2 px-2.5 py-2 rounded-md text-[13px] text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={t("nav.search")}
              >
                <Search className="w-4 h-4" />
                <kbd className="hidden xl:inline-block px-1.5 py-0.5 rounded border border-border bg-muted/50 text-[10px] font-mono text-muted-foreground">
                  /
                </kbd>
              </button>

              <LanguageSwitcher />

              <button
                onClick={() => setSettingsOpen(true)}
                className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={t("nav.settings")}
              >
                <Settings className="w-[18px] h-[18px]" />
              </button>

              <button
                onClick={() => setPresentationOpen(true)}
                className="hidden md:inline-flex items-center gap-1.5 ml-1 px-3 py-2 rounded-md text-[13px] font-medium text-[var(--vatan-blue)] border border-[var(--vatan-blue)]/30 hover:bg-[var(--vatan-blue-soft)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={t("nav.presentation")}
              >
                <Presentation className="w-4 h-4" />
                <span className="hidden xl:inline">{t("nav.presentation")}</span>
              </button>

              {/* Hamburger (mobile) */}
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-2 rounded-md text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                aria-label={t("nav.menu")}
                aria-expanded={mobileMenuOpen}
              >
                <Menu className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Scroll progress indicator */}
        <div
          className="absolute bottom-0 left-0 h-[2px] bg-[var(--vatan-blue)] transition-[width] duration-150 ease-out"
          style={{ width: `${scrollPct}%` }}
          aria-hidden="true"
        />
      </header>

      {/* Mobile menu overlay */}
      <div
        className={cn(
          "fixed inset-0 z-50 lg:hidden transition-all duration-300",
          mobileMenuOpen ? "visible opacity-100" : "invisible opacity-0"
        )}
        aria-hidden={!mobileMenuOpen}
      >
        <div
          className="absolute inset-0 bg-foreground/30 backdrop-blur-sm"
          onClick={() => setMobileMenuOpen(false)}
        />
        <div
          className={cn(
            "absolute right-0 top-0 h-full w-[88%] max-w-[380px] bg-background shadow-2xl flex flex-col transition-transform duration-300",
            mobileMenuOpen ? "translate-x-0" : "translate-x-full"
          )}
          role="dialog"
          aria-modal="true"
          aria-label={t("nav.menu")}
        >
          <div className="flex items-center justify-between px-5 h-16 border-b border-border">
            <span className="font-semibold text-[15px]">{t("nav.menu")}</span>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 rounded-md hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              aria-label={t("nav.close")}
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="flex-1 overflow-y-auto vatan-scroll px-3 py-4" aria-label={t("nav.section")}>
            <div className="px-2 mb-2 text-[11px] eyebrow text-muted-foreground">
              {t("nav.section")}
            </div>
            {NAV_SECTIONS.map((s) => (
              <button
                key={s.id}
                onClick={() => go(s.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-3.5 rounded-lg text-left transition-colors",
                  active === s.id
                    ? "bg-[var(--vatan-blue-soft)] text-foreground"
                    : "hover:bg-muted/60 text-foreground"
                )}
              >
                <span className="font-mono text-[12px] text-[var(--vatan-blue)] tabular-nums w-6">
                  {s.num}
                </span>
                <span className="font-medium text-[15px] flex-1">{t(s.key)}</span>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            ))}

            <div className="my-4 h-px bg-border" />

            <div className="px-2 mb-2 text-[11px] eyebrow text-muted-foreground">
              {t("footer.resources")}
            </div>
            <button
              onClick={() => { setMobileMenuOpen(false); setSearchOpen(true); }}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left hover:bg-muted/60 transition-colors"
            >
              <Search className="w-[18px] h-[18px] text-muted-foreground" />
              <span className="text-[15px]">{t("nav.search")}</span>
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); setPresentationOpen(true); }}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left hover:bg-muted/60 transition-colors"
            >
              <Presentation className="w-[18px] h-[18px] text-muted-foreground" />
              <span className="text-[15px]">{t("nav.presentation")}</span>
            </button>
            <button
              onClick={() => go("about")}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left hover:bg-muted/60 transition-colors"
            >
              <ChevronRight className="w-[18px] h-[18px] text-muted-foreground rotate-45" />
              <span className="text-[15px]">{t("nav.about")}</span>
            </button>
            <button
              onClick={() => go("faq")}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left hover:bg-muted/60 transition-colors"
            >
              <ChevronRight className="w-[18px] h-[18px] text-muted-foreground rotate-45" />
              <span className="text-[15px]">{t("nav.faq")}</span>
            </button>
            <button
              onClick={() => go("sources")}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left hover:bg-muted/60 transition-colors"
            >
              <ChevronRight className="w-[18px] h-[18px] text-muted-foreground rotate-45" />
              <span className="text-[15px]">{t("nav.sources")}</span>
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); setGlossaryOpen(true); }}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-lg text-left hover:bg-muted/60 transition-colors"
            >
              <BookMarked className="w-[18px] h-[18px] text-muted-foreground" />
              <span className="text-[15px]">{t("glossary.title")}</span>
            </button>
          </nav>

          <div className="px-5 py-4 border-t border-border">
            <div className="flex items-center gap-2 mb-3">
              <Globe className="w-4 h-4 text-muted-foreground" />
              <span className="text-[13px] text-muted-foreground">{t("nav.language")}</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {LANGS.map((l) => (
                <button
                  key={l.code}
                  onClick={() => setLang(l.code)}
                  className={cn(
                    "px-2 py-2 rounded-md text-[13px] font-medium transition-colors",
                    lang === l.code
                      ? "bg-[var(--vatan-blue)] text-white"
                      : "bg-muted/60 text-foreground hover:bg-muted"
                  )}
                >
                  {l.native}
                </button>
              ))}
            </div>
            <button
              onClick={() => { setMobileMenuOpen(false); setSettingsOpen(true); }}
              className="mt-3 w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-md text-[13px] font-medium border border-border hover:bg-muted/60 transition-colors"
            >
              <Settings className="w-4 h-4" />
              {t("nav.settings")}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

function LanguageSwitcher() {
  const { lang, setLang, t } = useApp();
  const [open, setOpen] = useState(false);
  const ref = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1 px-2.5 py-2 rounded-md text-[13px] font-medium text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        aria-label={t("nav.language")}
        aria-expanded={open}
      >
        <Globe className="w-4 h-4" />
        <span className="uppercase">{lang}</span>
      </button>
      {open && (
        <div className="absolute right-0 mt-1.5 w-40 rounded-lg border border-border bg-popover shadow-lg overflow-hidden vatan-rise">
          {LANGS.map((l) => (
            <button
              key={l.code}
              onClick={() => { setLang(l.code); setOpen(false); }}
              className={cn(
                "w-full flex items-center justify-between px-3 py-2.5 text-[13px] transition-colors text-left",
                lang === l.code
                  ? "bg-[var(--vatan-blue-soft)] text-foreground"
                  : "text-foreground hover:bg-muted/60"
              )}
            >
              <span>{l.native}</span>
              <span className="text-[10px] uppercase text-muted-foreground">{l.code}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function LogoMark({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true" fill="none">
      {/* crescent */}
      <path
        d="M24 6a14 14 0 1 0 0 28 15.5 15.5 0 0 1 0-28Z"
        fill="currentColor"
      />
      <circle cx="16" cy="20" r="11" fill="var(--background)" />
      {/* star */}
      <path
        d="M30 11l1.4 2.9 3.1.45-2.25 2.2.53 3.1L30 21.4l-2.78 1.46.53-3.1L25.5 17.55l3.1-.45L30 11Z"
        fill="currentColor"
      />
      {/* brass ring */}
      <circle cx="20" cy="20" r="18" stroke="var(--vatan-brass)" strokeWidth="0.8" opacity="0.5" />
    </svg>
  );
}
