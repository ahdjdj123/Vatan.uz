"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { buildSearchIndex, type SearchableItem } from "@/lib/content";
import { Search as SearchIcon, X, ArrowRight, FileText, BookOpen, HelpCircle, Layers, BookMarked } from "lucide-react";
import { cn } from "@/lib/utils";
import { scrollToSection } from "@/lib/use-active-section";

const INDEX = buildSearchIndex();

export function SearchModal() {
  const { t, lang, searchOpen, setSearchOpen, setGlossaryOpen } = useApp();
  const [query, setQuery] = useState("");
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  // Reset on open
  useEffect(() => {
    if (searchOpen) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setQuery("");
       
      setActiveIdx(0);
      setTimeout(() => inputRef.current?.focus(), 60);
    }
  }, [searchOpen]);

  const results = useMemo<SearchableItem[]>(() => {
    const q = query.trim().toLowerCase();
    if (!q) {
      // Show sections by default
      return INDEX.filter((i) => i.type === "section").slice(0, 5);
    }
    const matches: { item: SearchableItem; score: number }[] = [];
    for (const item of INDEX) {
      const title =
        item.titleText?.[lang] ?? (item.titleKey ? t(item.titleKey) : "");
      const desc =
        item.descText?.[lang] ?? (item.descKey ? t(item.descKey) : "");
      const tl = title.toLowerCase();
      const dl = (desc || "").toLowerCase();
      let score = 0;
      if (tl.startsWith(q)) score += 10;
      else if (tl.includes(q)) score += 5;
      if (dl.includes(q)) score += 2;
      if (score > 0) matches.push({ item, score });
    }
    matches.sort((a, b) => b.score - a.score);
    return matches.slice(0, 12).map((m) => m.item);
  }, [query, lang, t]);

  // Reset active when results change
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setActiveIdx(0);
  }, [query]);

  const handleSelect = (item: SearchableItem) => {
    setSearchOpen(false);
    if (item.openGlossary) {
      setTimeout(() => setGlossaryOpen(true), 100);
    } else if (item.href) {
      window.open(item.href, "_blank", "noopener,noreferrer");
    } else if (item.target) {
      setTimeout(() => scrollToSection(item.target!), 80);
    }
  };

  // Esc / arrows / enter to close/navigate
  useEffect(() => {
    if (!searchOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSearchOpen(false);
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIdx((i) => Math.min(i + 1, results.length - 1));
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIdx((i) => Math.max(i - 1, 0));
      }
      if (e.key === "Enter" && results[activeIdx]) {
        e.preventDefault();
        handleSelect(results[activeIdx]);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [searchOpen, setSearchOpen, results, activeIdx]);

  // Global "/" to open
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const tag = target.tagName;
      const isTyping = tag === "INPUT" || tag === "TEXTAREA" || target.isContentEditable;
      if (e.key === "/" && !isTyping && !searchOpen) {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [searchOpen, setSearchOpen]);

  if (!searchOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center pt-[10vh] px-4" role="dialog" aria-modal="true" aria-label={t("search.title")}>
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
        onClick={() => setSearchOpen(false)}
      />
      <div className="relative w-full max-w-xl rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise">
        {/* Input */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border">
          <SearchIcon className="w-5 h-5 text-muted-foreground shrink-0" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t("search.placeholder")}
            className="flex-1 bg-transparent text-[15px] text-foreground placeholder:text-muted-foreground focus:outline-none"
            aria-label={t("search.placeholder")}
            aria-autocomplete="list"
            aria-controls="search-list"
          />
          <kbd className="px-1.5 py-0.5 rounded border border-border bg-muted/50 text-[10px] font-mono text-muted-foreground">
            ESC
          </kbd>
          <button
            onClick={() => setSearchOpen(false)}
            className="p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60"
            aria-label={t("nav.close")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results */}
        <div
          ref={listRef}
          id="search-list"
          role="listbox"
          className="max-h-[50vh] overflow-y-auto vatan-scroll p-2"
        >
          {results.length === 0 ? (
            <div className="px-4 py-10 text-center">
              <p className="text-[14px] text-muted-foreground mb-1">{t("search.empty")}</p>
              <p className="text-[12px] text-muted-foreground/70">{t("search.hint")}</p>
            </div>
          ) : (
            results.map((item, i) => {
              const title =
                item.titleText?.[lang] ?? (item.titleKey ? t(item.titleKey) : "");
              const desc =
                item.descText?.[lang] ?? (item.descKey ? t(item.descKey) : "");
              const isActive = i === activeIdx;
              return (
                <button
                  key={`${item.type}-${item.id}`}
                  onClick={() => handleSelect(item)}
                  onMouseEnter={() => setActiveIdx(i)}
                  className={cn(
                    "w-full flex items-start gap-3 px-3 py-2.5 rounded-lg text-left transition-colors",
                    isActive ? "bg-[var(--vatan-blue-soft)]" : "hover:bg-muted/50"
                  )}
                  role="option"
                  aria-selected={isActive}
                >
                  <span className={cn(
                    "shrink-0 mt-0.5 w-7 h-7 rounded-md flex items-center justify-center",
                    isActive ? "bg-[var(--vatan-blue)] text-white" : "bg-muted/70 text-muted-foreground"
                  )}>
                    <TypeIcon type={item.type} />
                  </span>
                  <span className="flex-1 min-w-0">
                    <span className="flex items-center gap-2">
                      <span className="text-[10px] eyebrow text-muted-foreground">
                        {typeLabel(item.type, t)}
                      </span>
                    </span>
                    <span className="block text-[14px] font-medium text-foreground truncate">
                      {title}
                    </span>
                    {desc && (
                      <span className="block text-[12px] text-muted-foreground truncate">
                        {desc}
                      </span>
                    )}
                  </span>
                  <ArrowRight className={cn("w-4 h-4 mt-1.5 shrink-0 transition-opacity", isActive ? "text-[var(--vatan-blue)] opacity-100" : "opacity-0")} />
                </button>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.5 rounded border border-border bg-muted/50 font-mono">↑↓</kbd>
              navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.5 rounded border border-border bg-muted/50 font-mono">↵</kbd>
              open
            </span>
          </div>
          <span>{results.length} results</span>
        </div>
      </div>
    </div>
  );
}

function typeLabel(type: SearchableItem["type"], t: (k: string) => string) {
  switch (type) {
    case "section": return t("search.section");
    case "topic": return t("search.topic");
    case "source": return t("search.source");
    case "faq": return t("search.faq");
    case "glossary": return t("glossary.eyebrow");
  }
}

function TypeIcon({ type }: { type: SearchableItem["type"] }) {
  switch (type) {
    case "section": return <Layers className="w-3.5 h-3.5" />;
    case "topic": return <FileText className="w-3.5 h-3.5" />;
    case "source": return <BookOpen className="w-3.5 h-3.5" />;
    case "faq": return <HelpCircle className="w-3.5 h-3.5" />;
    case "glossary": return <BookMarked className="w-3.5 h-3.5" />;
  }
}
