"use client";

import React from "react";

/**
 * Subtle Uzbek-inspired decorative motifs.
 * These are SPARSE — used only occasionally around section edges, behind
 * selected headings, and in large background areas. Never tile everywhere.
 *
 * Inspired by: abstract sun/rays, minimal crescent-and-star, cotton/wheat
 * linework, abstract Humo-inspired curves, small geometric ornamental fragments.
 *
 * Colors use CSS variables (blue/green/brass) and currentColor.
 */

interface MotifProps {
  className?: string;
}

/** Abstract sun rays — minimalist, used behind hero heading.
 *  Coordinates are precomputed and rounded to avoid hydration mismatches.
 */
const SUN_RAYS = Array.from({ length: 36 }).map((_, i) => {
  const a = (i * Math.PI) / 18;
  const r1 = 70;
  const r2 = 180;
  return {
    x1: Math.round((200 + Math.cos(a) * r1) * 1000) / 1000,
    y1: Math.round((200 + Math.sin(a) * r1) * 1000) / 1000,
    x2: Math.round((200 + Math.cos(a) * r2) * 1000) / 1000,
    y2: Math.round((200 + Math.sin(a) * r2) * 1000) / 1000,
  };
});

export function SunRaysMotif({ className = "" }: MotifProps) {
  return (
    <svg
      viewBox="0 0 400 400"
      className={className}
      aria-hidden="true"
      fill="none"
    >
      <g stroke="currentColor" strokeWidth="1" opacity="0.55">
        {SUN_RAYS.map((l, i) => (
          <line key={i} x1={l.x1} y1={l.y1} x2={l.x2} y2={l.y2} />
        ))}
      </g>
      <circle cx="200" cy="200" r="56" stroke="currentColor" strokeWidth="1.2" opacity="0.7" />
      <circle cx="200" cy="200" r="62" stroke="currentColor" strokeWidth="0.6" opacity="0.4" />
    </svg>
  );
}

/** Minimal crescent-and-star — used occasionally as a tiny detail. */
export function CrescentStarMotif({ className = "" }: MotifProps) {
  return (
    <svg viewBox="0 0 120 120" className={className} aria-hidden="true" fill="none">
      <path
        d="M64 16a40 40 0 1 0 0 88 44 44 0 0 1 0-88Z"
        fill="currentColor"
        opacity="0.9"
      />
      <circle cx="44" cy="60" r="32" fill="var(--vatan-ivory, #F7F5EF)" />
      <path
        d="M86 40l3.6 7.3 8.1 1.2-5.85 5.7 1.38 8.06L86 68.4l-7.23 3.8 1.38-8.06-5.85-5.7 8.1-1.2L86 40Z"
        fill="currentColor"
      />
    </svg>
  );
}

/** Cotton-inspired linework — a delicate branch with 3 cotton bolls. */
export function CottonMotif({ className = "" }: MotifProps) {
  return (
    <svg viewBox="0 0 200 220" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1.2" opacity="0.7">
        <path d="M100 210 C100 170 100 130 100 90" />
        <path d="M100 150 C70 140 50 130 30 120" />
        <path d="M100 120 C130 110 150 100 170 92" />
        <path d="M100 95 C90 80 80 70 70 60" />
      </g>
      {/* cotton bolls */}
      <g fill="currentColor" opacity="0.85">
        <g transform="translate(30 110)">
          <circle cx="0" cy="0" r="9" />
          <circle cx="-6" cy="-4" r="6" />
          <circle cx="6" cy="-4" r="6" />
          <circle cx="0" cy="-8" r="6" />
        </g>
        <g transform="translate(170 82)">
          <circle cx="0" cy="0" r="9" />
          <circle cx="-6" cy="-4" r="6" />
          <circle cx="6" cy="-4" r="6" />
          <circle cx="0" cy="-8" r="6" />
        </g>
        <g transform="translate(100 70)">
          <circle cx="0" cy="0" r="9" />
          <circle cx="-6" cy="-4" r="6" />
          <circle cx="6" cy="-4" r="6" />
          <circle cx="0" cy="-8" r="6" />
        </g>
      </g>
      {/* leaves */}
      <g fill="currentColor" opacity="0.5">
        <path d="M100 150 C80 145 70 138 70 130 C82 132 92 140 100 150Z" />
        <path d="M100 120 C120 115 130 108 130 100 C118 102 108 110 100 120Z" />
      </g>
    </svg>
  );
}

/** Wheat-inspired linework — a delicate ear of wheat. */
export function WheatMotif({ className = "" }: MotifProps) {
  return (
    <svg viewBox="0 0 120 240" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1.1" opacity="0.7">
        <line x1="60" y1="230" x2="60" y2="60" />
      </g>
      <g fill="currentColor" opacity="0.85">
        {Array.from({ length: 7 }).map((_, i) => {
          const y = 70 + i * 22;
          return (
            <g key={i}>
              <ellipse cx="44" cy={y} rx="10" ry="5" transform={`rotate(-30 44 ${y})`} />
              <ellipse cx="76" cy={y} rx="10" ry="5" transform={`rotate(30 76 ${y})`} />
              <ellipse cx="60" cy={y - 8} rx="9" ry="4.5" />
            </g>
          );
        })}
      </g>
      {/* awns */}
      <g stroke="currentColor" strokeWidth="0.8" opacity="0.5">
        {Array.from({ length: 5 }).map((_, i) => {
          const y = 50 + i * 8;
          return (
            <g key={i}>
              <line x1="60" y1={y} x2="40" y2={y - 22} />
              <line x1="60" y1={y} x2="80" y2={y - 22} />
            </g>
          );
        })}
      </g>
    </svg>
  );
}

/** Abstract Humo-inspired wing curve — used near section edges. */
export function HumoCurveMotif({ className = "" }: MotifProps) {
  return (
    <svg viewBox="0 0 360 160" className={className} aria-hidden="true" fill="none">
      <path
        d="M10 140 C60 60 160 30 250 60 C300 78 330 110 350 140"
        stroke="currentColor"
        strokeWidth="1.4"
        opacity="0.7"
      />
      <path
        d="M30 140 C70 80 150 55 230 80 C275 95 300 120 320 140"
        stroke="currentColor"
        strokeWidth="0.8"
        opacity="0.4"
      />
      {/* feather-like divisions */}
      <g stroke="currentColor" strokeWidth="0.8" opacity="0.45">
        <line x1="80" y1="100" x2="70" y2="135" />
        <line x1="120" y1="80" x2="110" y2="135" />
        <line x1="160" y1="68" x2="155" y2="135" />
        <line x1="200" y1="65" x2="200" y2="135" />
        <line x1="240" y1="72" x2="248" y2="135" />
        <line x1="280" y1="92" x2="292" y2="138" />
      </g>
    </svg>
  );
}

/** Small geometric ornamental fragment — corner piece. */
export function CornerOrnament({ className = "" }: MotifProps) {
  return (
    <svg viewBox="0 0 80 80" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1" opacity="0.6">
        <path d="M4 4 L4 40 M4 4 L40 4" />
        <path d="M4 4 C20 12 28 20 36 36" />
        <circle cx="4" cy="4" r="2.5" fill="currentColor" opacity="0.5" />
        <circle cx="40" cy="4" r="1.6" fill="currentColor" />
        <circle cx="4" cy="40" r="1.6" fill="currentColor" />
        <path d="M16 4 L16 12 M4 16 L12 16" />
      </g>
    </svg>
  );
}

/** Tiny diamond cluster — very small accent. */
export function DiamondCluster({ className = "" }: MotifProps) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true" fill="none">
      <g stroke="currentColor" strokeWidth="1" opacity="0.7">
        <path d="M20 4 L28 20 L20 36 L12 20 Z" />
        <path d="M20 12 L24 20 L20 28 L16 20 Z" opacity="0.5" />
      </g>
    </svg>
  );
}

/** Decorative divider — small ornamental line with center diamond. */
export function OrnamentalDivider({ className = "" }: MotifProps) {
  return (
    <span
      className={`inline-flex items-center gap-2 ${className}`}
      aria-hidden="true"
    >
      <span className="block h-px w-10 bg-current opacity-30" />
      <DiamondCluster className="w-3.5 h-3.5 text-[var(--vatan-brass)]" />
      <span className="block h-px w-10 bg-current opacity-30" />
    </span>
  );
}
