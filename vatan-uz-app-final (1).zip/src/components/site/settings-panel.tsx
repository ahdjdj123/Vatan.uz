"use client";

import React, { useEffect } from "react";
import { useApp, type TextSize, type Theme } from "@/lib/contexts/app-context";
import { LANGS } from "@/lib/i18n";
import { X, Sun, Moon, Monitor, Type, Zap, Contrast, RotateCcw, Eye, ShieldCheck, CheckCircle2, Focus, Bookmark, BookMarked, BarChart3, Trophy, GraduationCap, LayoutGrid } from "lucide-react";
import { cn } from "@/lib/utils";
import { SectionChecklist } from "@/components/site/section-checklist";

function ToolButton({ label, icon: Icon, onClick, active }: { label: string; icon: React.ElementType; onClick: () => void; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center gap-2.5 px-3 py-2.5 rounded-lg border text-[13px] font-medium transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        active
          ? "border-[var(--vatan-blue)] bg-[var(--vatan-blue-soft)] text-foreground"
          : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/20"
      )}
    >
      <Icon className="w-4 h-4 shrink-0" />
      <span className="truncate">{label}</span>
    </button>
  );
}

export function SettingsPanel() {
  const {
    t,
    settingsOpen,
    setSettingsOpen,
    lang,
    setLang,
    theme,
    setTheme,
    textSize,
    setTextSize,
    reducedMotion,
    setReducedMotion,
    highContrast,
    setHighContrast,
    progress,
    resetProgress,
    studyMode,
    setStudyMode,
    setBookmarksOpen,
    setGlossaryOpen,
    setDashboardOpen,
    setAchievementsOpen,
    setQuizOpen,
  } = useApp();

  const [showResetToast, setShowResetToast] = React.useState(false);

  useEffect(() => {
    if (!settingsOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSettingsOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [settingsOpen, setSettingsOpen]);

  const onReset = () => {
    if (window.confirm(t("settings.progress.reset.confirm"))) {
      resetProgress();
      setShowResetToast(true);
      setTimeout(() => setShowResetToast(false), 2000);
    }
  };

  if (!settingsOpen) return null;

  const visitedCount = Object.values(progress.visited).filter(Boolean).length;
  const totalSections = 6;

  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center pt-[8vh] px-4" role="dialog" aria-modal="true" aria-label={t("settings.title")}>
      <div className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise" onClick={() => setSettingsOpen(false)} />
      <div className="relative w-full max-w-lg rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise max-h-[84vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <h2 className="text-[16px] font-semibold text-foreground">{t("settings.title")}</h2>
          <button
            onClick={() => setSettingsOpen(false)}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            aria-label={t("nav.close")}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto vatan-scroll px-5 py-4 space-y-6">
          {/* Tools — quick access to secondary features */}
          <Section title={t("nav.tools")} icon={<LayoutGrid className="w-3.5 h-3.5" />}>
            <div className="grid grid-cols-2 gap-2">
              <ToolButton
                label={t("bookmark.title")}
                icon={Bookmark}
                onClick={() => { setSettingsOpen(false); setTimeout(() => setBookmarksOpen(true), 100); }}
              />
              <ToolButton
                label={t("glossary.title")}
                icon={BookMarked}
                onClick={() => { setSettingsOpen(false); setTimeout(() => setGlossaryOpen(true), 100); }}
              />
              <ToolButton
                label={t("dashboard.title")}
                icon={BarChart3}
                onClick={() => { setSettingsOpen(false); setTimeout(() => setDashboardOpen(true), 100); }}
              />
              <ToolButton
                label={t("ach.title")}
                icon={Trophy}
                onClick={() => { setSettingsOpen(false); setTimeout(() => setAchievementsOpen(true), 100); }}
              />
              <ToolButton
                label={t("quiz.title")}
                icon={GraduationCap}
                onClick={() => { setSettingsOpen(false); setTimeout(() => setQuizOpen(true), 100); }}
              />
              <ToolButton
                label={studyMode ? t("study.off") : t("study.on")}
                icon={Focus}
                active={studyMode}
                onClick={() => setStudyMode(!studyMode)}
              />
            </div>
          </Section>

          {/* Language */}
          <Section title={t("settings.language")} icon={<Type className="w-3.5 h-3.5" />}>
            <div className="grid grid-cols-3 gap-2">
              {LANGS.map((l) => (
                <button
                  key={l.code}
                  onClick={() => setLang(l.code)}
                  className={cn(
                    "px-3 py-3 rounded-lg text-[13px] font-medium border transition-all",
                    lang === l.code
                      ? "border-[var(--vatan-blue)] bg-[var(--vatan-blue-soft)] text-foreground"
                      : "border-border text-muted-foreground hover:border-foreground/30 hover:text-foreground"
                  )}
                >
                  <span className="block mb-0.5">{l.native}</span>
                  <span className="text-[10px] uppercase eyebrow">{l.code}</span>
                </button>
              ))}
            </div>
          </Section>

          {/* Appearance */}
          <Section title={t("settings.appearance")} icon={<Sun className="w-3.5 h-3.5" />}>
            <div className="grid grid-cols-3 gap-2">
              {([
                { v: "light", label: t("settings.light"), Icon: Sun },
                { v: "dark", label: t("settings.dark"), Icon: Moon },
                { v: "system", label: t("settings.system"), Icon: Monitor },
              ] as { v: Theme; label: string; Icon: React.ElementType }[]).map((opt) => (
                <button
                  key={opt.v}
                  onClick={() => setTheme(opt.v)}
                  className={cn(
                    "flex flex-col items-center gap-1.5 px-3 py-3 rounded-lg text-[12.5px] font-medium border transition-all",
                    theme === opt.v
                      ? "border-[var(--vatan-blue)] bg-[var(--vatan-blue-soft)] text-foreground"
                      : "border-border text-muted-foreground hover:border-foreground/30 hover:text-foreground"
                  )}
                >
                  <opt.Icon className="w-4 h-4" />
                  {opt.label}
                </button>
              ))}
            </div>
          </Section>

          {/* Accessibility */}
          <Section title={t("settings.accessibility")} icon={<Eye className="w-3.5 h-3.5" />}>
            <div className="space-y-3">
              {/* Text size */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[13px] text-foreground">{t("settings.textsize")}</span>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {([
                    { v: "normal", label: t("settings.textsize.normal"), size: "text-[12px]" },
                    { v: "large", label: t("settings.textsize.large"), size: "text-[14px]" },
                    { v: "xlarge", label: t("settings.textsize.xlarge"), size: "text-[16px]" },
                  ] as { v: TextSize; label: string; size: string }[]).map((opt) => (
                    <button
                      key={opt.v}
                      onClick={() => setTextSize(opt.v)}
                      className={cn(
                        "px-3 py-2 rounded-lg border font-medium transition-all",
                        textSize === opt.v
                          ? "border-[var(--vatan-blue)] bg-[var(--vatan-blue-soft)] text-foreground"
                          : "border-border text-muted-foreground hover:text-foreground",
                        opt.size
                      )}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggles */}
              <ToggleRow
                label={t("settings.reducedmotion")}
                desc="↓"
                Icon={Zap}
                checked={reducedMotion}
                onChange={setReducedMotion}
              />
              <ToggleRow
                label={t("settings.highcontrast")}
                Icon={Contrast}
                checked={highContrast}
                onChange={setHighContrast}
              />
              <ToggleRow
                label={t("study.title")}
                desc={t("study.desc")}
                Icon={Focus}
                checked={studyMode}
                onChange={setStudyMode}
              />
            </div>
          </Section>

          {/* Progress */}
          <Section title={t("settings.progress")} icon={<CheckCircle2 className="w-3.5 h-3.5" />}>
            <div className="space-y-3">
              <div className="rounded-lg border border-border p-4 bg-muted/30">
                <div className="grid grid-cols-3 gap-3 text-center">
                  <Stat label={t("progress.visited")} value={`${visitedCount}/${totalSections}`} />
                  <Stat label={t("progress.activities")} value={`${progress.scenarioCompleted}`} />
                  <Stat label={t("progress.reflections")} value={`${Object.keys(progress.reflections).length}`} />
                </div>
                <div className="mt-3 h-1.5 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full bg-[var(--vatan-blue)] transition-all"
                    style={{ width: `${(visitedCount / totalSections) * 100}%` }}
                  />
                </div>
              </div>

              {/* Per-section checklist */}
              <div className="rounded-lg border border-border bg-card/40 p-3">
                <div className="text-[10px] eyebrow text-muted-foreground font-semibold mb-2 px-1">
                  {t("checklist.title")}
                </div>
                <SectionChecklist />
              </div>

              <button
                onClick={onReset}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-[var(--vatan-red)]/30 text-[var(--vatan-red)] text-[13px] font-medium hover:bg-[var(--vatan-red-soft)]/50 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                {t("settings.progress.reset")}
              </button>
              {showResetToast && (
                <div className="rounded-lg bg-[var(--vatan-green-soft)]/60 border border-[var(--vatan-green)]/20 px-3 py-2 text-[12px] text-[var(--vatan-green)] font-medium vatan-rise">
                  {t("progress.reset.done")}
                </div>
              )}
            </div>
          </Section>

          {/* Privacy */}
          <Section title={t("settings.privacy.title")} icon={<ShieldCheck className="w-3.5 h-3.5" />}>
            <p className="text-[12.5px] leading-relaxed text-muted-foreground">
              {t("settings.privacy.body")}
            </p>
          </Section>
        </div>
      </div>
    </div>
  );
}

function Section({ title, icon, children }: { title: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <span className="text-muted-foreground">{icon}</span>
        <h3 className="text-[11px] eyebrow text-muted-foreground font-semibold">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="font-mono text-[18px] font-bold text-foreground tabular-nums">{value}</div>
      <div className="text-[10px] eyebrow text-muted-foreground mt-0.5">{label}</div>
    </div>
  );
}

function ToggleRow({
  label,
  desc,
  Icon,
  checked,
  onChange,
}: {
  label: string;
  desc?: string;
  Icon: React.ElementType;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className="w-full flex items-center justify-between gap-3 px-3 py-2.5 rounded-lg border border-border hover:bg-muted/40 transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
      role="switch"
      aria-checked={checked}
    >
      <span className="flex items-center gap-2.5">
        <Icon className="w-4 h-4 text-muted-foreground" />
        <span className="text-[13px] text-foreground">{label}</span>
        {desc && <span className="text-[10px] text-muted-foreground">{desc}</span>}
      </span>
      <span
        className={cn(
          "relative w-9 h-5 rounded-full transition-colors shrink-0",
          checked ? "bg-[var(--vatan-blue)]" : "bg-muted"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 w-4 h-4 rounded-full bg-white shadow-sm transition-transform",
            checked ? "translate-x-[18px]" : "translate-x-0.5"
          )}
        />
      </span>
    </button>
  );
}
