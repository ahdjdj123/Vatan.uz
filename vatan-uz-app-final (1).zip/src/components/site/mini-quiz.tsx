"use client";

import React, { useEffect, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { GraduationCap, X, CheckCircle2, XCircle, ChevronRight, RotateCcw, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const QUESTIONS = ["q1", "q2", "q3", "q4", "q5"] as const;
const OPTIONS = ["a1", "a2", "a3"] as const;

export function MiniQuiz() {
  const { t, quizOpen, setQuizOpen, celebrate, progress } = useApp();
  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    if (!quizOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setQuizOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [quizOpen, setQuizOpen]);

  // Reset on open
  useEffect(() => {
    if (quizOpen) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setIdx(0);
       
      setSelected(null);
       
      setScore(0);
       
      setStarted(false);
    }
  }, [quizOpen]);

  if (!quizOpen) return null;

  const qKey = QUESTIONS[idx];
  const correctOpt = t(`quiz.${qKey}.correct`) as string;
  const isLast = idx === QUESTIONS.length - 1;
  const allDone = idx >= QUESTIONS.length;

  const onChoose = (optIdx: number) => {
    if (selected !== null) return;
    setSelected(optIdx);
    const chosen = OPTIONS[optIdx];
    if (chosen === correctOpt) {
      setScore((s) => s + 1);
    }
  };

  const next = () => {
    if (isLast) {
      // Celebrate quiz completion
      if (!progress.celebratedSections.includes("mini-quiz-done")) {
        celebrate("mini-quiz-done", "quiz.complete");
      }
      return;
    }
    setIdx((i) => i + 1);
    setSelected(null);
  };

  const retry = () => {
    setIdx(0);
    setSelected(null);
    setScore(0);
    setStarted(true);
  };

  return (
    <div
      className="fixed inset-0 z-[70] flex items-start sm:items-center justify-center pt-[8vh] sm:pt-0 px-4"
      role="dialog"
      aria-modal="true"
      aria-label={t("quiz.title")}
    >
      <div
        className="absolute inset-0 bg-foreground/30 backdrop-blur-sm vatan-rise"
        onClick={() => setQuizOpen(false)}
      />
      <div className="relative w-full max-w-lg rounded-2xl border border-border bg-popover shadow-2xl overflow-hidden vatan-rise max-h-[84vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-border shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--vatan-green-soft)] text-[var(--vatan-green)] flex items-center justify-center">
              <GraduationCap className="w-4 h-4" />
            </div>
            <div>
              <div className="text-[10px] eyebrow text-[var(--vatan-green)] font-semibold">
                {t("quiz.eyebrow")}
              </div>
              <h2 className="text-[16px] font-semibold text-foreground">
                {t("quiz.title")}
              </h2>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {started && !allDone && (
              <span className="font-mono text-[14px] font-bold text-[var(--vatan-green)] tabular-nums">
                {score}/{QUESTIONS.length}
              </span>
            )}
            <button
              onClick={() => setQuizOpen(false)}
              className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted/60 transition-colors"
              aria-label={t("quiz.exit")}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto vatan-scroll p-5">
          {!started ? (
            // Start screen
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[var(--vatan-green-soft)] text-[var(--vatan-green)] mb-4">
                <GraduationCap className="w-8 h-8" />
              </div>
              <h3 className="text-[20px] font-semibold text-foreground mb-2">
                {t("quiz.title")}
              </h3>
              <p className="text-[13.5px] text-muted-foreground mb-6 max-w-sm mx-auto leading-relaxed">
                {QUESTIONS.length} {t("quiz.question").toLowerCase()} {t("quiz.of")} {QUESTIONS.length}
              </p>
              <button
                onClick={() => setStarted(true)}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-[var(--vatan-green)] text-white text-[14px] font-medium hover:bg-[var(--vatan-green)]/90 active:scale-[0.98] transition-all"
              >
                <Sparkles className="w-4 h-4" />
                {t("quiz.start")}
              </button>
            </div>
          ) : allDone ? (
            // Completion screen
            <div className="text-center py-8">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[var(--vatan-green-soft)] text-[var(--vatan-green)] mb-4">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h3 className="text-[20px] font-semibold text-foreground mb-2">
                {t("quiz.complete")}
              </h3>
              <p className="text-[32px] font-bold text-[var(--vatan-green)] font-mono tabular-nums mb-6">
                {score}/{QUESTIONS.length}
              </p>
              <button
                onClick={retry}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg border border-border text-[14px] font-medium hover:bg-muted/60 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                {t("quiz.retry")}
              </button>
            </div>
          ) : (
            // Question
            <>
              {/* Progress dots */}
              <div className="flex items-center gap-1.5 mb-5">
                {QUESTIONS.map((_, i) => (
                  <div
                    key={i}
                    className={cn(
                      "h-1 flex-1 rounded-full transition-colors",
                      i < idx ? "bg-[var(--vatan-green)]" :
                      i === idx ? "bg-[var(--vatan-blue)]" : "bg-muted"
                    )}
                  />
                ))}
              </div>

              <div className="text-[11px] eyebrow text-muted-foreground mb-2">
                {t("quiz.question")} {idx + 1} {t("quiz.of")} {QUESTIONS.length}
              </div>
              <p className="text-[17px] sm:text-[18px] font-semibold text-foreground leading-snug mb-5">
                {t(`quiz.${qKey}`)}
              </p>

              <div className="space-y-2">
                {OPTIONS.map((opt, i) => {
                  const isPicked = selected === i;
                  const showState = selected !== null;
                  const isCorrect = opt === correctOpt;
                  const stateCls = showState
                    ? isCorrect
                      ? "border-[var(--vatan-green)] bg-[var(--vatan-green-soft)]/50"
                      : isPicked
                      ? "border-[var(--vatan-red)] bg-[var(--vatan-red-soft)]/40"
                      : "border-border opacity-60"
                    : "border-border hover:border-[var(--vatan-green)]/50 hover:bg-muted/40";
                  return (
                    <button
                      key={opt}
                      onClick={() => onChoose(i)}
                      disabled={selected !== null}
                      className={cn(
                        "w-full flex items-center gap-3 p-3.5 rounded-xl border text-left transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                        stateCls
                      )}
                    >
                      <span className={cn(
                        "shrink-0 w-6 h-6 rounded-full flex items-center justify-center font-mono text-[11px] font-bold border",
                        showState && isCorrect
                          ? "bg-[var(--vatan-green)] text-white border-[var(--vatan-green)]"
                          : showState && isPicked
                          ? "bg-[var(--vatan-red)] text-white border-[var(--vatan-red)]"
                          : "border-border text-muted-foreground"
                      )}>
                        {showState && isCorrect ? (
                          <CheckCircle2 className="w-4 h-4" />
                        ) : showState && isPicked ? (
                          <XCircle className="w-4 h-4" />
                        ) : (
                          String.fromCharCode(65 + i)
                        )}
                      </span>
                      <span className="text-[14px] leading-relaxed text-foreground flex-1">
                        {t(`quiz.${qKey}.${opt}`)}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Feedback */}
              {selected !== null && (
                <div className="mt-4 vatan-rise">
                  <div className={cn(
                    "rounded-xl p-4",
                    OPTIONS[selected] === correctOpt
                      ? "bg-[var(--vatan-green-soft)]/60 border border-[var(--vatan-green)]/20"
                      : "bg-[var(--vatan-red-soft)]/50 border border-[var(--vatan-red)]/20"
                  )}>
                    <div className="flex items-center gap-2 mb-1.5">
                      {OPTIONS[selected] === correctOpt ? (
                        <CheckCircle2 className="w-4 h-4 text-[var(--vatan-green)]" />
                      ) : (
                        <XCircle className="w-4 h-4 text-[var(--vatan-red)]" />
                      )}
                      <span className={cn(
                        "text-[11px] eyebrow font-semibold",
                        OPTIONS[selected] === correctOpt ? "text-[var(--vatan-green)]" : "text-[var(--vatan-red)]"
                      )}>
                        {OPTIONS[selected] === correctOpt ? t("quiz.correct") : t("quiz.incorrect")}
                      </span>
                    </div>
                    <p className="text-[13px] leading-relaxed text-foreground/90">
                      {t(`quiz.${qKey}.exp`)}
                    </p>
                  </div>
                  <div className="mt-4 flex justify-end">
                    {!isLast ? (
                      <button
                        onClick={next}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[var(--vatan-blue)] text-white text-[14px] font-medium hover:bg-[var(--vatan-blue-deep)] active:scale-[0.98] transition-all"
                      >
                        {t("quiz.next")}
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    ) : (
                      <button
                        onClick={next}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[var(--vatan-green)] text-white text-[14px] font-medium hover:bg-[var(--vatan-green)]/90 active:scale-[0.98] transition-all"
                      >
                        {t("quiz.complete")}
                        <CheckCircle2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
