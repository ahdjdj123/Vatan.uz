"use client";

import React, { useEffect, useRef } from "react";
import { useApp, type SectionId } from "@/lib/contexts/app-context";
import { scrollToSection } from "@/lib/use-active-section";
import { ArrowRight, BookOpen, CheckCircle2, Flame } from "lucide-react";
import { cn } from "@/lib/utils";

const SECTION_META: { id: SectionId; num: string; key: string }[] = [
  { id: "s1", num: "01", key: "nav.01" },
  { id: "s2", num: "02", key: "nav.02" },
  { id: "s3", num: "03", key: "nav.03" },
  { id: "s4", num: "04", key: "nav.04" },
  { id: "s5", num: "05", key: "nav.05" },
];

export function ContinueReading() {
  const { t, progress, markVisited, celebrate } = useApp();
  const last = progress.lastVisited;

  // Count visited sections (excluding hero)
  const visitedCount = SECTION_META.filter((s) => progress.visited[s.id]).length;
  const totalCount = SECTION_META.length;
  const allComplete = visitedCount === totalCount;
  const pct = Math.round((visitedCount / totalCount) * 100);

  // Celebrate when all sections first visited
  const celebratedRef = useRef(false);
  useEffect(() => {
    if (allComplete && !celebratedRef.current && !progress.celebratedSections.includes("all")) {
      celebratedRef.current = true;
      celebrate("all", "celebrate.all");
    }
  }, [allComplete, progress.celebratedSections, celebrate]);

  // Don't show if no sections visited yet (only hero)
  if (visitedCount === 0) return null;

  const lastMeta = last ? SECTION_META.find((s) => s.id === last) : null;

  const handleContinue = () => {
    if (last) {
      markVisited(last);
      scrollToSection(last);
    } else {
      scrollToSection("s1");
    }
  };

  return (
    <div className="mt-8 rounded-2xl border border-[var(--vatan-blue)]/20 bg-gradient-to-r from-[var(--vatan-blue-soft)]/60 to-transparent p-4 sm:p-5">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3 min-w-0">
          <div className="shrink-0 w-10 h-10 rounded-lg bg-[var(--vatan-blue)] text-white flex items-center justify-center">
            {allComplete ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <BookOpen className="w-5 h-5" />
            )}
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <div className="text-[10px] eyebrow text-[var(--vatan-blue)] font-semibold">
                {t("continue.progress")}
              </div>
              {progress.streak > 0 && (
                <span className="inline-flex items-center gap-0.5 text-[10px] eyebrow font-semibold text-[var(--vatan-brass)]">
                  <Flame className="w-3 h-3" />
                  {progress.streak} {t("streak.days")}
                </span>
              )}
            </div>
            <div className="text-[14px] font-semibold text-foreground truncate">
              {allComplete
                ? t("continue.complete")
                : lastMeta
                ? `${t("continue.lastSection")}: ${t(lastMeta.key)}`
                : t("continue.title")}
            </div>
            {/* Progress bar */}
            <div className="mt-1.5 h-1 w-32 sm:w-40 rounded-full bg-muted overflow-hidden">
              <div
                className="h-full bg-[var(--vatan-blue)] transition-all duration-500"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        </div>

        {!allComplete && (
          <button
            onClick={handleContinue}
            className="group inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[var(--vatan-blue)] text-white text-[13px] font-medium hover:bg-[var(--vatan-blue-deep)] active:scale-[0.98] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring shrink-0"
          >
            {t("continue.cta")}
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </button>
        )}
      </div>

      {/* Section dots */}
      <div className="mt-3 flex items-center gap-1.5">
        {SECTION_META.map((s) => {
          const visited = progress.visited[s.id];
          const isLast = last === s.id;
          return (
            <button
              key={s.id}
              onClick={() => {
                markVisited(s.id);
                scrollToSection(s.id);
              }}
              className={cn(
                "flex-1 h-1.5 rounded-full transition-all group/dot relative",
                visited ? "bg-[var(--vatan-blue)]" : "bg-muted",
                isLast && "ring-2 ring-[var(--vatan-blue)]/30 ring-offset-1"
              )}
              aria-label={`${s.num} ${t(s.key)}`}
              title={`${s.num} ${t(s.key)}`}
            >
              <span className="absolute -top-7 left-1/2 -translate-x-1/2 text-[9px] font-mono text-muted-foreground opacity-0 group-hover/dot:opacity-100 transition-opacity pointer-events-none whitespace-nowrap">
                {s.num}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
