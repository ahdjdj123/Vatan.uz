"use client";

import React, { useEffect, useState } from "react";
import { useApp } from "@/lib/contexts/app-context";
import { SunRaysMotif, CrescentStarMotif, DiamondCluster, HumoCurveMotif } from "@/components/site/motifs";
import { ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Premium, short, skippable introduction.
 * Shows "Made by Abdushukur's team" → tagline → CTA.
 * Persists "seen" in localStorage so it shows only once.
 */
export function IntroExperience() {
  const { t, introSeen, setIntroSeen, reducedMotion } = useApp();
  const [phase, setPhase] = useState<0 | 1 | 2>(0);
  const [leaving, setLeaving] = useState(false);

  // Already seen -> don't render
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);

  const finish = React.useCallback(() => {
    setLeaving(true);
    window.setTimeout(() => {
      setIntroSeen(true);
    }, reducedMotion ? 0 : 380);
  }, [setIntroSeen, reducedMotion]);

  // Phase progression
  useEffect(() => {
    if (introSeen || !mounted) return;
    if (reducedMotion) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setPhase(2);
      return;
    }
    const p1 = window.setTimeout(() => setPhase(1), 700);
    const p2 = window.setTimeout(() => setPhase(2), 1500);
    return () => {
      window.clearTimeout(p1);
      window.clearTimeout(p2);
    };
  }, [introSeen, mounted, reducedMotion]);

  // Keyboard: Enter/Space/Escape to proceed
  useEffect(() => {
    if (introSeen || !mounted) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Enter" || e.key === " " || e.key === "Escape") {
        e.preventDefault();
        finish();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [introSeen, mounted, finish]);

  if (!mounted || introSeen) return null;

  return (
    <div
      className={cn(
        "fixed inset-0 z-[100] bg-[var(--vatan-ivory)] dark:bg-[#14181A] flex items-center justify-center overflow-hidden",
        "transition-opacity duration-300",
        leaving ? "opacity-0" : "opacity-100"
      )}
      role="dialog"
      aria-modal="true"
      aria-label={t("intro.tagline")}
    >
      {/* Subtle background motifs */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <SunRaysMotif className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120vmin] h-[120vmin] text-[var(--vatan-brass)] opacity-[0.07]" />
        <HumoCurveMotif className="absolute -bottom-16 -left-16 w-[440px] h-[220px] text-[var(--vatan-blue)] opacity-[0.07]" />
        <CrescentStarMotif className="absolute top-16 right-[14%] w-12 h-12 text-[var(--vatan-blue)] opacity-[0.15]" />
        <DiamondCluster className="absolute bottom-24 right-[26%] w-5 h-5 text-[var(--vatan-brass)] opacity-50" />
      </div>

      <div className="relative z-10 px-6 text-center max-w-2xl">
        {/* Phase 0: Made by */}
        <div
          className={cn(
            "transition-all duration-500",
            phase >= 0 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
          )}
        >
          <div className="flex items-center justify-center gap-2.5 mb-5">
            <span className="h-px w-6 bg-[var(--vatan-brass)]/60" />
            <span className="eyebrow text-[10px] sm:text-[11px] font-semibold text-[var(--vatan-brass)]">
              {t("intro.madeBy")}
            </span>
            <span className="h-px w-6 bg-[var(--vatan-brass)]/60" />
          </div>
        </div>

        {/* Phase 1: Tagline */}
        <h1
          className={cn(
            "display-heading font-semibold text-foreground transition-all duration-700",
            phase >= 1 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-3"
          )}
          style={{ fontSize: "clamp(36px, 8vw, 72px)", lineHeight: 1.02 }}
        >
          {t("intro.tagline").split(" — ").map((part, i) => (
            <React.Fragment key={i}>
              {i === 1 ? (
                <span className="text-[var(--vatan-blue)]"> — {part}</span>
              ) : (
                part
              )}
            </React.Fragment>
          ))}
        </h1>

        {/* Phase 2: CTA */}
        <div
          className={cn(
            "mt-9 transition-all duration-500",
            phase >= 2 ? "opacity-100 translate-y-0" : "opacity-0 translate-y-2"
          )}
        >
          <button
            onClick={finish}
            className="group inline-flex items-center gap-2.5 px-7 py-3.5 rounded-lg bg-[var(--vatan-blue)] text-white font-medium text-[15px] shadow-sm hover:bg-[var(--vatan-blue-deep)] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
          >
            {t("intro.cta")}
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </button>

          <button
            onClick={finish}
            className="block mx-auto mt-4 text-[12px] text-muted-foreground hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded px-2 py-1"
          >
            {t("intro.skip")} →
          </button>
        </div>
      </div>

      {/* Progress dots */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-1.5" aria-hidden="true">
        {[0, 1, 2].map((p) => (
          <span
            key={p}
            className={cn(
              "h-1 rounded-full transition-all duration-300",
              phase >= p ? "w-6 bg-[var(--vatan-blue)]" : "w-1.5 bg-muted-foreground/40"
            )}
          />
        ))}
      </div>
    </div>
  );
}
