"use client";

import React from "react";
import { useApp } from "@/lib/contexts/app-context";
import { scrollToSection } from "@/lib/use-active-section";
import { ArrowRight, Presentation, Info, ChevronDown } from "lucide-react";
import { SunRaysMotif, CrescentStarMotif, HumoCurveMotif, DiamondCluster } from "@/components/site/motifs";
import { ContinueReading } from "@/components/site/continue-reading";

export function Hero() {
  const { t, setPresentationOpen, markVisited } = useApp();

  const start = () => {
    markVisited("hero");
    scrollToSection("s1");
  };

  return (
    <section
      id="hero"
      className="relative min-h-[100svh] flex items-center pt-20 pb-24 overflow-hidden"
      aria-labelledby="hero-title"
    >
      {/* Background — subtle Uzbek-inspired geometry */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        {/* ivory base already from body. Add faint warm wash */}
        <div className="absolute inset-0 bg-gradient-to-b from-[var(--vatan-ivory)] via-[var(--vatan-ivory)] to-[#F1EEE4]" />
        {/* Sun rays top-right, very faint */}
        <SunRaysMotif className="absolute -top-24 -right-24 w-[560px] h-[560px] text-[var(--vatan-brass)] opacity-[0.12]" />
        {/* Humo curve bottom-left */}
        <HumoCurveMotif className="absolute -bottom-10 -left-10 w-[420px] h-[200px] text-[var(--vatan-blue)] opacity-[0.10]" />
        {/* Crescent tiny accent */}
        <CrescentStarMotif className="absolute top-28 right-[8%] w-12 h-12 text-[var(--vatan-blue)] opacity-20" />
        {/* Tiny diamond cluster accent */}
        <DiamondCluster className="absolute bottom-32 right-[22%] w-5 h-5 text-[var(--vatan-brass)] opacity-60" />
        {/* Soft grid lines, very faint */}
        <div
          className="absolute inset-0 opacity-[0.025]"
          style={{
            backgroundImage:
              "linear-gradient(to right, #000 1px, transparent 1px), linear-gradient(to bottom, #000 1px, transparent 1px)",
            backgroundSize: "80px 80px",
          }}
        />
      </div>

      <div className="relative mx-auto max-w-[1280px] px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-8 max-w-3xl">
            {/* Eyebrow */}
            <div className="flex items-center gap-3 mb-7">
              <span className="h-px w-8 bg-[var(--vatan-blue)]" />
              <span className="eyebrow text-[11px] text-[var(--vatan-blue)] font-semibold">
                {t("hero.eyebrow")}
              </span>
            </div>

            {/* Title */}
            <h1
              id="hero-title"
              className="display-heading font-semibold text-foreground text-[44px] leading-[0.98] sm:text-[64px] lg:text-[88px] xl:text-[104px]"
            >
              {t("hero.title").split("\n").map((line, i) => (
                <React.Fragment key={i}>
                  {i === 1 ? (
                    <span className="text-[var(--vatan-blue)]">{line}</span>
                  ) : (
                    line
                  )}
                  {i === 0 && <br />}
                </React.Fragment>
              ))}
            </h1>

            {/* Subtitle */}
            <p className="mt-7 text-[16px] sm:text-[18px] lg:text-[20px] leading-relaxed text-[var(--vatan-slate)] max-w-2xl">
              {t("hero.subtitle")}
            </p>

            {/* CTAs */}
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <button
                onClick={start}
                className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-lg bg-[var(--vatan-blue)] text-white font-medium text-[15px] shadow-sm hover:bg-[var(--vatan-blue-deep)] transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
              >
                {t("hero.cta.start")}
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
              </button>
              <button
                onClick={() => scrollToSection("about")}
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-lg border border-[var(--vatan-blue)]/30 text-foreground font-medium text-[15px] hover:bg-[var(--vatan-blue-soft)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                <Info className="w-4 h-4 text-[var(--vatan-blue)]" />
                {t("hero.cta.about")}
              </button>
              <button
                onClick={() => setPresentationOpen(true)}
                className="inline-flex items-center gap-2 px-2 py-3.5 text-[15px] font-medium text-foreground/80 hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md"
              >
                <Presentation className="w-4 h-4 text-[var(--vatan-brass)]" />
                {t("hero.cta.presentation")}
              </button>
            </div>

            {/* Continue reading tracker — appears once user has visited a section */}
            <ContinueReading />
          </div>

          {/* Side card — mini index */}
          <div className="lg:col-span-4 lg:pl-6">
            <div className="relative rounded-2xl border border-border bg-card/80 backdrop-blur-sm p-6 shadow-[0_8px_30px_-12px_rgba(24,32,29,0.08)]">
              <div className="flex items-center justify-between mb-5">
                <span className="eyebrow text-[10px] text-muted-foreground">
                  {t("nav.section")}
                </span>
                <DiamondCluster className="w-3.5 h-3.5 text-[var(--vatan-brass)]" />
              </div>
              <ol className="space-y-1">
                {[
                  { id: "s1", num: "01", key: "nav.01" },
                  { id: "s2", num: "02", key: "nav.02" },
                  { id: "s3", num: "03", key: "nav.03" },
                  { id: "s4", num: "04", key: "nav.04" },
                  { id: "s5", num: "05", key: "nav.05" },
                ].map((s) => (
                  <li key={s.id}>
                    <button
                      onClick={() => scrollToSection(s.id)}
                      className="group w-full flex items-center gap-3 py-2.5 px-2 -mx-2 rounded-md hover:bg-muted/50 transition-colors text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    >
                      <span className="font-mono text-[12px] text-[var(--vatan-blue)] tabular-nums w-6">
                        {s.num}
                      </span>
                      <span className="text-[14px] font-medium flex-1">{t(s.key)}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-muted-foreground opacity-0 -translate-x-1 group-hover:opacity-100 group-hover:translate-x-0 transition-all" />
                    </button>
                  </li>
                ))}
              </ol>
              <div className="mt-5 pt-4 border-t border-border">
                <p className="text-[12px] text-muted-foreground leading-relaxed">
                  {t("brand.tagline")}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll hint */}
        <div className="hidden md:flex absolute bottom-6 left-1/2 -translate-x-1/2 flex-col items-center gap-2 text-muted-foreground">
          <span className="text-[11px] eyebrow">{t("hero.scroll")}</span>
          <ChevronDown className="w-4 h-4 animate-bounce" style={{ animationDuration: "2s" }} />
        </div>
      </div>
    </section>
  );
}
