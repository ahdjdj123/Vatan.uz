# Vatan.uz.app

**Yagona Vatan — yagona xalq**
*One Homeland — One People*

Interactive educational web application for students in grades 9–11 in Uzbekistan, covering homeland, independence, reforms, cybersecurity, and research conclusion.

## Project Description

Vatan.uz.app is a single-page educational platform built for classroom and independent study. It combines editorial information design with subtle Uzbek national identity, interactive learning scenarios, a presentation mode for teachers, and a research/survey framework for students.

## Main Sections

1. **Yagona Vatan** — One Homeland (shared values, unity)
2. **Mustaqillik** — Independence (statehood, symbols, rights)
3. **Islohotlar** — Reforms (problem → solution → result framework)
4. **Kiberxavfsizlik** — Cybersecurity (interactive scenario-based learning)
5. **Xulosa** — Conclusion (research, survey, reflection, sources)

## Key Interactive Features

- **Trilingual** — Uzbek (UZ), English (EN), Russian (RU) with full UI translation
- **Presentation Mode** — 12-slide classroom presentation with keyboard navigation
- **Cybersecurity Scenarios** — 5 interactive scenarios with feedback and safer actions
- **Mini Quiz** — 5-question self-test with explanations
- **Reflection** — Save/share personal reflections (localStorage)
- **Survey Builder** — Create and visualize real survey data (demo/real toggle)
- **Glossary** — 20 educational terms with definitions
- **Bookmarks** — Save sections for quick access
- **Achievements** — 9 milestone badges
- **Progress Dashboard** — Comprehensive stats overview
- **Search** — Global search across all content
- **Settings** — Language, theme (light/dark), text size, accessibility, study mode
- **Keyboard Shortcuts** — Press `?` for the full list

## Technology Stack

- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 with shadcn/ui
- **Icons**: Lucide React
- **State**: React Context + localStorage (no backend, no database)
- **Fonts**: Geist Sans / Geist Mono (Latin, Cyrillic subsets)

## Local Installation

```bash
# Install dependencies
bun install

# Start development server
bun run dev

# The app runs on http://localhost:3000
```

## Build & Deployment

```bash
# Create production build
bun run build

# Start production server
bun run start
```

The project is configured for deployment on Vercel or any Node.js hosting platform.

## Environment Variables

This project does not require any environment variables for basic operation.
All data is stored locally in the browser via `localStorage`.
No backend, API keys, or database connections are needed.

If you add backend features in the future, create a `.env.local` file (not committed) with your variables.

## Project Structure

```
src/
├── app/                    # Next.js App Router
│   ├── globals.css         # Global styles + theme variables
│   ├── layout.tsx          # Root layout
│   └── page.tsx            # Main single-page application
├── components/
│   └── site/               # All site components
│       ├── sections/       # 5 educational sections
│       ├── header.tsx      # Navigation header
│       ├── footer.tsx      # Footer
│       ├── hero.tsx        # Hero section
│       ├── presentation-mode.tsx
│       ├── search-modal.tsx
│       ├── settings-panel.tsx
│       ├── glossary-modal.tsx
│       ├── bookmarks-modal.tsx
│       ├── achievements-modal.tsx
│       ├── mini-quiz.tsx
│       ├── progress-dashboard.tsx
│       └── ...
├── lib/
│   ├── i18n.ts             # Translations (UZ/EN/RU)
│   ├── contexts/           # React Context (app state)
│   ├── content.ts          # Content data (sources, scenarios, search index)
│   └── utils.ts            # Utilities
└── public/                 # Static assets
```

## Made by Abdushukur's team

- Research
- Content
- Design
- Development
- Presentation
